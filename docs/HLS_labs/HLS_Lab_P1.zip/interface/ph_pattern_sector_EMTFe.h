//////////////////////////////////////////////////////////////////////////////////
// Company: UF
// Author: Rafael Hernandez
//
// Create Date:    01:36:08 03/19/2010
// Design Name: tf_slch
// Module Name:    ph_pattern_sector
// Project Name: tf_slch
// Target Devices: V6
// Tool versions: 11.4
// Description: pattern detector for entire sector
//
// Dependencies: ph_pattern
//
// Revision:
// Revision 0.01 - File Created
// Additional Comments: Translated by Rafael into C++
//
//////////////////////////////////////////////////////////////////////////////////
#ifndef _PH_PATTERN_SECTOR_CLASS_
#define _PH_PATTERN_SECTOR_CLASS_

#define PHPS_FILE_MACRO
#define PHPS_FILENAME "phps_o.out"

#ifndef __SYNTHESIS__
  #ifdef PHPS_FILE_MACRO
    #include <iostream>
    #include <iomanip>
    #include <fstream>
  #endif // PHPS_FILE
#endif // Synthesis

#ifdef _LOCAL_AP_INT_H_
  #include "../include/ap_int.h"
#else
  #include <ap_int.h>
#endif
#include "../interface/spbits.h"
#include "../interface/ph_pattern_EMTFe.h"

struct ph_pattern_sector {
    ph_pattern php[7][ph_raw_w];

    ph_pattern_sector();

    void operator()(
        const ap_uint<ph_raw_w>  st[7][15],
        const ap_uint<3>        &drifttime,
        const ap_uint<3>        &foldn,
              ap_uint<11>        qcode[7][ph_raw_w]
    );
};

#endif

