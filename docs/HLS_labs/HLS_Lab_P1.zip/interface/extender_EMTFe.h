//////////////////////////////////////////////////////////////////////////////////
// Company: UF
// Author: Rafael Hernandez, Beichen (Oliver) Su
//
// Create Date:    14:24:00 03/12/2010 
// Design Name: tf_slhc
// Module Name:    extender 
// Project Name: tf_slhc
// Target Devices: V6
// Tool versions: 11.4
// Description: pulse extender
//
// Dependencies:
//
// Revision: 
// Revision 0.01 - File Created
// Additional Comments: Translated by Oliver into C++, heavily updated by Rafael
//
//////////////////////////////////////////////////////////////////////////////////

#ifndef _EXTENDER_CLASS_
#define _EXTENDER_CLASS_

#ifdef _LOCAL_AP_INT_H_
  #include "../include/ap_int.h"
#else
  #include <ap_int.h>
#endif
#include "../interface/spbits.h"

struct extender {
    ap_uint<ph_raw_w> d1;
    ap_uint<ph_raw_w> d2;

    extender();

    void operator()(
        const ap_uint<ph_raw_w> &inp,
              ap_uint<ph_raw_w> &outp,
        const ap_uint<3>        &drifttime
    );
};
#endif

