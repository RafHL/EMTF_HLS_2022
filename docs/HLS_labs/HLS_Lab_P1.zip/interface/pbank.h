// Pattern bank [pattern][zone][layer][0 - min, 1 - mid, 2 - max]
constexpr int pbank[18][7][15][3] = {
    { // Pat: 0
        { // Zon: 0
            {12, 19, 24}, // Pat: 0 Zon: 0 Lay: 0
            { 0,  0,  0}, // Pat: 0 Zon: 0 Lay: 1
            { 0,  0,  0}, // Pat: 0 Zon: 0 Lay: 2
            {24, 27, 30}, // Pat: 0 Zon: 0 Lay: 3
            {22, 27, 32}, // Pat: 0 Zon: 0 Lay: 4
            { 0,  0,  0}, // Pat: 0 Zon: 0 Lay: 5
            { 0,  0,  0}, // Pat: 0 Zon: 0 Lay: 6
            {23, 27, 31}, // Pat: 0 Zon: 0 Lay: 7
            {21, 27, 33}, // Pat: 0 Zon: 0 Lay: 8
            { 0,  0,  0}, // Pat: 0 Zon: 0 Lay: 9
            {24, 25, 26}, // Pat: 0 Zon: 0 Lay: 10
            { 8, 16, 22}, // Pat: 0 Zon: 0 Lay: 11
            { 0,  0,  0}, // Pat: 0 Zon: 0 Lay: 12
            { 0,  0,  0}, // Pat: 0 Zon: 0 Lay: 13
            { 0,  0,  0}, // Pat: 0 Zon: 0 Lay: 14
        },
        { // Zon: 1
            {10, 16, 22}, // Pat: 0 Zon: 1 Lay: 0
            { 0,  0,  0}, // Pat: 0 Zon: 1 Lay: 1
            { 0,  0,  0}, // Pat: 0 Zon: 1 Lay: 2
            {23, 26, 29}, // Pat: 0 Zon: 1 Lay: 3
            {18, 25, 30}, // Pat: 0 Zon: 1 Lay: 4
            { 0,  0,  0}, // Pat: 0 Zon: 1 Lay: 5
            { 0,  0,  0}, // Pat: 0 Zon: 1 Lay: 6
            {21, 26, 30}, // Pat: 0 Zon: 1 Lay: 7
            {17, 25, 31}, // Pat: 0 Zon: 1 Lay: 8
            { 8, 15, 20}, // Pat: 0 Zon: 1 Lay: 9
            {24, 25, 27}, // Pat: 0 Zon: 1 Lay: 10
            { 6, 13, 20}, // Pat: 0 Zon: 1 Lay: 11
            { 0,  0,  0}, // Pat: 0 Zon: 1 Lay: 12
            { 0,  0,  0}, // Pat: 0 Zon: 1 Lay: 13
            { 0,  0,  0}, // Pat: 0 Zon: 1 Lay: 14
        },
        { // Zon: 2
            {10, 16, 21}, // Pat: 0 Zon: 2 Lay: 0
            { 0,  0,  0}, // Pat: 0 Zon: 2 Lay: 1
            { 0,  0,  0}, // Pat: 0 Zon: 2 Lay: 2
            {22, 26, 28}, // Pat: 0 Zon: 2 Lay: 3
            {17, 24, 29}, // Pat: 0 Zon: 2 Lay: 4
            { 0,  0,  0}, // Pat: 0 Zon: 2 Lay: 5
            { 0,  0,  0}, // Pat: 0 Zon: 2 Lay: 6
            {20, 25, 29}, // Pat: 0 Zon: 2 Lay: 7
            {16, 24, 30}, // Pat: 0 Zon: 2 Lay: 8
            { 9, 14, 20}, // Pat: 0 Zon: 2 Lay: 9
            {24, 26, 27}, // Pat: 0 Zon: 2 Lay: 10
            { 0,  0,  0}, // Pat: 0 Zon: 2 Lay: 11
            { 0,  0,  0}, // Pat: 0 Zon: 2 Lay: 12
            { 0,  0,  0}, // Pat: 0 Zon: 2 Lay: 13
            { 0,  0,  0}, // Pat: 0 Zon: 2 Lay: 14
        },
        { // Zon: 3
            { 8, 14, 19}, // Pat: 0 Zon: 3 Lay: 0
            { 0,  0,  0}, // Pat: 0 Zon: 3 Lay: 1
            { 0,  0,  0}, // Pat: 0 Zon: 3 Lay: 2
            {22, 26, 27}, // Pat: 0 Zon: 3 Lay: 3
            {18, 24, 27}, // Pat: 0 Zon: 3 Lay: 4
            { 0,  0,  0}, // Pat: 0 Zon: 3 Lay: 5
            { 0,  0,  0}, // Pat: 0 Zon: 3 Lay: 6
            {19, 25, 27}, // Pat: 0 Zon: 3 Lay: 7
            {12, 22, 28}, // Pat: 0 Zon: 3 Lay: 8
            { 8, 13, 18}, // Pat: 0 Zon: 3 Lay: 9
            {25, 26, 27}, // Pat: 0 Zon: 3 Lay: 10
            { 0,  0,  0}, // Pat: 0 Zon: 3 Lay: 11
            { 0,  0,  0}, // Pat: 0 Zon: 3 Lay: 12
            { 0,  0,  0}, // Pat: 0 Zon: 3 Lay: 13
            { 0,  0,  0}, // Pat: 0 Zon: 3 Lay: 14
        },
        { // Zon: 4
            { 7, 14, 20}, // Pat: 0 Zon: 4 Lay: 0
            {17, 21, 25}, // Pat: 0 Zon: 4 Lay: 1
            { 0,  0,  0}, // Pat: 0 Zon: 4 Lay: 2
            {22, 26, 27}, // Pat: 0 Zon: 4 Lay: 3
            {18, 24, 27}, // Pat: 0 Zon: 4 Lay: 4
            {18, 23, 26}, // Pat: 0 Zon: 4 Lay: 5
            { 0,  0,  0}, // Pat: 0 Zon: 4 Lay: 6
            {19, 25, 27}, // Pat: 0 Zon: 4 Lay: 7
            {12, 22, 28}, // Pat: 0 Zon: 4 Lay: 8
            { 7, 13, 18}, // Pat: 0 Zon: 4 Lay: 9
            { 0,  0,  0}, // Pat: 0 Zon: 4 Lay: 10
            { 0,  0,  0}, // Pat: 0 Zon: 4 Lay: 11
            { 0,  0,  0}, // Pat: 0 Zon: 4 Lay: 12
            { 0,  0,  0}, // Pat: 0 Zon: 4 Lay: 13
            { 0,  0,  0}, // Pat: 0 Zon: 4 Lay: 14
        },
        { // Zon: 5
            { 0,  0,  0}, // Pat: 0 Zon: 5 Lay: 0
            {21, 24, 31}, // Pat: 0 Zon: 5 Lay: 1
            { 0,  0,  0}, // Pat: 0 Zon: 5 Lay: 2
            {20, 25, 27}, // Pat: 0 Zon: 5 Lay: 3
            {15, 24, 28}, // Pat: 0 Zon: 5 Lay: 4
            {21, 24, 31}, // Pat: 0 Zon: 5 Lay: 5
            {25, 26, 28}, // Pat: 0 Zon: 5 Lay: 6
            {16, 24, 28}, // Pat: 0 Zon: 5 Lay: 7
            {12, 23, 28}, // Pat: 0 Zon: 5 Lay: 8
            { 0,  0,  0}, // Pat: 0 Zon: 5 Lay: 9
            { 0,  0,  0}, // Pat: 0 Zon: 5 Lay: 10
            { 0,  0,  0}, // Pat: 0 Zon: 5 Lay: 11
            { 0,  0,  0}, // Pat: 0 Zon: 5 Lay: 12
            { 0,  0,  0}, // Pat: 0 Zon: 5 Lay: 13
            { 0,  0,  0}, // Pat: 0 Zon: 5 Lay: 14
        },
        { // Zon: 6
            { 0,  0,  0}, // Pat: 0 Zon: 6 Lay: 0
            {23, 26, 29}, // Pat: 0 Zon: 6 Lay: 1
            { 0,  0,  0}, // Pat: 0 Zon: 6 Lay: 2
            {22, 25, 27}, // Pat: 0 Zon: 6 Lay: 3
            { 0,  0,  0}, // Pat: 0 Zon: 6 Lay: 4
            {23, 26, 29}, // Pat: 0 Zon: 6 Lay: 5
            {25, 26, 28}, // Pat: 0 Zon: 6 Lay: 6
            {20, 25, 27}, // Pat: 0 Zon: 6 Lay: 7
            { 0,  0,  0}, // Pat: 0 Zon: 6 Lay: 8
            { 0,  0,  0}, // Pat: 0 Zon: 6 Lay: 9
            { 0,  0,  0}, // Pat: 0 Zon: 6 Lay: 10
            { 0,  0,  0}, // Pat: 0 Zon: 6 Lay: 11
            {18, 22, 26}, // Pat: 0 Zon: 6 Lay: 12
            {22, 25, 29}, // Pat: 0 Zon: 6 Lay: 13
            {25, 27, 30}, // Pat: 0 Zon: 6 Lay: 14
        }
    },
    { // Pat: 1
        { // Zon: 0
            {18, 21, 24}, // Pat: 1 Zon: 0 Lay: 0
            { 0,  0,  0}, // Pat: 1 Zon: 0 Lay: 1
            { 0,  0,  0}, // Pat: 1 Zon: 0 Lay: 2
            {25, 27, 29}, // Pat: 1 Zon: 0 Lay: 3
            {24, 27, 30}, // Pat: 1 Zon: 0 Lay: 4
            { 0,  0,  0}, // Pat: 1 Zon: 0 Lay: 5
            { 0,  0,  0}, // Pat: 1 Zon: 0 Lay: 6
            {25, 27, 29}, // Pat: 1 Zon: 0 Lay: 7
            {24, 27, 30}, // Pat: 1 Zon: 0 Lay: 8
            { 0,  0,  0}, // Pat: 1 Zon: 0 Lay: 9
            {25, 26, 26}, // Pat: 1 Zon: 0 Lay: 10
            {15, 20, 23}, // Pat: 1 Zon: 0 Lay: 11
            { 0,  0,  0}, // Pat: 1 Zon: 0 Lay: 12
            { 0,  0,  0}, // Pat: 1 Zon: 0 Lay: 13
            { 0,  0,  0}, // Pat: 1 Zon: 0 Lay: 14
        },
        { // Zon: 1
            {16, 20, 23}, // Pat: 1 Zon: 1 Lay: 0
            { 0,  0,  0}, // Pat: 1 Zon: 1 Lay: 1
            { 0,  0,  0}, // Pat: 1 Zon: 1 Lay: 2
            {25, 27, 28}, // Pat: 1 Zon: 1 Lay: 3
            {24, 26, 29}, // Pat: 1 Zon: 1 Lay: 4
            { 0,  0,  0}, // Pat: 1 Zon: 1 Lay: 5
            { 0,  0,  0}, // Pat: 1 Zon: 1 Lay: 6
            {25, 27, 29}, // Pat: 1 Zon: 1 Lay: 7
            {23, 26, 30}, // Pat: 1 Zon: 1 Lay: 8
            {14, 19, 22}, // Pat: 1 Zon: 1 Lay: 9
            {24, 26, 26}, // Pat: 1 Zon: 1 Lay: 10
            {13, 18, 22}, // Pat: 1 Zon: 1 Lay: 11
            { 0,  0,  0}, // Pat: 1 Zon: 1 Lay: 12
            { 0,  0,  0}, // Pat: 1 Zon: 1 Lay: 13
            { 0,  0,  0}, // Pat: 1 Zon: 1 Lay: 14
        },
        { // Zon: 2
            {15, 19, 22}, // Pat: 1 Zon: 2 Lay: 0
            { 0,  0,  0}, // Pat: 1 Zon: 2 Lay: 1
            { 0,  0,  0}, // Pat: 1 Zon: 2 Lay: 2
            {25, 26, 28}, // Pat: 1 Zon: 2 Lay: 3
            {23, 26, 29}, // Pat: 1 Zon: 2 Lay: 4
            { 0,  0,  0}, // Pat: 1 Zon: 2 Lay: 5
            { 0,  0,  0}, // Pat: 1 Zon: 2 Lay: 6
            {24, 26, 28}, // Pat: 1 Zon: 2 Lay: 7
            {23, 26, 29}, // Pat: 1 Zon: 2 Lay: 8
            {14, 18, 21}, // Pat: 1 Zon: 2 Lay: 9
            {25, 26, 26}, // Pat: 1 Zon: 2 Lay: 10
            { 0,  0,  0}, // Pat: 1 Zon: 2 Lay: 11
            { 0,  0,  0}, // Pat: 1 Zon: 2 Lay: 12
            { 0,  0,  0}, // Pat: 1 Zon: 2 Lay: 13
            { 0,  0,  0}, // Pat: 1 Zon: 2 Lay: 14
        },
        { // Zon: 3
            {14, 18, 21}, // Pat: 1 Zon: 3 Lay: 0
            { 0,  0,  0}, // Pat: 1 Zon: 3 Lay: 1
            { 0,  0,  0}, // Pat: 1 Zon: 3 Lay: 2
            {25, 26, 27}, // Pat: 1 Zon: 3 Lay: 3
            {23, 26, 28}, // Pat: 1 Zon: 3 Lay: 4
            { 0,  0,  0}, // Pat: 1 Zon: 3 Lay: 5
            { 0,  0,  0}, // Pat: 1 Zon: 3 Lay: 6
            {24, 26, 28}, // Pat: 1 Zon: 3 Lay: 7
            {21, 25, 28}, // Pat: 1 Zon: 3 Lay: 8
            {12, 16, 20}, // Pat: 1 Zon: 3 Lay: 9
            {25, 26, 26}, // Pat: 1 Zon: 3 Lay: 10
            { 0,  0,  0}, // Pat: 1 Zon: 3 Lay: 11
            { 0,  0,  0}, // Pat: 1 Zon: 3 Lay: 12
            { 0,  0,  0}, // Pat: 1 Zon: 3 Lay: 13
            { 0,  0,  0}, // Pat: 1 Zon: 3 Lay: 14
        },
        { // Zon: 4
            {13, 18, 21}, // Pat: 1 Zon: 4 Lay: 0
            {20, 22, 24}, // Pat: 1 Zon: 4 Lay: 1
            { 0,  0,  0}, // Pat: 1 Zon: 4 Lay: 2
            {25, 26, 27}, // Pat: 1 Zon: 4 Lay: 3
            {23, 26, 28}, // Pat: 1 Zon: 4 Lay: 4
            {20, 23, 25}, // Pat: 1 Zon: 4 Lay: 5
            { 0,  0,  0}, // Pat: 1 Zon: 4 Lay: 6
            {24, 26, 28}, // Pat: 1 Zon: 4 Lay: 7
            {21, 25, 28}, // Pat: 1 Zon: 4 Lay: 8
            {11, 16, 20}, // Pat: 1 Zon: 4 Lay: 9
            { 0,  0,  0}, // Pat: 1 Zon: 4 Lay: 10
            { 0,  0,  0}, // Pat: 1 Zon: 4 Lay: 11
            { 0,  0,  0}, // Pat: 1 Zon: 4 Lay: 12
            { 0,  0,  0}, // Pat: 1 Zon: 4 Lay: 13
            { 0,  0,  0}, // Pat: 1 Zon: 4 Lay: 14
        },
        { // Zon: 5
            { 0,  0,  0}, // Pat: 1 Zon: 5 Lay: 0
            {23, 24, 26}, // Pat: 1 Zon: 5 Lay: 1
            { 0,  0,  0}, // Pat: 1 Zon: 5 Lay: 2
            {24, 26, 27}, // Pat: 1 Zon: 5 Lay: 3
            {22, 26, 27}, // Pat: 1 Zon: 5 Lay: 4
            {23, 24, 26}, // Pat: 1 Zon: 5 Lay: 5
            {25, 26, 27}, // Pat: 1 Zon: 5 Lay: 6
            {23, 26, 27}, // Pat: 1 Zon: 5 Lay: 7
            {22, 25, 28}, // Pat: 1 Zon: 5 Lay: 8
            { 0,  0,  0}, // Pat: 1 Zon: 5 Lay: 9
            { 0,  0,  0}, // Pat: 1 Zon: 5 Lay: 10
            { 0,  0,  0}, // Pat: 1 Zon: 5 Lay: 11
            { 0,  0,  0}, // Pat: 1 Zon: 5 Lay: 12
            { 0,  0,  0}, // Pat: 1 Zon: 5 Lay: 13
            { 0,  0,  0}, // Pat: 1 Zon: 5 Lay: 14
        },
        { // Zon: 6
            { 0,  0,  0}, // Pat: 1 Zon: 6 Lay: 0
            {24, 25, 26}, // Pat: 1 Zon: 6 Lay: 1
            { 0,  0,  0}, // Pat: 1 Zon: 6 Lay: 2
            {25, 26, 27}, // Pat: 1 Zon: 6 Lay: 3
            { 0,  0,  0}, // Pat: 1 Zon: 6 Lay: 4
            {24, 25, 26}, // Pat: 1 Zon: 6 Lay: 5
            {25, 26, 27}, // Pat: 1 Zon: 6 Lay: 6
            {25, 26, 27}, // Pat: 1 Zon: 6 Lay: 7
            { 0,  0,  0}, // Pat: 1 Zon: 6 Lay: 8
            { 0,  0,  0}, // Pat: 1 Zon: 6 Lay: 9
            { 0,  0,  0}, // Pat: 1 Zon: 6 Lay: 10
            { 0,  0,  0}, // Pat: 1 Zon: 6 Lay: 11
            {20, 23, 25}, // Pat: 1 Zon: 6 Lay: 12
            {23, 24, 26}, // Pat: 1 Zon: 6 Lay: 13
            {25, 26, 28}, // Pat: 1 Zon: 6 Lay: 14
        }
    },
    { // Pat: 2
        { // Zon: 0
            {21, 23, 25}, // Pat: 2 Zon: 0 Lay: 0
            { 0,  0,  0}, // Pat: 2 Zon: 0 Lay: 1
            { 0,  0,  0}, // Pat: 2 Zon: 0 Lay: 2
            {26, 27, 28}, // Pat: 2 Zon: 0 Lay: 3
            {25, 27, 28}, // Pat: 2 Zon: 0 Lay: 4
            { 0,  0,  0}, // Pat: 2 Zon: 0 Lay: 5
            { 0,  0,  0}, // Pat: 2 Zon: 0 Lay: 6
            {25, 27, 28}, // Pat: 2 Zon: 0 Lay: 7
            {25, 27, 29}, // Pat: 2 Zon: 0 Lay: 8
            { 0,  0,  0}, // Pat: 2 Zon: 0 Lay: 9
            {25, 26, 26}, // Pat: 2 Zon: 0 Lay: 10
            {19, 22, 24}, // Pat: 2 Zon: 0 Lay: 11
            { 0,  0,  0}, // Pat: 2 Zon: 0 Lay: 12
            { 0,  0,  0}, // Pat: 2 Zon: 0 Lay: 13
            { 0,  0,  0}, // Pat: 2 Zon: 0 Lay: 14
        },
        { // Zon: 1
            {20, 22, 24}, // Pat: 2 Zon: 1 Lay: 0
            { 0,  0,  0}, // Pat: 2 Zon: 1 Lay: 1
            { 0,  0,  0}, // Pat: 2 Zon: 1 Lay: 2
            {26, 26, 28}, // Pat: 2 Zon: 1 Lay: 3
            {25, 27, 28}, // Pat: 2 Zon: 1 Lay: 4
            { 0,  0,  0}, // Pat: 2 Zon: 1 Lay: 5
            { 0,  0,  0}, // Pat: 2 Zon: 1 Lay: 6
            {25, 27, 28}, // Pat: 2 Zon: 1 Lay: 7
            {25, 27, 28}, // Pat: 2 Zon: 1 Lay: 8
            {19, 21, 24}, // Pat: 2 Zon: 1 Lay: 9
            {25, 26, 26}, // Pat: 2 Zon: 1 Lay: 10
            {18, 21, 23}, // Pat: 2 Zon: 1 Lay: 11
            { 0,  0,  0}, // Pat: 2 Zon: 1 Lay: 12
            { 0,  0,  0}, // Pat: 2 Zon: 1 Lay: 13
            { 0,  0,  0}, // Pat: 2 Zon: 1 Lay: 14
        },
        { // Zon: 2
            {19, 22, 24}, // Pat: 2 Zon: 2 Lay: 0
            { 0,  0,  0}, // Pat: 2 Zon: 2 Lay: 1
            { 0,  0,  0}, // Pat: 2 Zon: 2 Lay: 2
            {26, 26, 27}, // Pat: 2 Zon: 2 Lay: 3
            {25, 26, 28}, // Pat: 2 Zon: 2 Lay: 4
            { 0,  0,  0}, // Pat: 2 Zon: 2 Lay: 5
            { 0,  0,  0}, // Pat: 2 Zon: 2 Lay: 6
            {25, 26, 28}, // Pat: 2 Zon: 2 Lay: 7
            {25, 26, 28}, // Pat: 2 Zon: 2 Lay: 8
            {18, 21, 23}, // Pat: 2 Zon: 2 Lay: 9
            {25, 26, 26}, // Pat: 2 Zon: 2 Lay: 10
            { 0,  0,  0}, // Pat: 2 Zon: 2 Lay: 11
            { 0,  0,  0}, // Pat: 2 Zon: 2 Lay: 12
            { 0,  0,  0}, // Pat: 2 Zon: 2 Lay: 13
            { 0,  0,  0}, // Pat: 2 Zon: 2 Lay: 14
        },
        { // Zon: 3
            {18, 21, 23}, // Pat: 2 Zon: 3 Lay: 0
            { 0,  0,  0}, // Pat: 2 Zon: 3 Lay: 1
            { 0,  0,  0}, // Pat: 2 Zon: 3 Lay: 2
            {26, 26, 27}, // Pat: 2 Zon: 3 Lay: 3
            {25, 26, 27}, // Pat: 2 Zon: 3 Lay: 4
            { 0,  0,  0}, // Pat: 2 Zon: 3 Lay: 5
            { 0,  0,  0}, // Pat: 2 Zon: 3 Lay: 6
            {25, 26, 27}, // Pat: 2 Zon: 3 Lay: 7
            {24, 26, 28}, // Pat: 2 Zon: 3 Lay: 8
            {17, 20, 22}, // Pat: 2 Zon: 3 Lay: 9
            {25, 26, 26}, // Pat: 2 Zon: 3 Lay: 10
            { 0,  0,  0}, // Pat: 2 Zon: 3 Lay: 11
            { 0,  0,  0}, // Pat: 2 Zon: 3 Lay: 12
            { 0,  0,  0}, // Pat: 2 Zon: 3 Lay: 13
            { 0,  0,  0}, // Pat: 2 Zon: 3 Lay: 14
        },
        { // Zon: 4
            {18, 21, 23}, // Pat: 2 Zon: 4 Lay: 0
            {22, 24, 25}, // Pat: 2 Zon: 4 Lay: 1
            { 0,  0,  0}, // Pat: 2 Zon: 4 Lay: 2
            {26, 26, 27}, // Pat: 2 Zon: 4 Lay: 3
            {25, 26, 27}, // Pat: 2 Zon: 4 Lay: 4
            {22, 24, 25}, // Pat: 2 Zon: 4 Lay: 5
            { 0,  0,  0}, // Pat: 2 Zon: 4 Lay: 6
            {25, 26, 27}, // Pat: 2 Zon: 4 Lay: 7
            {24, 26, 28}, // Pat: 2 Zon: 4 Lay: 8
            {17, 20, 22}, // Pat: 2 Zon: 4 Lay: 9
            { 0,  0,  0}, // Pat: 2 Zon: 4 Lay: 10
            { 0,  0,  0}, // Pat: 2 Zon: 4 Lay: 11
            { 0,  0,  0}, // Pat: 2 Zon: 4 Lay: 12
            { 0,  0,  0}, // Pat: 2 Zon: 4 Lay: 13
            { 0,  0,  0}, // Pat: 2 Zon: 4 Lay: 14
        },
        { // Zon: 5
            { 0,  0,  0}, // Pat: 2 Zon: 5 Lay: 0
            {24, 25, 26}, // Pat: 2 Zon: 5 Lay: 1
            { 0,  0,  0}, // Pat: 2 Zon: 5 Lay: 2
            {26, 26, 27}, // Pat: 2 Zon: 5 Lay: 3
            {25, 26, 27}, // Pat: 2 Zon: 5 Lay: 4
            {24, 25, 26}, // Pat: 2 Zon: 5 Lay: 5
            {25, 26, 26}, // Pat: 2 Zon: 5 Lay: 6
            {25, 26, 27}, // Pat: 2 Zon: 5 Lay: 7
            {25, 26, 27}, // Pat: 2 Zon: 5 Lay: 8
            { 0,  0,  0}, // Pat: 2 Zon: 5 Lay: 9
            { 0,  0,  0}, // Pat: 2 Zon: 5 Lay: 10
            { 0,  0,  0}, // Pat: 2 Zon: 5 Lay: 11
            { 0,  0,  0}, // Pat: 2 Zon: 5 Lay: 12
            { 0,  0,  0}, // Pat: 2 Zon: 5 Lay: 13
            { 0,  0,  0}, // Pat: 2 Zon: 5 Lay: 14
        },
        { // Zon: 6
            { 0,  0,  0}, // Pat: 2 Zon: 6 Lay: 0
            {24, 25, 27}, // Pat: 2 Zon: 6 Lay: 1
            { 0,  0,  0}, // Pat: 2 Zon: 6 Lay: 2
            {25, 26, 27}, // Pat: 2 Zon: 6 Lay: 3
            { 0,  0,  0}, // Pat: 2 Zon: 6 Lay: 4
            {24, 26, 27}, // Pat: 2 Zon: 6 Lay: 5
            {25, 26, 27}, // Pat: 2 Zon: 6 Lay: 6
            {25, 26, 27}, // Pat: 2 Zon: 6 Lay: 7
            { 0,  0,  0}, // Pat: 2 Zon: 6 Lay: 8
            { 0,  0,  0}, // Pat: 2 Zon: 6 Lay: 9
            { 0,  0,  0}, // Pat: 2 Zon: 6 Lay: 10
            { 0,  0,  0}, // Pat: 2 Zon: 6 Lay: 11
            {22, 24, 25}, // Pat: 2 Zon: 6 Lay: 12
            {24, 25, 26}, // Pat: 2 Zon: 6 Lay: 13
            {25, 26, 27}, // Pat: 2 Zon: 6 Lay: 14
        }
    },
    { // Pat: 3
        { // Zon: 0
            {23, 25, 27}, // Pat: 3 Zon: 0 Lay: 0
            { 0,  0,  0}, // Pat: 3 Zon: 0 Lay: 1
            { 0,  0,  0}, // Pat: 3 Zon: 0 Lay: 2
            {26, 26, 27}, // Pat: 3 Zon: 0 Lay: 3
            {26, 26, 27}, // Pat: 3 Zon: 0 Lay: 4
            { 0,  0,  0}, // Pat: 3 Zon: 0 Lay: 5
            { 0,  0,  0}, // Pat: 3 Zon: 0 Lay: 6
            {26, 26, 27}, // Pat: 3 Zon: 0 Lay: 7
            {25, 26, 27}, // Pat: 3 Zon: 0 Lay: 8
            { 0,  0,  0}, // Pat: 3 Zon: 0 Lay: 9
            {25, 26, 26}, // Pat: 3 Zon: 0 Lay: 10
            {22, 25, 27}, // Pat: 3 Zon: 0 Lay: 11
            { 0,  0,  0}, // Pat: 3 Zon: 0 Lay: 12
            { 0,  0,  0}, // Pat: 3 Zon: 0 Lay: 13
            { 0,  0,  0}, // Pat: 3 Zon: 0 Lay: 14
        },
        { // Zon: 1
            {22, 25, 27}, // Pat: 3 Zon: 1 Lay: 0
            { 0,  0,  0}, // Pat: 3 Zon: 1 Lay: 1
            { 0,  0,  0}, // Pat: 3 Zon: 1 Lay: 2
            {26, 26, 27}, // Pat: 3 Zon: 1 Lay: 3
            {26, 26, 27}, // Pat: 3 Zon: 1 Lay: 4
            { 0,  0,  0}, // Pat: 3 Zon: 1 Lay: 5
            { 0,  0,  0}, // Pat: 3 Zon: 1 Lay: 6
            {26, 26, 27}, // Pat: 3 Zon: 1 Lay: 7
            {25, 26, 27}, // Pat: 3 Zon: 1 Lay: 8
            {22, 25, 27}, // Pat: 3 Zon: 1 Lay: 9
            {25, 26, 26}, // Pat: 3 Zon: 1 Lay: 10
            {22, 25, 27}, // Pat: 3 Zon: 1 Lay: 11
            { 0,  0,  0}, // Pat: 3 Zon: 1 Lay: 12
            { 0,  0,  0}, // Pat: 3 Zon: 1 Lay: 13
            { 0,  0,  0}, // Pat: 3 Zon: 1 Lay: 14
        },
        { // Zon: 2
            {22, 25, 27}, // Pat: 3 Zon: 2 Lay: 0
            { 0,  0,  0}, // Pat: 3 Zon: 2 Lay: 1
            { 0,  0,  0}, // Pat: 3 Zon: 2 Lay: 2
            {26, 26, 27}, // Pat: 3 Zon: 2 Lay: 3
            {26, 26, 27}, // Pat: 3 Zon: 2 Lay: 4
            { 0,  0,  0}, // Pat: 3 Zon: 2 Lay: 5
            { 0,  0,  0}, // Pat: 3 Zon: 2 Lay: 6
            {26, 26, 27}, // Pat: 3 Zon: 2 Lay: 7
            {25, 26, 27}, // Pat: 3 Zon: 2 Lay: 8
            {22, 24, 27}, // Pat: 3 Zon: 2 Lay: 9
            {25, 26, 26}, // Pat: 3 Zon: 2 Lay: 10
            { 0,  0,  0}, // Pat: 3 Zon: 2 Lay: 11
            { 0,  0,  0}, // Pat: 3 Zon: 2 Lay: 12
            { 0,  0,  0}, // Pat: 3 Zon: 2 Lay: 13
            { 0,  0,  0}, // Pat: 3 Zon: 2 Lay: 14
        },
        { // Zon: 3
            {22, 24, 27}, // Pat: 3 Zon: 3 Lay: 0
            { 0,  0,  0}, // Pat: 3 Zon: 3 Lay: 1
            { 0,  0,  0}, // Pat: 3 Zon: 3 Lay: 2
            {26, 26, 27}, // Pat: 3 Zon: 3 Lay: 3
            {26, 26, 27}, // Pat: 3 Zon: 3 Lay: 4
            { 0,  0,  0}, // Pat: 3 Zon: 3 Lay: 5
            { 0,  0,  0}, // Pat: 3 Zon: 3 Lay: 6
            {25, 26, 27}, // Pat: 3 Zon: 3 Lay: 7
            {25, 26, 27}, // Pat: 3 Zon: 3 Lay: 8
            {21, 24, 27}, // Pat: 3 Zon: 3 Lay: 9
            {25, 26, 26}, // Pat: 3 Zon: 3 Lay: 10
            { 0,  0,  0}, // Pat: 3 Zon: 3 Lay: 11
            { 0,  0,  0}, // Pat: 3 Zon: 3 Lay: 12
            { 0,  0,  0}, // Pat: 3 Zon: 3 Lay: 13
            { 0,  0,  0}, // Pat: 3 Zon: 3 Lay: 14
        },
        { // Zon: 4
            {22, 24, 27}, // Pat: 3 Zon: 4 Lay: 0
            {24, 25, 26}, // Pat: 3 Zon: 4 Lay: 1
            { 0,  0,  0}, // Pat: 3 Zon: 4 Lay: 2
            {26, 26, 27}, // Pat: 3 Zon: 4 Lay: 3
            {26, 26, 27}, // Pat: 3 Zon: 4 Lay: 4
            {24, 25, 27}, // Pat: 3 Zon: 4 Lay: 5
            { 0,  0,  0}, // Pat: 3 Zon: 4 Lay: 6
            {25, 26, 27}, // Pat: 3 Zon: 4 Lay: 7
            {25, 26, 27}, // Pat: 3 Zon: 4 Lay: 8
            {21, 24, 27}, // Pat: 3 Zon: 4 Lay: 9
            { 0,  0,  0}, // Pat: 3 Zon: 4 Lay: 10
            { 0,  0,  0}, // Pat: 3 Zon: 4 Lay: 11
            { 0,  0,  0}, // Pat: 3 Zon: 4 Lay: 12
            { 0,  0,  0}, // Pat: 3 Zon: 4 Lay: 13
            { 0,  0,  0}, // Pat: 3 Zon: 4 Lay: 14
        },
        { // Zon: 5
            { 0,  0,  0}, // Pat: 3 Zon: 5 Lay: 0
            {25, 26, 26}, // Pat: 3 Zon: 5 Lay: 1
            { 0,  0,  0}, // Pat: 3 Zon: 5 Lay: 2
            {26, 26, 27}, // Pat: 3 Zon: 5 Lay: 3
            {26, 26, 27}, // Pat: 3 Zon: 5 Lay: 4
            {25, 26, 27}, // Pat: 3 Zon: 5 Lay: 5
            {25, 26, 26}, // Pat: 3 Zon: 5 Lay: 6
            {25, 26, 27}, // Pat: 3 Zon: 5 Lay: 7
            {25, 26, 27}, // Pat: 3 Zon: 5 Lay: 8
            { 0,  0,  0}, // Pat: 3 Zon: 5 Lay: 9
            { 0,  0,  0}, // Pat: 3 Zon: 5 Lay: 10
            { 0,  0,  0}, // Pat: 3 Zon: 5 Lay: 11
            { 0,  0,  0}, // Pat: 3 Zon: 5 Lay: 12
            { 0,  0,  0}, // Pat: 3 Zon: 5 Lay: 13
            { 0,  0,  0}, // Pat: 3 Zon: 5 Lay: 14
        },
        { // Zon: 6
            { 0,  0,  0}, // Pat: 3 Zon: 6 Lay: 0
            {25, 26, 27}, // Pat: 3 Zon: 6 Lay: 1
            { 0,  0,  0}, // Pat: 3 Zon: 6 Lay: 2
            {26, 26, 27}, // Pat: 3 Zon: 6 Lay: 3
            { 0,  0,  0}, // Pat: 3 Zon: 6 Lay: 4
            {25, 26, 27}, // Pat: 3 Zon: 6 Lay: 5
            {25, 26, 27}, // Pat: 3 Zon: 6 Lay: 6
            {25, 26, 27}, // Pat: 3 Zon: 6 Lay: 7
            { 0,  0,  0}, // Pat: 3 Zon: 6 Lay: 8
            { 0,  0,  0}, // Pat: 3 Zon: 6 Lay: 9
            { 0,  0,  0}, // Pat: 3 Zon: 6 Lay: 10
            { 0,  0,  0}, // Pat: 3 Zon: 6 Lay: 11
            {24, 25, 27}, // Pat: 3 Zon: 6 Lay: 12
            {25, 26, 26}, // Pat: 3 Zon: 6 Lay: 13
            {25, 26, 27}, // Pat: 3 Zon: 6 Lay: 14
        }
    },
    { // Pat: 4
        { // Zon: 0
            {24, 26, 28}, // Pat: 4 Zon: 0 Lay: 0
            { 0,  0,  0}, // Pat: 4 Zon: 0 Lay: 1
            { 0,  0,  0}, // Pat: 4 Zon: 0 Lay: 2
            {25, 26, 27}, // Pat: 4 Zon: 0 Lay: 3
            {25, 26, 27}, // Pat: 4 Zon: 0 Lay: 4
            { 0,  0,  0}, // Pat: 4 Zon: 0 Lay: 5
            { 0,  0,  0}, // Pat: 4 Zon: 0 Lay: 6
            {25, 26, 27}, // Pat: 4 Zon: 0 Lay: 7
            {25, 26, 27}, // Pat: 4 Zon: 0 Lay: 8
            { 0,  0,  0}, // Pat: 4 Zon: 0 Lay: 9
            {25, 26, 27}, // Pat: 4 Zon: 0 Lay: 10
            {24, 26, 28}, // Pat: 4 Zon: 0 Lay: 11
            { 0,  0,  0}, // Pat: 4 Zon: 0 Lay: 12
            { 0,  0,  0}, // Pat: 4 Zon: 0 Lay: 13
            { 0,  0,  0}, // Pat: 4 Zon: 0 Lay: 14
        },
        { // Zon: 1
            {24, 26, 28}, // Pat: 4 Zon: 1 Lay: 0
            { 0,  0,  0}, // Pat: 4 Zon: 1 Lay: 1
            { 0,  0,  0}, // Pat: 4 Zon: 1 Lay: 2
            {25, 26, 27}, // Pat: 4 Zon: 1 Lay: 3
            {25, 26, 27}, // Pat: 4 Zon: 1 Lay: 4
            { 0,  0,  0}, // Pat: 4 Zon: 1 Lay: 5
            { 0,  0,  0}, // Pat: 4 Zon: 1 Lay: 6
            {25, 26, 27}, // Pat: 4 Zon: 1 Lay: 7
            {25, 26, 27}, // Pat: 4 Zon: 1 Lay: 8
            {24, 26, 28}, // Pat: 4 Zon: 1 Lay: 9
            {25, 26, 27}, // Pat: 4 Zon: 1 Lay: 10
            {23, 26, 29}, // Pat: 4 Zon: 1 Lay: 11
            { 0,  0,  0}, // Pat: 4 Zon: 1 Lay: 12
            { 0,  0,  0}, // Pat: 4 Zon: 1 Lay: 13
            { 0,  0,  0}, // Pat: 4 Zon: 1 Lay: 14
        },
        { // Zon: 2
            {24, 26, 28}, // Pat: 4 Zon: 2 Lay: 0
            { 0,  0,  0}, // Pat: 4 Zon: 2 Lay: 1
            { 0,  0,  0}, // Pat: 4 Zon: 2 Lay: 2
            {25, 26, 27}, // Pat: 4 Zon: 2 Lay: 3
            {25, 26, 27}, // Pat: 4 Zon: 2 Lay: 4
            { 0,  0,  0}, // Pat: 4 Zon: 2 Lay: 5
            { 0,  0,  0}, // Pat: 4 Zon: 2 Lay: 6
            {25, 26, 27}, // Pat: 4 Zon: 2 Lay: 7
            {25, 26, 27}, // Pat: 4 Zon: 2 Lay: 8
            {23, 26, 29}, // Pat: 4 Zon: 2 Lay: 9
            {25, 26, 27}, // Pat: 4 Zon: 2 Lay: 10
            { 0,  0,  0}, // Pat: 4 Zon: 2 Lay: 11
            { 0,  0,  0}, // Pat: 4 Zon: 2 Lay: 12
            { 0,  0,  0}, // Pat: 4 Zon: 2 Lay: 13
            { 0,  0,  0}, // Pat: 4 Zon: 2 Lay: 14
        },
        { // Zon: 3
            {23, 26, 29}, // Pat: 4 Zon: 3 Lay: 0
            { 0,  0,  0}, // Pat: 4 Zon: 3 Lay: 1
            { 0,  0,  0}, // Pat: 4 Zon: 3 Lay: 2
            {25, 26, 27}, // Pat: 4 Zon: 3 Lay: 3
            {25, 26, 27}, // Pat: 4 Zon: 3 Lay: 4
            { 0,  0,  0}, // Pat: 4 Zon: 3 Lay: 5
            { 0,  0,  0}, // Pat: 4 Zon: 3 Lay: 6
            {25, 26, 27}, // Pat: 4 Zon: 3 Lay: 7
            {25, 26, 27}, // Pat: 4 Zon: 3 Lay: 8
            {23, 26, 29}, // Pat: 4 Zon: 3 Lay: 9
            {25, 26, 27}, // Pat: 4 Zon: 3 Lay: 10
            { 0,  0,  0}, // Pat: 4 Zon: 3 Lay: 11
            { 0,  0,  0}, // Pat: 4 Zon: 3 Lay: 12
            { 0,  0,  0}, // Pat: 4 Zon: 3 Lay: 13
            { 0,  0,  0}, // Pat: 4 Zon: 3 Lay: 14
        },
        { // Zon: 4
            {23, 26, 29}, // Pat: 4 Zon: 4 Lay: 0
            {25, 26, 27}, // Pat: 4 Zon: 4 Lay: 1
            { 0,  0,  0}, // Pat: 4 Zon: 4 Lay: 2
            {25, 26, 27}, // Pat: 4 Zon: 4 Lay: 3
            {25, 26, 27}, // Pat: 4 Zon: 4 Lay: 4
            {25, 26, 27}, // Pat: 4 Zon: 4 Lay: 5
            { 0,  0,  0}, // Pat: 4 Zon: 4 Lay: 6
            {25, 26, 27}, // Pat: 4 Zon: 4 Lay: 7
            {25, 26, 27}, // Pat: 4 Zon: 4 Lay: 8
            {23, 26, 29}, // Pat: 4 Zon: 4 Lay: 9
            { 0,  0,  0}, // Pat: 4 Zon: 4 Lay: 10
            { 0,  0,  0}, // Pat: 4 Zon: 4 Lay: 11
            { 0,  0,  0}, // Pat: 4 Zon: 4 Lay: 12
            { 0,  0,  0}, // Pat: 4 Zon: 4 Lay: 13
            { 0,  0,  0}, // Pat: 4 Zon: 4 Lay: 14
        },
        { // Zon: 5
            { 0,  0,  0}, // Pat: 4 Zon: 5 Lay: 0
            {25, 26, 27}, // Pat: 4 Zon: 5 Lay: 1
            { 0,  0,  0}, // Pat: 4 Zon: 5 Lay: 2
            {25, 26, 27}, // Pat: 4 Zon: 5 Lay: 3
            {25, 26, 27}, // Pat: 4 Zon: 5 Lay: 4
            {25, 26, 27}, // Pat: 4 Zon: 5 Lay: 5
            {25, 26, 27}, // Pat: 4 Zon: 5 Lay: 6
            {25, 26, 27}, // Pat: 4 Zon: 5 Lay: 7
            {25, 26, 27}, // Pat: 4 Zon: 5 Lay: 8
            { 0,  0,  0}, // Pat: 4 Zon: 5 Lay: 9
            { 0,  0,  0}, // Pat: 4 Zon: 5 Lay: 10
            { 0,  0,  0}, // Pat: 4 Zon: 5 Lay: 11
            { 0,  0,  0}, // Pat: 4 Zon: 5 Lay: 12
            { 0,  0,  0}, // Pat: 4 Zon: 5 Lay: 13
            { 0,  0,  0}, // Pat: 4 Zon: 5 Lay: 14
        },
        { // Zon: 6
            { 0,  0,  0}, // Pat: 4 Zon: 6 Lay: 0
            {25, 26, 27}, // Pat: 4 Zon: 6 Lay: 1
            { 0,  0,  0}, // Pat: 4 Zon: 6 Lay: 2
            {25, 26, 27}, // Pat: 4 Zon: 6 Lay: 3
            { 0,  0,  0}, // Pat: 4 Zon: 6 Lay: 4
            {25, 26, 27}, // Pat: 4 Zon: 6 Lay: 5
            {25, 26, 27}, // Pat: 4 Zon: 6 Lay: 6
            {25, 26, 27}, // Pat: 4 Zon: 6 Lay: 7
            { 0,  0,  0}, // Pat: 4 Zon: 6 Lay: 8
            { 0,  0,  0}, // Pat: 4 Zon: 6 Lay: 9
            { 0,  0,  0}, // Pat: 4 Zon: 6 Lay: 10
            { 0,  0,  0}, // Pat: 4 Zon: 6 Lay: 11
            {25, 26, 27}, // Pat: 4 Zon: 6 Lay: 12
            {25, 26, 27}, // Pat: 4 Zon: 6 Lay: 13
            {25, 26, 27}, // Pat: 4 Zon: 6 Lay: 14
        }
    },
    { // Pat: 5
        { // Zon: 0
            {25, 27, 29}, // Pat: 5 Zon: 0 Lay: 0
            { 0,  0,  0}, // Pat: 5 Zon: 0 Lay: 1
            { 0,  0,  0}, // Pat: 5 Zon: 0 Lay: 2
            {25, 26, 26}, // Pat: 5 Zon: 0 Lay: 3
            {25, 26, 26}, // Pat: 5 Zon: 0 Lay: 4
            { 0,  0,  0}, // Pat: 5 Zon: 0 Lay: 5
            { 0,  0,  0}, // Pat: 5 Zon: 0 Lay: 6
            {25, 26, 26}, // Pat: 5 Zon: 0 Lay: 7
            {25, 26, 27}, // Pat: 5 Zon: 0 Lay: 8
            { 0,  0,  0}, // Pat: 5 Zon: 0 Lay: 9
            {26, 26, 27}, // Pat: 5 Zon: 0 Lay: 10
            {25, 27, 30}, // Pat: 5 Zon: 0 Lay: 11
            { 0,  0,  0}, // Pat: 5 Zon: 0 Lay: 12
            { 0,  0,  0}, // Pat: 5 Zon: 0 Lay: 13
            { 0,  0,  0}, // Pat: 5 Zon: 0 Lay: 14
        },
        { // Zon: 1
            {25, 27, 30}, // Pat: 5 Zon: 1 Lay: 0
            { 0,  0,  0}, // Pat: 5 Zon: 1 Lay: 1
            { 0,  0,  0}, // Pat: 5 Zon: 1 Lay: 2
            {25, 26, 26}, // Pat: 5 Zon: 1 Lay: 3
            {25, 26, 26}, // Pat: 5 Zon: 1 Lay: 4
            { 0,  0,  0}, // Pat: 5 Zon: 1 Lay: 5
            { 0,  0,  0}, // Pat: 5 Zon: 1 Lay: 6
            {25, 26, 26}, // Pat: 5 Zon: 1 Lay: 7
            {25, 26, 27}, // Pat: 5 Zon: 1 Lay: 8
            {25, 27, 30}, // Pat: 5 Zon: 1 Lay: 9
            {26, 26, 27}, // Pat: 5 Zon: 1 Lay: 10
            {25, 27, 30}, // Pat: 5 Zon: 1 Lay: 11
            { 0,  0,  0}, // Pat: 5 Zon: 1 Lay: 12
            { 0,  0,  0}, // Pat: 5 Zon: 1 Lay: 13
            { 0,  0,  0}, // Pat: 5 Zon: 1 Lay: 14
        },
        { // Zon: 2
            {25, 27, 30}, // Pat: 5 Zon: 2 Lay: 0
            { 0,  0,  0}, // Pat: 5 Zon: 2 Lay: 1
            { 0,  0,  0}, // Pat: 5 Zon: 2 Lay: 2
            {25, 26, 26}, // Pat: 5 Zon: 2 Lay: 3
            {25, 26, 26}, // Pat: 5 Zon: 2 Lay: 4
            { 0,  0,  0}, // Pat: 5 Zon: 2 Lay: 5
            { 0,  0,  0}, // Pat: 5 Zon: 2 Lay: 6
            {25, 26, 26}, // Pat: 5 Zon: 2 Lay: 7
            {25, 26, 27}, // Pat: 5 Zon: 2 Lay: 8
            {25, 28, 30}, // Pat: 5 Zon: 2 Lay: 9
            {26, 26, 27}, // Pat: 5 Zon: 2 Lay: 10
            { 0,  0,  0}, // Pat: 5 Zon: 2 Lay: 11
            { 0,  0,  0}, // Pat: 5 Zon: 2 Lay: 12
            { 0,  0,  0}, // Pat: 5 Zon: 2 Lay: 13
            { 0,  0,  0}, // Pat: 5 Zon: 2 Lay: 14
        },
        { // Zon: 3
            {25, 28, 30}, // Pat: 5 Zon: 3 Lay: 0
            { 0,  0,  0}, // Pat: 5 Zon: 3 Lay: 1
            { 0,  0,  0}, // Pat: 5 Zon: 3 Lay: 2
            {25, 26, 26}, // Pat: 5 Zon: 3 Lay: 3
            {25, 26, 26}, // Pat: 5 Zon: 3 Lay: 4
            { 0,  0,  0}, // Pat: 5 Zon: 3 Lay: 5
            { 0,  0,  0}, // Pat: 5 Zon: 3 Lay: 6
            {25, 26, 27}, // Pat: 5 Zon: 3 Lay: 7
            {25, 26, 27}, // Pat: 5 Zon: 3 Lay: 8
            {25, 28, 31}, // Pat: 5 Zon: 3 Lay: 9
            {26, 26, 27}, // Pat: 5 Zon: 3 Lay: 10
            { 0,  0,  0}, // Pat: 5 Zon: 3 Lay: 11
            { 0,  0,  0}, // Pat: 5 Zon: 3 Lay: 12
            { 0,  0,  0}, // Pat: 5 Zon: 3 Lay: 13
            { 0,  0,  0}, // Pat: 5 Zon: 3 Lay: 14
        },
        { // Zon: 4
            {25, 28, 30}, // Pat: 5 Zon: 4 Lay: 0
            {26, 27, 28}, // Pat: 5 Zon: 4 Lay: 1
            { 0,  0,  0}, // Pat: 5 Zon: 4 Lay: 2
            {25, 26, 26}, // Pat: 5 Zon: 4 Lay: 3
            {25, 26, 26}, // Pat: 5 Zon: 4 Lay: 4
            {25, 27, 28}, // Pat: 5 Zon: 4 Lay: 5
            { 0,  0,  0}, // Pat: 5 Zon: 4 Lay: 6
            {25, 26, 27}, // Pat: 5 Zon: 4 Lay: 7
            {25, 26, 27}, // Pat: 5 Zon: 4 Lay: 8
            {25, 28, 31}, // Pat: 5 Zon: 4 Lay: 9
            { 0,  0,  0}, // Pat: 5 Zon: 4 Lay: 10
            { 0,  0,  0}, // Pat: 5 Zon: 4 Lay: 11
            { 0,  0,  0}, // Pat: 5 Zon: 4 Lay: 12
            { 0,  0,  0}, // Pat: 5 Zon: 4 Lay: 13
            { 0,  0,  0}, // Pat: 5 Zon: 4 Lay: 14
        },
        { // Zon: 5
            { 0,  0,  0}, // Pat: 5 Zon: 5 Lay: 0
            {26, 26, 27}, // Pat: 5 Zon: 5 Lay: 1
            { 0,  0,  0}, // Pat: 5 Zon: 5 Lay: 2
            {25, 26, 26}, // Pat: 5 Zon: 5 Lay: 3
            {25, 26, 26}, // Pat: 5 Zon: 5 Lay: 4
            {25, 26, 27}, // Pat: 5 Zon: 5 Lay: 5
            {26, 26, 27}, // Pat: 5 Zon: 5 Lay: 6
            {25, 26, 27}, // Pat: 5 Zon: 5 Lay: 7
            {25, 26, 27}, // Pat: 5 Zon: 5 Lay: 8
            { 0,  0,  0}, // Pat: 5 Zon: 5 Lay: 9
            { 0,  0,  0}, // Pat: 5 Zon: 5 Lay: 10
            { 0,  0,  0}, // Pat: 5 Zon: 5 Lay: 11
            { 0,  0,  0}, // Pat: 5 Zon: 5 Lay: 12
            { 0,  0,  0}, // Pat: 5 Zon: 5 Lay: 13
            { 0,  0,  0}, // Pat: 5 Zon: 5 Lay: 14
        },
        { // Zon: 6
            { 0,  0,  0}, // Pat: 5 Zon: 6 Lay: 0
            {25, 26, 27}, // Pat: 5 Zon: 6 Lay: 1
            { 0,  0,  0}, // Pat: 5 Zon: 6 Lay: 2
            {25, 26, 26}, // Pat: 5 Zon: 6 Lay: 3
            { 0,  0,  0}, // Pat: 5 Zon: 6 Lay: 4
            {25, 26, 27}, // Pat: 5 Zon: 6 Lay: 5
            {25, 26, 27}, // Pat: 5 Zon: 6 Lay: 6
            {25, 26, 27}, // Pat: 5 Zon: 6 Lay: 7
            { 0,  0,  0}, // Pat: 5 Zon: 6 Lay: 8
            { 0,  0,  0}, // Pat: 5 Zon: 6 Lay: 9
            { 0,  0,  0}, // Pat: 5 Zon: 6 Lay: 10
            { 0,  0,  0}, // Pat: 5 Zon: 6 Lay: 11
            {25, 27, 28}, // Pat: 5 Zon: 6 Lay: 12
            {26, 26, 27}, // Pat: 5 Zon: 6 Lay: 13
            {25, 26, 27}, // Pat: 5 Zon: 6 Lay: 14
        }
    },
    { // Pat: 6
        { // Zon: 0
            {27, 29, 31}, // Pat: 6 Zon: 0 Lay: 0
            { 0,  0,  0}, // Pat: 6 Zon: 0 Lay: 1
            { 0,  0,  0}, // Pat: 6 Zon: 0 Lay: 2
            {24, 25, 26}, // Pat: 6 Zon: 0 Lay: 3
            {24, 25, 27}, // Pat: 6 Zon: 0 Lay: 4
            { 0,  0,  0}, // Pat: 6 Zon: 0 Lay: 5
            { 0,  0,  0}, // Pat: 6 Zon: 0 Lay: 6
            {24, 25, 27}, // Pat: 6 Zon: 0 Lay: 7
            {23, 25, 27}, // Pat: 6 Zon: 0 Lay: 8
            { 0,  0,  0}, // Pat: 6 Zon: 0 Lay: 9
            {26, 26, 27}, // Pat: 6 Zon: 0 Lay: 10
            {28, 30, 33}, // Pat: 6 Zon: 0 Lay: 11
            { 0,  0,  0}, // Pat: 6 Zon: 0 Lay: 12
            { 0,  0,  0}, // Pat: 6 Zon: 0 Lay: 13
            { 0,  0,  0}, // Pat: 6 Zon: 0 Lay: 14
        },
        { // Zon: 1
            {28, 30, 32}, // Pat: 6 Zon: 1 Lay: 0
            { 0,  0,  0}, // Pat: 6 Zon: 1 Lay: 1
            { 0,  0,  0}, // Pat: 6 Zon: 1 Lay: 2
            {24, 26, 26}, // Pat: 6 Zon: 1 Lay: 3
            {24, 25, 27}, // Pat: 6 Zon: 1 Lay: 4
            { 0,  0,  0}, // Pat: 6 Zon: 1 Lay: 5
            { 0,  0,  0}, // Pat: 6 Zon: 1 Lay: 6
            {24, 25, 27}, // Pat: 6 Zon: 1 Lay: 7
            {24, 25, 27}, // Pat: 6 Zon: 1 Lay: 8
            {28, 31, 33}, // Pat: 6 Zon: 1 Lay: 9
            {26, 26, 27}, // Pat: 6 Zon: 1 Lay: 10
            {29, 31, 34}, // Pat: 6 Zon: 1 Lay: 11
            { 0,  0,  0}, // Pat: 6 Zon: 1 Lay: 12
            { 0,  0,  0}, // Pat: 6 Zon: 1 Lay: 13
            { 0,  0,  0}, // Pat: 6 Zon: 1 Lay: 14
        },
        { // Zon: 2
            {28, 30, 33}, // Pat: 6 Zon: 2 Lay: 0
            { 0,  0,  0}, // Pat: 6 Zon: 2 Lay: 1
            { 0,  0,  0}, // Pat: 6 Zon: 2 Lay: 2
            {25, 26, 26}, // Pat: 6 Zon: 2 Lay: 3
            {24, 26, 27}, // Pat: 6 Zon: 2 Lay: 4
            { 0,  0,  0}, // Pat: 6 Zon: 2 Lay: 5
            { 0,  0,  0}, // Pat: 6 Zon: 2 Lay: 6
            {24, 26, 27}, // Pat: 6 Zon: 2 Lay: 7
            {24, 26, 27}, // Pat: 6 Zon: 2 Lay: 8
            {29, 31, 34}, // Pat: 6 Zon: 2 Lay: 9
            {26, 26, 27}, // Pat: 6 Zon: 2 Lay: 10
            { 0,  0,  0}, // Pat: 6 Zon: 2 Lay: 11
            { 0,  0,  0}, // Pat: 6 Zon: 2 Lay: 12
            { 0,  0,  0}, // Pat: 6 Zon: 2 Lay: 13
            { 0,  0,  0}, // Pat: 6 Zon: 2 Lay: 14
        },
        { // Zon: 3
            {29, 31, 34}, // Pat: 6 Zon: 3 Lay: 0
            { 0,  0,  0}, // Pat: 6 Zon: 3 Lay: 1
            { 0,  0,  0}, // Pat: 6 Zon: 3 Lay: 2
            {25, 26, 26}, // Pat: 6 Zon: 3 Lay: 3
            {25, 26, 27}, // Pat: 6 Zon: 3 Lay: 4
            { 0,  0,  0}, // Pat: 6 Zon: 3 Lay: 5
            { 0,  0,  0}, // Pat: 6 Zon: 3 Lay: 6
            {25, 26, 27}, // Pat: 6 Zon: 3 Lay: 7
            {24, 26, 28}, // Pat: 6 Zon: 3 Lay: 8
            {30, 32, 35}, // Pat: 6 Zon: 3 Lay: 9
            {26, 26, 27}, // Pat: 6 Zon: 3 Lay: 10
            { 0,  0,  0}, // Pat: 6 Zon: 3 Lay: 11
            { 0,  0,  0}, // Pat: 6 Zon: 3 Lay: 12
            { 0,  0,  0}, // Pat: 6 Zon: 3 Lay: 13
            { 0,  0,  0}, // Pat: 6 Zon: 3 Lay: 14
        },
        { // Zon: 4
            {29, 31, 34}, // Pat: 6 Zon: 4 Lay: 0
            {27, 28, 30}, // Pat: 6 Zon: 4 Lay: 1
            { 0,  0,  0}, // Pat: 6 Zon: 4 Lay: 2
            {25, 26, 26}, // Pat: 6 Zon: 4 Lay: 3
            {25, 26, 27}, // Pat: 6 Zon: 4 Lay: 4
            {27, 28, 30}, // Pat: 6 Zon: 4 Lay: 5
            { 0,  0,  0}, // Pat: 6 Zon: 4 Lay: 6
            {25, 26, 27}, // Pat: 6 Zon: 4 Lay: 7
            {24, 26, 28}, // Pat: 6 Zon: 4 Lay: 8
            {30, 32, 35}, // Pat: 6 Zon: 4 Lay: 9
            { 0,  0,  0}, // Pat: 6 Zon: 4 Lay: 10
            { 0,  0,  0}, // Pat: 6 Zon: 4 Lay: 11
            { 0,  0,  0}, // Pat: 6 Zon: 4 Lay: 12
            { 0,  0,  0}, // Pat: 6 Zon: 4 Lay: 13
            { 0,  0,  0}, // Pat: 6 Zon: 4 Lay: 14
        },
        { // Zon: 5
            { 0,  0,  0}, // Pat: 6 Zon: 5 Lay: 0
            {26, 27, 28}, // Pat: 6 Zon: 5 Lay: 1
            { 0,  0,  0}, // Pat: 6 Zon: 5 Lay: 2
            {25, 26, 26}, // Pat: 6 Zon: 5 Lay: 3
            {25, 26, 27}, // Pat: 6 Zon: 5 Lay: 4
            {26, 27, 28}, // Pat: 6 Zon: 5 Lay: 5
            {26, 26, 27}, // Pat: 6 Zon: 5 Lay: 6
            {25, 26, 27}, // Pat: 6 Zon: 5 Lay: 7
            {25, 26, 27}, // Pat: 6 Zon: 5 Lay: 8
            { 0,  0,  0}, // Pat: 6 Zon: 5 Lay: 9
            { 0,  0,  0}, // Pat: 6 Zon: 5 Lay: 10
            { 0,  0,  0}, // Pat: 6 Zon: 5 Lay: 11
            { 0,  0,  0}, // Pat: 6 Zon: 5 Lay: 12
            { 0,  0,  0}, // Pat: 6 Zon: 5 Lay: 13
            { 0,  0,  0}, // Pat: 6 Zon: 5 Lay: 14
        },
        { // Zon: 6
            { 0,  0,  0}, // Pat: 6 Zon: 6 Lay: 0
            {25, 27, 28}, // Pat: 6 Zon: 6 Lay: 1
            { 0,  0,  0}, // Pat: 6 Zon: 6 Lay: 2
            {25, 26, 27}, // Pat: 6 Zon: 6 Lay: 3
            { 0,  0,  0}, // Pat: 6 Zon: 6 Lay: 4
            {25, 26, 28}, // Pat: 6 Zon: 6 Lay: 5
            {25, 26, 27}, // Pat: 6 Zon: 6 Lay: 6
            {25, 26, 27}, // Pat: 6 Zon: 6 Lay: 7
            { 0,  0,  0}, // Pat: 6 Zon: 6 Lay: 8
            { 0,  0,  0}, // Pat: 6 Zon: 6 Lay: 9
            { 0,  0,  0}, // Pat: 6 Zon: 6 Lay: 10
            { 0,  0,  0}, // Pat: 6 Zon: 6 Lay: 11
            {27, 28, 30}, // Pat: 6 Zon: 6 Lay: 12
            {26, 27, 28}, // Pat: 6 Zon: 6 Lay: 13
            {25, 26, 27}, // Pat: 6 Zon: 6 Lay: 14
        }
    },
    { // Pat: 7
        { // Zon: 0
            {28, 31, 34}, // Pat: 7 Zon: 0 Lay: 0
            { 0,  0,  0}, // Pat: 7 Zon: 0 Lay: 1
            { 0,  0,  0}, // Pat: 7 Zon: 0 Lay: 2
            {23, 25, 27}, // Pat: 7 Zon: 0 Lay: 3
            {22, 25, 28}, // Pat: 7 Zon: 0 Lay: 4
            { 0,  0,  0}, // Pat: 7 Zon: 0 Lay: 5
            { 0,  0,  0}, // Pat: 7 Zon: 0 Lay: 6
            {23, 25, 27}, // Pat: 7 Zon: 0 Lay: 7
            {22, 25, 28}, // Pat: 7 Zon: 0 Lay: 8
            { 0,  0,  0}, // Pat: 7 Zon: 0 Lay: 9
            {26, 26, 27}, // Pat: 7 Zon: 0 Lay: 10
            {29, 32, 37}, // Pat: 7 Zon: 0 Lay: 11
            { 0,  0,  0}, // Pat: 7 Zon: 0 Lay: 12
            { 0,  0,  0}, // Pat: 7 Zon: 0 Lay: 13
            { 0,  0,  0}, // Pat: 7 Zon: 0 Lay: 14
        },
        { // Zon: 1
            {29, 32, 36}, // Pat: 7 Zon: 1 Lay: 0
            { 0,  0,  0}, // Pat: 7 Zon: 1 Lay: 1
            { 0,  0,  0}, // Pat: 7 Zon: 1 Lay: 2
            {24, 25, 27}, // Pat: 7 Zon: 1 Lay: 3
            {23, 26, 28}, // Pat: 7 Zon: 1 Lay: 4
            { 0,  0,  0}, // Pat: 7 Zon: 1 Lay: 5
            { 0,  0,  0}, // Pat: 7 Zon: 1 Lay: 6
            {23, 25, 27}, // Pat: 7 Zon: 1 Lay: 7
            {22, 26, 29}, // Pat: 7 Zon: 1 Lay: 8
            {30, 33, 38}, // Pat: 7 Zon: 1 Lay: 9
            {26, 26, 28}, // Pat: 7 Zon: 1 Lay: 10
            {30, 34, 39}, // Pat: 7 Zon: 1 Lay: 11
            { 0,  0,  0}, // Pat: 7 Zon: 1 Lay: 12
            { 0,  0,  0}, // Pat: 7 Zon: 1 Lay: 13
            { 0,  0,  0}, // Pat: 7 Zon: 1 Lay: 14
        },
        { // Zon: 2
            {30, 33, 37}, // Pat: 7 Zon: 2 Lay: 0
            { 0,  0,  0}, // Pat: 7 Zon: 2 Lay: 1
            { 0,  0,  0}, // Pat: 7 Zon: 2 Lay: 2
            {24, 26, 27}, // Pat: 7 Zon: 2 Lay: 3
            {23, 26, 29}, // Pat: 7 Zon: 2 Lay: 4
            { 0,  0,  0}, // Pat: 7 Zon: 2 Lay: 5
            { 0,  0,  0}, // Pat: 7 Zon: 2 Lay: 6
            {24, 26, 28}, // Pat: 7 Zon: 2 Lay: 7
            {23, 26, 29}, // Pat: 7 Zon: 2 Lay: 8
            {31, 34, 38}, // Pat: 7 Zon: 2 Lay: 9
            {26, 26, 27}, // Pat: 7 Zon: 2 Lay: 10
            { 0,  0,  0}, // Pat: 7 Zon: 2 Lay: 11
            { 0,  0,  0}, // Pat: 7 Zon: 2 Lay: 12
            { 0,  0,  0}, // Pat: 7 Zon: 2 Lay: 13
            { 0,  0,  0}, // Pat: 7 Zon: 2 Lay: 14
        },
        { // Zon: 3
            {31, 34, 38}, // Pat: 7 Zon: 3 Lay: 0
            { 0,  0,  0}, // Pat: 7 Zon: 3 Lay: 1
            { 0,  0,  0}, // Pat: 7 Zon: 3 Lay: 2
            {25, 26, 27}, // Pat: 7 Zon: 3 Lay: 3
            {24, 26, 29}, // Pat: 7 Zon: 3 Lay: 4
            { 0,  0,  0}, // Pat: 7 Zon: 3 Lay: 5
            { 0,  0,  0}, // Pat: 7 Zon: 3 Lay: 6
            {24, 26, 28}, // Pat: 7 Zon: 3 Lay: 7
            {24, 27, 31}, // Pat: 7 Zon: 3 Lay: 8
            {32, 36, 40}, // Pat: 7 Zon: 3 Lay: 9
            {26, 26, 27}, // Pat: 7 Zon: 3 Lay: 10
            { 0,  0,  0}, // Pat: 7 Zon: 3 Lay: 11
            { 0,  0,  0}, // Pat: 7 Zon: 3 Lay: 12
            { 0,  0,  0}, // Pat: 7 Zon: 3 Lay: 13
            { 0,  0,  0}, // Pat: 7 Zon: 3 Lay: 14
        },
        { // Zon: 4
            {31, 34, 39}, // Pat: 7 Zon: 4 Lay: 0
            {28, 30, 32}, // Pat: 7 Zon: 4 Lay: 1
            { 0,  0,  0}, // Pat: 7 Zon: 4 Lay: 2
            {25, 26, 27}, // Pat: 7 Zon: 4 Lay: 3
            {24, 26, 29}, // Pat: 7 Zon: 4 Lay: 4
            {27, 29, 32}, // Pat: 7 Zon: 4 Lay: 5
            { 0,  0,  0}, // Pat: 7 Zon: 4 Lay: 6
            {24, 26, 28}, // Pat: 7 Zon: 4 Lay: 7
            {24, 27, 31}, // Pat: 7 Zon: 4 Lay: 8
            {32, 36, 41}, // Pat: 7 Zon: 4 Lay: 9
            { 0,  0,  0}, // Pat: 7 Zon: 4 Lay: 10
            { 0,  0,  0}, // Pat: 7 Zon: 4 Lay: 11
            { 0,  0,  0}, // Pat: 7 Zon: 4 Lay: 12
            { 0,  0,  0}, // Pat: 7 Zon: 4 Lay: 13
            { 0,  0,  0}, // Pat: 7 Zon: 4 Lay: 14
        },
        { // Zon: 5
            { 0,  0,  0}, // Pat: 7 Zon: 5 Lay: 0
            {26, 28, 29}, // Pat: 7 Zon: 5 Lay: 1
            { 0,  0,  0}, // Pat: 7 Zon: 5 Lay: 2
            {25, 26, 28}, // Pat: 7 Zon: 5 Lay: 3
            {25, 26, 30}, // Pat: 7 Zon: 5 Lay: 4
            {26, 28, 29}, // Pat: 7 Zon: 5 Lay: 5
            {25, 26, 27}, // Pat: 7 Zon: 5 Lay: 6
            {25, 26, 29}, // Pat: 7 Zon: 5 Lay: 7
            {24, 27, 30}, // Pat: 7 Zon: 5 Lay: 8
            { 0,  0,  0}, // Pat: 7 Zon: 5 Lay: 9
            { 0,  0,  0}, // Pat: 7 Zon: 5 Lay: 10
            { 0,  0,  0}, // Pat: 7 Zon: 5 Lay: 11
            { 0,  0,  0}, // Pat: 7 Zon: 5 Lay: 12
            { 0,  0,  0}, // Pat: 7 Zon: 5 Lay: 13
            { 0,  0,  0}, // Pat: 7 Zon: 5 Lay: 14
        },
        { // Zon: 6
            { 0,  0,  0}, // Pat: 7 Zon: 6 Lay: 0
            {26, 27, 28}, // Pat: 7 Zon: 6 Lay: 1
            { 0,  0,  0}, // Pat: 7 Zon: 6 Lay: 2
            {25, 26, 27}, // Pat: 7 Zon: 6 Lay: 3
            { 0,  0,  0}, // Pat: 7 Zon: 6 Lay: 4
            {26, 27, 28}, // Pat: 7 Zon: 6 Lay: 5
            {25, 26, 27}, // Pat: 7 Zon: 6 Lay: 6
            {25, 26, 27}, // Pat: 7 Zon: 6 Lay: 7
            { 0,  0,  0}, // Pat: 7 Zon: 6 Lay: 8
            { 0,  0,  0}, // Pat: 7 Zon: 6 Lay: 9
            { 0,  0,  0}, // Pat: 7 Zon: 6 Lay: 10
            { 0,  0,  0}, // Pat: 7 Zon: 6 Lay: 11
            {27, 29, 32}, // Pat: 7 Zon: 6 Lay: 12
            {26, 28, 29}, // Pat: 7 Zon: 6 Lay: 13
            {24, 26, 27}, // Pat: 7 Zon: 6 Lay: 14
        }
    },
    { // Pat: 8
        { // Zon: 0
            {28, 33, 40}, // Pat: 8 Zon: 0 Lay: 0
            { 0,  0,  0}, // Pat: 8 Zon: 0 Lay: 1
            { 0,  0,  0}, // Pat: 8 Zon: 0 Lay: 2
            {22, 25, 28}, // Pat: 8 Zon: 0 Lay: 3
            {20, 25, 30}, // Pat: 8 Zon: 0 Lay: 4
            { 0,  0,  0}, // Pat: 8 Zon: 0 Lay: 5
            { 0,  0,  0}, // Pat: 8 Zon: 0 Lay: 6
            {21, 25, 29}, // Pat: 8 Zon: 0 Lay: 7
            {19, 25, 31}, // Pat: 8 Zon: 0 Lay: 8
            { 0,  0,  0}, // Pat: 8 Zon: 0 Lay: 9
            {26, 27, 28}, // Pat: 8 Zon: 0 Lay: 10
            {30, 36, 44}, // Pat: 8 Zon: 0 Lay: 11
            { 0,  0,  0}, // Pat: 8 Zon: 0 Lay: 12
            { 0,  0,  0}, // Pat: 8 Zon: 0 Lay: 13
            { 0,  0,  0}, // Pat: 8 Zon: 0 Lay: 14
        },
        { // Zon: 1
            {30, 36, 42}, // Pat: 8 Zon: 1 Lay: 0
            { 0,  0,  0}, // Pat: 8 Zon: 1 Lay: 1
            { 0,  0,  0}, // Pat: 8 Zon: 1 Lay: 2
            {23, 26, 29}, // Pat: 8 Zon: 1 Lay: 3
            {22, 27, 34}, // Pat: 8 Zon: 1 Lay: 4
            { 0,  0,  0}, // Pat: 8 Zon: 1 Lay: 5
            { 0,  0,  0}, // Pat: 8 Zon: 1 Lay: 6
            {22, 26, 31}, // Pat: 8 Zon: 1 Lay: 7
            {21, 27, 35}, // Pat: 8 Zon: 1 Lay: 8
            {32, 37, 44}, // Pat: 8 Zon: 1 Lay: 9
            {25, 27, 28}, // Pat: 8 Zon: 1 Lay: 10
            {32, 39, 46}, // Pat: 8 Zon: 1 Lay: 11
            { 0,  0,  0}, // Pat: 8 Zon: 1 Lay: 12
            { 0,  0,  0}, // Pat: 8 Zon: 1 Lay: 13
            { 0,  0,  0}, // Pat: 8 Zon: 1 Lay: 14
        },
        { // Zon: 2
            {31, 36, 42}, // Pat: 8 Zon: 2 Lay: 0
            { 0,  0,  0}, // Pat: 8 Zon: 2 Lay: 1
            { 0,  0,  0}, // Pat: 8 Zon: 2 Lay: 2
            {24, 26, 30}, // Pat: 8 Zon: 2 Lay: 3
            {23, 28, 35}, // Pat: 8 Zon: 2 Lay: 4
            { 0,  0,  0}, // Pat: 8 Zon: 2 Lay: 5
            { 0,  0,  0}, // Pat: 8 Zon: 2 Lay: 6
            {23, 27, 32}, // Pat: 8 Zon: 2 Lay: 7
            {22, 28, 36}, // Pat: 8 Zon: 2 Lay: 8
            {32, 38, 43}, // Pat: 8 Zon: 2 Lay: 9
            {25, 26, 28}, // Pat: 8 Zon: 2 Lay: 10
            { 0,  0,  0}, // Pat: 8 Zon: 2 Lay: 11
            { 0,  0,  0}, // Pat: 8 Zon: 2 Lay: 12
            { 0,  0,  0}, // Pat: 8 Zon: 2 Lay: 13
            { 0,  0,  0}, // Pat: 8 Zon: 2 Lay: 14
        },
        { // Zon: 3
            {33, 38, 44}, // Pat: 8 Zon: 3 Lay: 0
            { 0,  0,  0}, // Pat: 8 Zon: 3 Lay: 1
            { 0,  0,  0}, // Pat: 8 Zon: 3 Lay: 2
            {25, 26, 30}, // Pat: 8 Zon: 3 Lay: 3
            {25, 28, 34}, // Pat: 8 Zon: 3 Lay: 4
            { 0,  0,  0}, // Pat: 8 Zon: 3 Lay: 5
            { 0,  0,  0}, // Pat: 8 Zon: 3 Lay: 6
            {25, 27, 33}, // Pat: 8 Zon: 3 Lay: 7
            {24, 30, 40}, // Pat: 8 Zon: 3 Lay: 8
            {34, 39, 44}, // Pat: 8 Zon: 3 Lay: 9
            {25, 26, 27}, // Pat: 8 Zon: 3 Lay: 10
            { 0,  0,  0}, // Pat: 8 Zon: 3 Lay: 11
            { 0,  0,  0}, // Pat: 8 Zon: 3 Lay: 12
            { 0,  0,  0}, // Pat: 8 Zon: 3 Lay: 13
            { 0,  0,  0}, // Pat: 8 Zon: 3 Lay: 14
        },
        { // Zon: 4
            {32, 38, 45}, // Pat: 8 Zon: 4 Lay: 0
            {27, 31, 35}, // Pat: 8 Zon: 4 Lay: 1
            { 0,  0,  0}, // Pat: 8 Zon: 4 Lay: 2
            {25, 26, 30}, // Pat: 8 Zon: 4 Lay: 3
            {25, 28, 34}, // Pat: 8 Zon: 4 Lay: 4
            {26, 29, 34}, // Pat: 8 Zon: 4 Lay: 5
            { 0,  0,  0}, // Pat: 8 Zon: 4 Lay: 6
            {25, 27, 33}, // Pat: 8 Zon: 4 Lay: 7
            {24, 30, 40}, // Pat: 8 Zon: 4 Lay: 8
            {34, 39, 45}, // Pat: 8 Zon: 4 Lay: 9
            { 0,  0,  0}, // Pat: 8 Zon: 4 Lay: 10
            { 0,  0,  0}, // Pat: 8 Zon: 4 Lay: 11
            { 0,  0,  0}, // Pat: 8 Zon: 4 Lay: 12
            { 0,  0,  0}, // Pat: 8 Zon: 4 Lay: 13
            { 0,  0,  0}, // Pat: 8 Zon: 4 Lay: 14
        },
        { // Zon: 5
            { 0,  0,  0}, // Pat: 8 Zon: 5 Lay: 0
            {21, 28, 31}, // Pat: 8 Zon: 5 Lay: 1
            { 0,  0,  0}, // Pat: 8 Zon: 5 Lay: 2
            {25, 27, 32}, // Pat: 8 Zon: 5 Lay: 3
            {24, 28, 37}, // Pat: 8 Zon: 5 Lay: 4
            {21, 28, 31}, // Pat: 8 Zon: 5 Lay: 5
            {24, 26, 27}, // Pat: 8 Zon: 5 Lay: 6
            {24, 28, 36}, // Pat: 8 Zon: 5 Lay: 7
            {24, 29, 40}, // Pat: 8 Zon: 5 Lay: 8
            { 0,  0,  0}, // Pat: 8 Zon: 5 Lay: 9
            { 0,  0,  0}, // Pat: 8 Zon: 5 Lay: 10
            { 0,  0,  0}, // Pat: 8 Zon: 5 Lay: 11
            { 0,  0,  0}, // Pat: 8 Zon: 5 Lay: 12
            { 0,  0,  0}, // Pat: 8 Zon: 5 Lay: 13
            { 0,  0,  0}, // Pat: 8 Zon: 5 Lay: 14
        },
        { // Zon: 6
            { 0,  0,  0}, // Pat: 8 Zon: 6 Lay: 0
            {23, 26, 29}, // Pat: 8 Zon: 6 Lay: 1
            { 0,  0,  0}, // Pat: 8 Zon: 6 Lay: 2
            {25, 27, 30}, // Pat: 8 Zon: 6 Lay: 3
            { 0,  0,  0}, // Pat: 8 Zon: 6 Lay: 4
            {23, 26, 29}, // Pat: 8 Zon: 6 Lay: 5
            {24, 26, 27}, // Pat: 8 Zon: 6 Lay: 6
            {25, 27, 32}, // Pat: 8 Zon: 6 Lay: 7
            { 0,  0,  0}, // Pat: 8 Zon: 6 Lay: 8
            { 0,  0,  0}, // Pat: 8 Zon: 6 Lay: 9
            { 0,  0,  0}, // Pat: 8 Zon: 6 Lay: 10
            { 0,  0,  0}, // Pat: 8 Zon: 6 Lay: 11
            {26, 30, 34}, // Pat: 8 Zon: 6 Lay: 12
            {23, 27, 30}, // Pat: 8 Zon: 6 Lay: 13
            {22, 25, 27}, // Pat: 8 Zon: 6 Lay: 14
        }
    },
    { // Pat: 9
        { // Zon: 0
            { 7,  9, 11}, // Pat: 9 Zon: 0 Lay: 0
            { 0,  0,  0}, // Pat: 9 Zon: 0 Lay: 1
            { 0,  0,  0}, // Pat: 9 Zon: 0 Lay: 2
            {30, 32, 35}, // Pat: 9 Zon: 0 Lay: 3
            {34, 36, 39}, // Pat: 9 Zon: 0 Lay: 4
            { 0,  0,  0}, // Pat: 9 Zon: 0 Lay: 5
            { 0,  0,  0}, // Pat: 9 Zon: 0 Lay: 6
            {32, 34, 36}, // Pat: 9 Zon: 0 Lay: 7
            {35, 38, 41}, // Pat: 9 Zon: 0 Lay: 8
            { 0,  0,  0}, // Pat: 9 Zon: 0 Lay: 9
            {23, 24, 25}, // Pat: 9 Zon: 0 Lay: 10
            { 0,  3,  6}, // Pat: 9 Zon: 0 Lay: 11
            { 0,  0,  0}, // Pat: 9 Zon: 0 Lay: 12
            { 0,  0,  0}, // Pat: 9 Zon: 0 Lay: 13
            { 0,  0,  0}, // Pat: 9 Zon: 0 Lay: 14
        },
        { // Zon: 1
            { 7, 10, 13}, // Pat: 9 Zon: 1 Lay: 0
            { 0,  0,  0}, // Pat: 9 Zon: 1 Lay: 1
            { 0,  0,  0}, // Pat: 9 Zon: 1 Lay: 2
            {29, 32, 34}, // Pat: 9 Zon: 1 Lay: 3
            {33, 35, 38}, // Pat: 9 Zon: 1 Lay: 4
            { 0,  0,  0}, // Pat: 9 Zon: 1 Lay: 5
            { 0,  0,  0}, // Pat: 9 Zon: 1 Lay: 6
            {31, 33, 35}, // Pat: 9 Zon: 1 Lay: 7
            {34, 36, 39}, // Pat: 9 Zon: 1 Lay: 8
            { 5,  7, 10}, // Pat: 9 Zon: 1 Lay: 9
            {23, 24, 25}, // Pat: 9 Zon: 1 Lay: 10
            { 1,  4,  6}, // Pat: 9 Zon: 1 Lay: 11
            { 0,  0,  0}, // Pat: 9 Zon: 1 Lay: 12
            { 0,  0,  0}, // Pat: 9 Zon: 1 Lay: 13
            { 0,  0,  0}, // Pat: 9 Zon: 1 Lay: 14
        },
        { // Zon: 2
            { 8, 11, 14}, // Pat: 9 Zon: 2 Lay: 0
            { 0,  0,  0}, // Pat: 9 Zon: 2 Lay: 1
            { 0,  0,  0}, // Pat: 9 Zon: 2 Lay: 2
            {29, 31, 33}, // Pat: 9 Zon: 2 Lay: 3
            {32, 34, 36}, // Pat: 9 Zon: 2 Lay: 4
            { 0,  0,  0}, // Pat: 9 Zon: 2 Lay: 5
            { 0,  0,  0}, // Pat: 9 Zon: 2 Lay: 6
            {30, 32, 34}, // Pat: 9 Zon: 2 Lay: 7
            {33, 35, 38}, // Pat: 9 Zon: 2 Lay: 8
            { 6,  9, 12}, // Pat: 9 Zon: 2 Lay: 9
            {23, 24, 25}, // Pat: 9 Zon: 2 Lay: 10
            { 0,  0,  0}, // Pat: 9 Zon: 2 Lay: 11
            { 0,  0,  0}, // Pat: 9 Zon: 2 Lay: 12
            { 0,  0,  0}, // Pat: 9 Zon: 2 Lay: 13
            { 0,  0,  0}, // Pat: 9 Zon: 2 Lay: 14
        },
        { // Zon: 3
            {10, 13, 17}, // Pat: 9 Zon: 3 Lay: 0
            { 0,  0,  0}, // Pat: 9 Zon: 3 Lay: 1
            { 0,  0,  0}, // Pat: 9 Zon: 3 Lay: 2
            {28, 30, 32}, // Pat: 9 Zon: 3 Lay: 3
            {31, 32, 34}, // Pat: 9 Zon: 3 Lay: 4
            { 0,  0,  0}, // Pat: 9 Zon: 3 Lay: 5
            { 0,  0,  0}, // Pat: 9 Zon: 3 Lay: 6
            {30, 31, 33}, // Pat: 9 Zon: 3 Lay: 7
            {32, 34, 36}, // Pat: 9 Zon: 3 Lay: 8
            { 8, 11, 15}, // Pat: 9 Zon: 3 Lay: 9
            {24, 25, 26}, // Pat: 9 Zon: 3 Lay: 10
            { 0,  0,  0}, // Pat: 9 Zon: 3 Lay: 11
            { 0,  0,  0}, // Pat: 9 Zon: 3 Lay: 12
            { 0,  0,  0}, // Pat: 9 Zon: 3 Lay: 13
            { 0,  0,  0}, // Pat: 9 Zon: 3 Lay: 14
        },
        { // Zon: 4
            {10, 13, 17}, // Pat: 9 Zon: 4 Lay: 0
            {18, 21, 22}, // Pat: 9 Zon: 4 Lay: 1
            { 0,  0,  0}, // Pat: 9 Zon: 4 Lay: 2
            {28, 30, 32}, // Pat: 9 Zon: 4 Lay: 3
            {31, 32, 34}, // Pat: 9 Zon: 4 Lay: 4
            {18, 21, 23}, // Pat: 9 Zon: 4 Lay: 5
            { 0,  0,  0}, // Pat: 9 Zon: 4 Lay: 6
            {30, 31, 33}, // Pat: 9 Zon: 4 Lay: 7
            {32, 34, 36}, // Pat: 9 Zon: 4 Lay: 8
            { 8, 11, 15}, // Pat: 9 Zon: 4 Lay: 9
            { 0,  0,  0}, // Pat: 9 Zon: 4 Lay: 10
            { 0,  0,  0}, // Pat: 9 Zon: 4 Lay: 11
            { 0,  0,  0}, // Pat: 9 Zon: 4 Lay: 12
            { 0,  0,  0}, // Pat: 9 Zon: 4 Lay: 13
            { 0,  0,  0}, // Pat: 9 Zon: 4 Lay: 14
        },
        { // Zon: 5
            { 0,  0,  0}, // Pat: 9 Zon: 5 Lay: 0
            {19, 21, 23}, // Pat: 9 Zon: 5 Lay: 1
            { 0,  0,  0}, // Pat: 9 Zon: 5 Lay: 2
            {28, 29, 30}, // Pat: 9 Zon: 5 Lay: 3
            {29, 31, 33}, // Pat: 9 Zon: 5 Lay: 4
            {19, 22, 24}, // Pat: 9 Zon: 5 Lay: 5
            {24, 25, 26}, // Pat: 9 Zon: 5 Lay: 6
            {28, 30, 32}, // Pat: 9 Zon: 5 Lay: 7
            {30, 32, 34}, // Pat: 9 Zon: 5 Lay: 8
            { 0,  0,  0}, // Pat: 9 Zon: 5 Lay: 9
            { 0,  0,  0}, // Pat: 9 Zon: 5 Lay: 10
            { 0,  0,  0}, // Pat: 9 Zon: 5 Lay: 11
            { 0,  0,  0}, // Pat: 9 Zon: 5 Lay: 12
            { 0,  0,  0}, // Pat: 9 Zon: 5 Lay: 13
            { 0,  0,  0}, // Pat: 9 Zon: 5 Lay: 14
        },
        { // Zon: 6
            { 0,  0,  0}, // Pat: 9 Zon: 6 Lay: 0
            { 0,  0,  0}, // Pat: 9 Zon: 6 Lay: 1
            { 0,  0,  0}, // Pat: 9 Zon: 6 Lay: 2
            { 0,  0,  0}, // Pat: 9 Zon: 6 Lay: 3
            { 0,  0,  0}, // Pat: 9 Zon: 6 Lay: 4
            { 0,  0,  0}, // Pat: 9 Zon: 6 Lay: 5
            { 0,  0,  0}, // Pat: 9 Zon: 6 Lay: 6
            { 0,  0,  0}, // Pat: 9 Zon: 6 Lay: 7
            { 0,  0,  0}, // Pat: 9 Zon: 6 Lay: 8
            { 0,  0,  0}, // Pat: 9 Zon: 6 Lay: 9
            { 0,  0,  0}, // Pat: 9 Zon: 6 Lay: 10
            { 0,  0,  0}, // Pat: 9 Zon: 6 Lay: 11
            { 0,  0,  0}, // Pat: 9 Zon: 6 Lay: 12
            { 0,  0,  0}, // Pat: 9 Zon: 6 Lay: 13
            { 0,  0,  0}, // Pat: 9 Zon: 6 Lay: 14
        }
    },
    { // Pat: 10
        { // Zon: 0
            { 8, 11, 14}, // Pat: 10 Zon: 0 Lay: 0
            { 0,  0,  0}, // Pat: 10 Zon: 0 Lay: 1
            { 0,  0,  0}, // Pat: 10 Zon: 0 Lay: 2
            {29, 31, 33}, // Pat: 10 Zon: 0 Lay: 3
            {32, 34, 37}, // Pat: 10 Zon: 0 Lay: 4
            { 0,  0,  0}, // Pat: 10 Zon: 0 Lay: 5
            { 0,  0,  0}, // Pat: 10 Zon: 0 Lay: 6
            {30, 32, 34}, // Pat: 10 Zon: 0 Lay: 7
            {33, 35, 38}, // Pat: 10 Zon: 0 Lay: 8
            { 0,  0,  0}, // Pat: 10 Zon: 0 Lay: 9
            {23, 24, 25}, // Pat: 10 Zon: 0 Lay: 10
            { 2,  6, 10}, // Pat: 10 Zon: 0 Lay: 11
            { 0,  0,  0}, // Pat: 10 Zon: 0 Lay: 12
            { 0,  0,  0}, // Pat: 10 Zon: 0 Lay: 13
            { 0,  0,  0}, // Pat: 10 Zon: 0 Lay: 14
        },
        { // Zon: 1
            {10, 13, 16}, // Pat: 10 Zon: 1 Lay: 0
            { 0,  0,  0}, // Pat: 10 Zon: 1 Lay: 1
            { 0,  0,  0}, // Pat: 10 Zon: 1 Lay: 2
            {28, 30, 32}, // Pat: 10 Zon: 1 Lay: 3
            {31, 33, 35}, // Pat: 10 Zon: 1 Lay: 4
            { 0,  0,  0}, // Pat: 10 Zon: 1 Lay: 5
            { 0,  0,  0}, // Pat: 10 Zon: 1 Lay: 6
            {30, 31, 33}, // Pat: 10 Zon: 1 Lay: 7
            {32, 34, 36}, // Pat: 10 Zon: 1 Lay: 8
            { 7, 11, 14}, // Pat: 10 Zon: 1 Lay: 9
            {24, 25, 26}, // Pat: 10 Zon: 1 Lay: 10
            { 4,  9, 12}, // Pat: 10 Zon: 1 Lay: 11
            { 0,  0,  0}, // Pat: 10 Zon: 1 Lay: 12
            { 0,  0,  0}, // Pat: 10 Zon: 1 Lay: 13
            { 0,  0,  0}, // Pat: 10 Zon: 1 Lay: 14
        },
        { // Zon: 2
            {12, 15, 18}, // Pat: 10 Zon: 2 Lay: 0
            { 0,  0,  0}, // Pat: 10 Zon: 2 Lay: 1
            { 0,  0,  0}, // Pat: 10 Zon: 2 Lay: 2
            {28, 30, 31}, // Pat: 10 Zon: 2 Lay: 3
            {30, 32, 34}, // Pat: 10 Zon: 2 Lay: 4
            { 0,  0,  0}, // Pat: 10 Zon: 2 Lay: 5
            { 0,  0,  0}, // Pat: 10 Zon: 2 Lay: 6
            {29, 30, 32}, // Pat: 10 Zon: 2 Lay: 7
            {31, 33, 35}, // Pat: 10 Zon: 2 Lay: 8
            { 9, 12, 16}, // Pat: 10 Zon: 2 Lay: 9
            {24, 25, 26}, // Pat: 10 Zon: 2 Lay: 10
            { 0,  0,  0}, // Pat: 10 Zon: 2 Lay: 11
            { 0,  0,  0}, // Pat: 10 Zon: 2 Lay: 12
            { 0,  0,  0}, // Pat: 10 Zon: 2 Lay: 13
            { 0,  0,  0}, // Pat: 10 Zon: 2 Lay: 14
        },
        { // Zon: 3
            {13, 16, 20}, // Pat: 10 Zon: 3 Lay: 0
            { 0,  0,  0}, // Pat: 10 Zon: 3 Lay: 1
            { 0,  0,  0}, // Pat: 10 Zon: 3 Lay: 2
            {28, 29, 30}, // Pat: 10 Zon: 3 Lay: 3
            {29, 31, 32}, // Pat: 10 Zon: 3 Lay: 4
            { 0,  0,  0}, // Pat: 10 Zon: 3 Lay: 5
            { 0,  0,  0}, // Pat: 10 Zon: 3 Lay: 6
            {28, 30, 31}, // Pat: 10 Zon: 3 Lay: 7
            {30, 32, 34}, // Pat: 10 Zon: 3 Lay: 8
            {11, 14, 18}, // Pat: 10 Zon: 3 Lay: 9
            {24, 25, 26}, // Pat: 10 Zon: 3 Lay: 10
            { 0,  0,  0}, // Pat: 10 Zon: 3 Lay: 11
            { 0,  0,  0}, // Pat: 10 Zon: 3 Lay: 12
            { 0,  0,  0}, // Pat: 10 Zon: 3 Lay: 13
            { 0,  0,  0}, // Pat: 10 Zon: 3 Lay: 14
        },
        { // Zon: 4
            {13, 16, 20}, // Pat: 10 Zon: 4 Lay: 0
            {20, 22, 24}, // Pat: 10 Zon: 4 Lay: 1
            { 0,  0,  0}, // Pat: 10 Zon: 4 Lay: 2
            {28, 29, 30}, // Pat: 10 Zon: 4 Lay: 3
            {29, 31, 32}, // Pat: 10 Zon: 4 Lay: 4
            {20, 22, 24}, // Pat: 10 Zon: 4 Lay: 5
            { 0,  0,  0}, // Pat: 10 Zon: 4 Lay: 6
            {28, 30, 31}, // Pat: 10 Zon: 4 Lay: 7
            {30, 32, 34}, // Pat: 10 Zon: 4 Lay: 8
            {11, 14, 18}, // Pat: 10 Zon: 4 Lay: 9
            { 0,  0,  0}, // Pat: 10 Zon: 4 Lay: 10
            { 0,  0,  0}, // Pat: 10 Zon: 4 Lay: 11
            { 0,  0,  0}, // Pat: 10 Zon: 4 Lay: 12
            { 0,  0,  0}, // Pat: 10 Zon: 4 Lay: 13
            { 0,  0,  0}, // Pat: 10 Zon: 4 Lay: 14
        },
        { // Zon: 5
            { 0,  0,  0}, // Pat: 10 Zon: 5 Lay: 0
            {21, 23, 24}, // Pat: 10 Zon: 5 Lay: 1
            { 0,  0,  0}, // Pat: 10 Zon: 5 Lay: 2
            {27, 28, 29}, // Pat: 10 Zon: 5 Lay: 3
            {28, 30, 31}, // Pat: 10 Zon: 5 Lay: 4
            {21, 23, 24}, // Pat: 10 Zon: 5 Lay: 5
            {24, 25, 26}, // Pat: 10 Zon: 5 Lay: 6
            {28, 29, 30}, // Pat: 10 Zon: 5 Lay: 7
            {29, 30, 32}, // Pat: 10 Zon: 5 Lay: 8
            { 0,  0,  0}, // Pat: 10 Zon: 5 Lay: 9
            { 0,  0,  0}, // Pat: 10 Zon: 5 Lay: 10
            { 0,  0,  0}, // Pat: 10 Zon: 5 Lay: 11
            { 0,  0,  0}, // Pat: 10 Zon: 5 Lay: 12
            { 0,  0,  0}, // Pat: 10 Zon: 5 Lay: 13
            { 0,  0,  0}, // Pat: 10 Zon: 5 Lay: 14
        },
        { // Zon: 6
            { 0,  0,  0}, // Pat: 10 Zon: 6 Lay: 0
            { 0,  0,  0}, // Pat: 10 Zon: 6 Lay: 1
            { 0,  0,  0}, // Pat: 10 Zon: 6 Lay: 2
            { 0,  0,  0}, // Pat: 10 Zon: 6 Lay: 3
            { 0,  0,  0}, // Pat: 10 Zon: 6 Lay: 4
            { 0,  0,  0}, // Pat: 10 Zon: 6 Lay: 5
            { 0,  0,  0}, // Pat: 10 Zon: 6 Lay: 6
            { 0,  0,  0}, // Pat: 10 Zon: 6 Lay: 7
            { 0,  0,  0}, // Pat: 10 Zon: 6 Lay: 8
            { 0,  0,  0}, // Pat: 10 Zon: 6 Lay: 9
            { 0,  0,  0}, // Pat: 10 Zon: 6 Lay: 10
            { 0,  0,  0}, // Pat: 10 Zon: 6 Lay: 11
            { 0,  0,  0}, // Pat: 10 Zon: 6 Lay: 12
            { 0,  0,  0}, // Pat: 10 Zon: 6 Lay: 13
            { 0,  0,  0}, // Pat: 10 Zon: 6 Lay: 14
        }
    },
    { // Pat: 11
        { // Zon: 0
            {11, 15, 19}, // Pat: 11 Zon: 0 Lay: 0
            { 0,  0,  0}, // Pat: 11 Zon: 0 Lay: 1
            { 0,  0,  0}, // Pat: 11 Zon: 0 Lay: 2
            {28, 29, 31}, // Pat: 11 Zon: 0 Lay: 3
            {30, 32, 34}, // Pat: 11 Zon: 0 Lay: 4
            { 0,  0,  0}, // Pat: 11 Zon: 0 Lay: 5
            { 0,  0,  0}, // Pat: 11 Zon: 0 Lay: 6
            {28, 30, 32}, // Pat: 11 Zon: 0 Lay: 7
            {30, 32, 35}, // Pat: 11 Zon: 0 Lay: 8
            { 0,  0,  0}, // Pat: 11 Zon: 0 Lay: 9
            {24, 25, 26}, // Pat: 11 Zon: 0 Lay: 10
            { 7, 11, 16}, // Pat: 11 Zon: 0 Lay: 11
            { 0,  0,  0}, // Pat: 11 Zon: 0 Lay: 12
            { 0,  0,  0}, // Pat: 11 Zon: 0 Lay: 13
            { 0,  0,  0}, // Pat: 11 Zon: 0 Lay: 14
        },
        { // Zon: 1
            {14, 17, 20}, // Pat: 11 Zon: 1 Lay: 0
            { 0,  0,  0}, // Pat: 11 Zon: 1 Lay: 1
            { 0,  0,  0}, // Pat: 11 Zon: 1 Lay: 2
            {28, 29, 30}, // Pat: 11 Zon: 1 Lay: 3
            {29, 31, 33}, // Pat: 11 Zon: 1 Lay: 4
            { 0,  0,  0}, // Pat: 11 Zon: 1 Lay: 5
            { 0,  0,  0}, // Pat: 11 Zon: 1 Lay: 6
            {28, 29, 31}, // Pat: 11 Zon: 1 Lay: 7
            {29, 31, 34}, // Pat: 11 Zon: 1 Lay: 8
            {12, 15, 19}, // Pat: 11 Zon: 1 Lay: 9
            {24, 25, 26}, // Pat: 11 Zon: 1 Lay: 10
            { 9, 13, 17}, // Pat: 11 Zon: 1 Lay: 11
            { 0,  0,  0}, // Pat: 11 Zon: 1 Lay: 12
            { 0,  0,  0}, // Pat: 11 Zon: 1 Lay: 13
            { 0,  0,  0}, // Pat: 11 Zon: 1 Lay: 14
        },
        { // Zon: 2
            {15, 18, 21}, // Pat: 11 Zon: 2 Lay: 0
            { 0,  0,  0}, // Pat: 11 Zon: 2 Lay: 1
            { 0,  0,  0}, // Pat: 11 Zon: 2 Lay: 2
            {27, 28, 30}, // Pat: 11 Zon: 2 Lay: 3
            {29, 30, 32}, // Pat: 11 Zon: 2 Lay: 4
            { 0,  0,  0}, // Pat: 11 Zon: 2 Lay: 5
            { 0,  0,  0}, // Pat: 11 Zon: 2 Lay: 6
            {28, 29, 31}, // Pat: 11 Zon: 2 Lay: 7
            {29, 31, 33}, // Pat: 11 Zon: 2 Lay: 8
            {13, 16, 20}, // Pat: 11 Zon: 2 Lay: 9
            {24, 25, 26}, // Pat: 11 Zon: 2 Lay: 10
            { 0,  0,  0}, // Pat: 11 Zon: 2 Lay: 11
            { 0,  0,  0}, // Pat: 11 Zon: 2 Lay: 12
            { 0,  0,  0}, // Pat: 11 Zon: 2 Lay: 13
            { 0,  0,  0}, // Pat: 11 Zon: 2 Lay: 14
        },
        { // Zon: 3
            {16, 20, 23}, // Pat: 11 Zon: 3 Lay: 0
            { 0,  0,  0}, // Pat: 11 Zon: 3 Lay: 1
            { 0,  0,  0}, // Pat: 11 Zon: 3 Lay: 2
            {27, 28, 29}, // Pat: 11 Zon: 3 Lay: 3
            {28, 29, 30}, // Pat: 11 Zon: 3 Lay: 4
            { 0,  0,  0}, // Pat: 11 Zon: 3 Lay: 5
            { 0,  0,  0}, // Pat: 11 Zon: 3 Lay: 6
            {27, 28, 30}, // Pat: 11 Zon: 3 Lay: 7
            {28, 30, 32}, // Pat: 11 Zon: 3 Lay: 8
            {14, 18, 22}, // Pat: 11 Zon: 3 Lay: 9
            {24, 25, 26}, // Pat: 11 Zon: 3 Lay: 10
            { 0,  0,  0}, // Pat: 11 Zon: 3 Lay: 11
            { 0,  0,  0}, // Pat: 11 Zon: 3 Lay: 12
            { 0,  0,  0}, // Pat: 11 Zon: 3 Lay: 13
            { 0,  0,  0}, // Pat: 11 Zon: 3 Lay: 14
        },
        { // Zon: 4
            {16, 20, 23}, // Pat: 11 Zon: 4 Lay: 0
            {21, 23, 25}, // Pat: 11 Zon: 4 Lay: 1
            { 0,  0,  0}, // Pat: 11 Zon: 4 Lay: 2
            {27, 28, 29}, // Pat: 11 Zon: 4 Lay: 3
            {28, 29, 30}, // Pat: 11 Zon: 4 Lay: 4
            {22, 24, 25}, // Pat: 11 Zon: 4 Lay: 5
            { 0,  0,  0}, // Pat: 11 Zon: 4 Lay: 6
            {27, 28, 30}, // Pat: 11 Zon: 4 Lay: 7
            {28, 30, 32}, // Pat: 11 Zon: 4 Lay: 8
            {14, 18, 22}, // Pat: 11 Zon: 4 Lay: 9
            { 0,  0,  0}, // Pat: 11 Zon: 4 Lay: 10
            { 0,  0,  0}, // Pat: 11 Zon: 4 Lay: 11
            { 0,  0,  0}, // Pat: 11 Zon: 4 Lay: 12
            { 0,  0,  0}, // Pat: 11 Zon: 4 Lay: 13
            { 0,  0,  0}, // Pat: 11 Zon: 4 Lay: 14
        },
        { // Zon: 5
            { 0,  0,  0}, // Pat: 11 Zon: 5 Lay: 0
            {22, 24, 25}, // Pat: 11 Zon: 5 Lay: 1
            { 0,  0,  0}, // Pat: 11 Zon: 5 Lay: 2
            {27, 28, 29}, // Pat: 11 Zon: 5 Lay: 3
            {28, 29, 30}, // Pat: 11 Zon: 5 Lay: 4
            {22, 24, 25}, // Pat: 11 Zon: 5 Lay: 5
            {24, 25, 26}, // Pat: 11 Zon: 5 Lay: 6
            {27, 28, 29}, // Pat: 11 Zon: 5 Lay: 7
            {28, 29, 30}, // Pat: 11 Zon: 5 Lay: 8
            { 0,  0,  0}, // Pat: 11 Zon: 5 Lay: 9
            { 0,  0,  0}, // Pat: 11 Zon: 5 Lay: 10
            { 0,  0,  0}, // Pat: 11 Zon: 5 Lay: 11
            { 0,  0,  0}, // Pat: 11 Zon: 5 Lay: 12
            { 0,  0,  0}, // Pat: 11 Zon: 5 Lay: 13
            { 0,  0,  0}, // Pat: 11 Zon: 5 Lay: 14
        },
        { // Zon: 6
            { 0,  0,  0}, // Pat: 11 Zon: 6 Lay: 0
            { 0,  0,  0}, // Pat: 11 Zon: 6 Lay: 1
            { 0,  0,  0}, // Pat: 11 Zon: 6 Lay: 2
            { 0,  0,  0}, // Pat: 11 Zon: 6 Lay: 3
            { 0,  0,  0}, // Pat: 11 Zon: 6 Lay: 4
            { 0,  0,  0}, // Pat: 11 Zon: 6 Lay: 5
            { 0,  0,  0}, // Pat: 11 Zon: 6 Lay: 6
            { 0,  0,  0}, // Pat: 11 Zon: 6 Lay: 7
            { 0,  0,  0}, // Pat: 11 Zon: 6 Lay: 8
            { 0,  0,  0}, // Pat: 11 Zon: 6 Lay: 9
            { 0,  0,  0}, // Pat: 11 Zon: 6 Lay: 10
            { 0,  0,  0}, // Pat: 11 Zon: 6 Lay: 11
            { 0,  0,  0}, // Pat: 11 Zon: 6 Lay: 12
            { 0,  0,  0}, // Pat: 11 Zon: 6 Lay: 13
            { 0,  0,  0}, // Pat: 11 Zon: 6 Lay: 14
        }
    },
    { // Pat: 12
        { // Zon: 0
            {17, 21, 25}, // Pat: 12 Zon: 0 Lay: 0
            { 0,  0,  0}, // Pat: 12 Zon: 0 Lay: 1
            { 0,  0,  0}, // Pat: 12 Zon: 0 Lay: 2
            {26, 27, 29}, // Pat: 12 Zon: 0 Lay: 3
            {26, 28, 31}, // Pat: 12 Zon: 0 Lay: 4
            { 0,  0,  0}, // Pat: 12 Zon: 0 Lay: 5
            { 0,  0,  0}, // Pat: 12 Zon: 0 Lay: 6
            {26, 28, 30}, // Pat: 12 Zon: 0 Lay: 7
            {26, 29, 32}, // Pat: 12 Zon: 0 Lay: 8
            { 0,  0,  0}, // Pat: 12 Zon: 0 Lay: 9
            {25, 25, 26}, // Pat: 12 Zon: 0 Lay: 10
            {13, 19, 25}, // Pat: 12 Zon: 0 Lay: 11
            { 0,  0,  0}, // Pat: 12 Zon: 0 Lay: 12
            { 0,  0,  0}, // Pat: 12 Zon: 0 Lay: 13
            { 0,  0,  0}, // Pat: 12 Zon: 0 Lay: 14
        },
        { // Zon: 1
            {18, 22, 26}, // Pat: 12 Zon: 1 Lay: 0
            { 0,  0,  0}, // Pat: 12 Zon: 1 Lay: 1
            { 0,  0,  0}, // Pat: 12 Zon: 1 Lay: 2
            {26, 27, 29}, // Pat: 12 Zon: 1 Lay: 3
            {26, 28, 30}, // Pat: 12 Zon: 1 Lay: 4
            { 0,  0,  0}, // Pat: 12 Zon: 1 Lay: 5
            { 0,  0,  0}, // Pat: 12 Zon: 1 Lay: 6
            {26, 27, 29}, // Pat: 12 Zon: 1 Lay: 7
            {26, 28, 30}, // Pat: 12 Zon: 1 Lay: 8
            {17, 21, 25}, // Pat: 12 Zon: 1 Lay: 9
            {25, 26, 26}, // Pat: 12 Zon: 1 Lay: 10
            {15, 20, 25}, // Pat: 12 Zon: 1 Lay: 11
            { 0,  0,  0}, // Pat: 12 Zon: 1 Lay: 12
            { 0,  0,  0}, // Pat: 12 Zon: 1 Lay: 13
            { 0,  0,  0}, // Pat: 12 Zon: 1 Lay: 14
        },
        { // Zon: 2
            {19, 22, 26}, // Pat: 12 Zon: 2 Lay: 0
            { 0,  0,  0}, // Pat: 12 Zon: 2 Lay: 1
            { 0,  0,  0}, // Pat: 12 Zon: 2 Lay: 2
            {26, 27, 28}, // Pat: 12 Zon: 2 Lay: 3
            {26, 28, 29}, // Pat: 12 Zon: 2 Lay: 4
            { 0,  0,  0}, // Pat: 12 Zon: 2 Lay: 5
            { 0,  0,  0}, // Pat: 12 Zon: 2 Lay: 6
            {26, 27, 29}, // Pat: 12 Zon: 2 Lay: 7
            {26, 28, 30}, // Pat: 12 Zon: 2 Lay: 8
            {17, 22, 26}, // Pat: 12 Zon: 2 Lay: 9
            {25, 26, 26}, // Pat: 12 Zon: 2 Lay: 10
            { 0,  0,  0}, // Pat: 12 Zon: 2 Lay: 11
            { 0,  0,  0}, // Pat: 12 Zon: 2 Lay: 12
            { 0,  0,  0}, // Pat: 12 Zon: 2 Lay: 13
            { 0,  0,  0}, // Pat: 12 Zon: 2 Lay: 14
        },
        { // Zon: 3
            {20, 23, 27}, // Pat: 12 Zon: 3 Lay: 0
            { 0,  0,  0}, // Pat: 12 Zon: 3 Lay: 1
            { 0,  0,  0}, // Pat: 12 Zon: 3 Lay: 2
            {26, 27, 28}, // Pat: 12 Zon: 3 Lay: 3
            {26, 27, 29}, // Pat: 12 Zon: 3 Lay: 4
            { 0,  0,  0}, // Pat: 12 Zon: 3 Lay: 5
            { 0,  0,  0}, // Pat: 12 Zon: 3 Lay: 6
            {26, 27, 28}, // Pat: 12 Zon: 3 Lay: 7
            {26, 28, 29}, // Pat: 12 Zon: 3 Lay: 8
            {18, 22, 27}, // Pat: 12 Zon: 3 Lay: 9
            {25, 26, 26}, // Pat: 12 Zon: 3 Lay: 10
            { 0,  0,  0}, // Pat: 12 Zon: 3 Lay: 11
            { 0,  0,  0}, // Pat: 12 Zon: 3 Lay: 12
            { 0,  0,  0}, // Pat: 12 Zon: 3 Lay: 13
            { 0,  0,  0}, // Pat: 12 Zon: 3 Lay: 14
        },
        { // Zon: 4
            {20, 23, 27}, // Pat: 12 Zon: 4 Lay: 0
            {23, 25, 26}, // Pat: 12 Zon: 4 Lay: 1
            { 0,  0,  0}, // Pat: 12 Zon: 4 Lay: 2
            {26, 27, 28}, // Pat: 12 Zon: 4 Lay: 3
            {26, 27, 29}, // Pat: 12 Zon: 4 Lay: 4
            {23, 25, 26}, // Pat: 12 Zon: 4 Lay: 5
            { 0,  0,  0}, // Pat: 12 Zon: 4 Lay: 6
            {26, 27, 28}, // Pat: 12 Zon: 4 Lay: 7
            {26, 28, 29}, // Pat: 12 Zon: 4 Lay: 8
            {18, 22, 27}, // Pat: 12 Zon: 4 Lay: 9
            { 0,  0,  0}, // Pat: 12 Zon: 4 Lay: 10
            { 0,  0,  0}, // Pat: 12 Zon: 4 Lay: 11
            { 0,  0,  0}, // Pat: 12 Zon: 4 Lay: 12
            { 0,  0,  0}, // Pat: 12 Zon: 4 Lay: 13
            { 0,  0,  0}, // Pat: 12 Zon: 4 Lay: 14
        },
        { // Zon: 5
            { 0,  0,  0}, // Pat: 12 Zon: 5 Lay: 0
            {23, 25, 26}, // Pat: 12 Zon: 5 Lay: 1
            { 0,  0,  0}, // Pat: 12 Zon: 5 Lay: 2
            {26, 27, 28}, // Pat: 12 Zon: 5 Lay: 3
            {26, 27, 28}, // Pat: 12 Zon: 5 Lay: 4
            {23, 25, 26}, // Pat: 12 Zon: 5 Lay: 5
            {25, 26, 26}, // Pat: 12 Zon: 5 Lay: 6
            {26, 27, 28}, // Pat: 12 Zon: 5 Lay: 7
            {26, 27, 29}, // Pat: 12 Zon: 5 Lay: 8
            { 0,  0,  0}, // Pat: 12 Zon: 5 Lay: 9
            { 0,  0,  0}, // Pat: 12 Zon: 5 Lay: 10
            { 0,  0,  0}, // Pat: 12 Zon: 5 Lay: 11
            { 0,  0,  0}, // Pat: 12 Zon: 5 Lay: 12
            { 0,  0,  0}, // Pat: 12 Zon: 5 Lay: 13
            { 0,  0,  0}, // Pat: 12 Zon: 5 Lay: 14
        },
        { // Zon: 6
            { 0,  0,  0}, // Pat: 12 Zon: 6 Lay: 0
            { 0,  0,  0}, // Pat: 12 Zon: 6 Lay: 1
            { 0,  0,  0}, // Pat: 12 Zon: 6 Lay: 2
            { 0,  0,  0}, // Pat: 12 Zon: 6 Lay: 3
            { 0,  0,  0}, // Pat: 12 Zon: 6 Lay: 4
            { 0,  0,  0}, // Pat: 12 Zon: 6 Lay: 5
            { 0,  0,  0}, // Pat: 12 Zon: 6 Lay: 6
            { 0,  0,  0}, // Pat: 12 Zon: 6 Lay: 7
            { 0,  0,  0}, // Pat: 12 Zon: 6 Lay: 8
            { 0,  0,  0}, // Pat: 12 Zon: 6 Lay: 9
            { 0,  0,  0}, // Pat: 12 Zon: 6 Lay: 10
            { 0,  0,  0}, // Pat: 12 Zon: 6 Lay: 11
            { 0,  0,  0}, // Pat: 12 Zon: 6 Lay: 12
            { 0,  0,  0}, // Pat: 12 Zon: 6 Lay: 13
            { 0,  0,  0}, // Pat: 12 Zon: 6 Lay: 14
        }
    },
    { // Pat: 13
        { // Zon: 0
            {22, 26, 30}, // Pat: 13 Zon: 0 Lay: 0
            { 0,  0,  0}, // Pat: 13 Zon: 0 Lay: 1
            { 0,  0,  0}, // Pat: 13 Zon: 0 Lay: 2
            {25, 26, 27}, // Pat: 13 Zon: 0 Lay: 3
            {24, 26, 28}, // Pat: 13 Zon: 0 Lay: 4
            { 0,  0,  0}, // Pat: 13 Zon: 0 Lay: 5
            { 0,  0,  0}, // Pat: 13 Zon: 0 Lay: 6
            {25, 26, 27}, // Pat: 13 Zon: 0 Lay: 7
            {24, 26, 28}, // Pat: 13 Zon: 0 Lay: 8
            { 0,  0,  0}, // Pat: 13 Zon: 0 Lay: 9
            {25, 26, 27}, // Pat: 13 Zon: 0 Lay: 10
            {21, 26, 31}, // Pat: 13 Zon: 0 Lay: 11
            { 0,  0,  0}, // Pat: 13 Zon: 0 Lay: 12
            { 0,  0,  0}, // Pat: 13 Zon: 0 Lay: 13
            { 0,  0,  0}, // Pat: 13 Zon: 0 Lay: 14
        },
        { // Zon: 1
            {23, 26, 29}, // Pat: 13 Zon: 1 Lay: 0
            { 0,  0,  0}, // Pat: 13 Zon: 1 Lay: 1
            { 0,  0,  0}, // Pat: 13 Zon: 1 Lay: 2
            {25, 26, 27}, // Pat: 13 Zon: 1 Lay: 3
            {25, 26, 27}, // Pat: 13 Zon: 1 Lay: 4
            { 0,  0,  0}, // Pat: 13 Zon: 1 Lay: 5
            { 0,  0,  0}, // Pat: 13 Zon: 1 Lay: 6
            {25, 26, 27}, // Pat: 13 Zon: 1 Lay: 7
            {24, 26, 28}, // Pat: 13 Zon: 1 Lay: 8
            {22, 26, 30}, // Pat: 13 Zon: 1 Lay: 9
            {25, 26, 27}, // Pat: 13 Zon: 1 Lay: 10
            {22, 26, 30}, // Pat: 13 Zon: 1 Lay: 11
            { 0,  0,  0}, // Pat: 13 Zon: 1 Lay: 12
            { 0,  0,  0}, // Pat: 13 Zon: 1 Lay: 13
            { 0,  0,  0}, // Pat: 13 Zon: 1 Lay: 14
        },
        { // Zon: 2
            {23, 26, 29}, // Pat: 13 Zon: 2 Lay: 0
            { 0,  0,  0}, // Pat: 13 Zon: 2 Lay: 1
            { 0,  0,  0}, // Pat: 13 Zon: 2 Lay: 2
            {25, 26, 27}, // Pat: 13 Zon: 2 Lay: 3
            {25, 26, 27}, // Pat: 13 Zon: 2 Lay: 4
            { 0,  0,  0}, // Pat: 13 Zon: 2 Lay: 5
            { 0,  0,  0}, // Pat: 13 Zon: 2 Lay: 6
            {25, 26, 27}, // Pat: 13 Zon: 2 Lay: 7
            {24, 26, 28}, // Pat: 13 Zon: 2 Lay: 8
            {22, 26, 30}, // Pat: 13 Zon: 2 Lay: 9
            {25, 26, 27}, // Pat: 13 Zon: 2 Lay: 10
            { 0,  0,  0}, // Pat: 13 Zon: 2 Lay: 11
            { 0,  0,  0}, // Pat: 13 Zon: 2 Lay: 12
            { 0,  0,  0}, // Pat: 13 Zon: 2 Lay: 13
            { 0,  0,  0}, // Pat: 13 Zon: 2 Lay: 14
        },
        { // Zon: 3
            {23, 26, 29}, // Pat: 13 Zon: 3 Lay: 0
            { 0,  0,  0}, // Pat: 13 Zon: 3 Lay: 1
            { 0,  0,  0}, // Pat: 13 Zon: 3 Lay: 2
            {25, 26, 27}, // Pat: 13 Zon: 3 Lay: 3
            {25, 26, 27}, // Pat: 13 Zon: 3 Lay: 4
            { 0,  0,  0}, // Pat: 13 Zon: 3 Lay: 5
            { 0,  0,  0}, // Pat: 13 Zon: 3 Lay: 6
            {25, 26, 27}, // Pat: 13 Zon: 3 Lay: 7
            {25, 26, 27}, // Pat: 13 Zon: 3 Lay: 8
            {22, 26, 30}, // Pat: 13 Zon: 3 Lay: 9
            {25, 26, 27}, // Pat: 13 Zon: 3 Lay: 10
            { 0,  0,  0}, // Pat: 13 Zon: 3 Lay: 11
            { 0,  0,  0}, // Pat: 13 Zon: 3 Lay: 12
            { 0,  0,  0}, // Pat: 13 Zon: 3 Lay: 13
            { 0,  0,  0}, // Pat: 13 Zon: 3 Lay: 14
        },
        { // Zon: 4
            {23, 26, 29}, // Pat: 13 Zon: 4 Lay: 0
            {24, 26, 28}, // Pat: 13 Zon: 4 Lay: 1
            { 0,  0,  0}, // Pat: 13 Zon: 4 Lay: 2
            {25, 26, 27}, // Pat: 13 Zon: 4 Lay: 3
            {25, 26, 27}, // Pat: 13 Zon: 4 Lay: 4
            {24, 26, 28}, // Pat: 13 Zon: 4 Lay: 5
            { 0,  0,  0}, // Pat: 13 Zon: 4 Lay: 6
            {25, 26, 27}, // Pat: 13 Zon: 4 Lay: 7
            {25, 26, 27}, // Pat: 13 Zon: 4 Lay: 8
            {22, 26, 30}, // Pat: 13 Zon: 4 Lay: 9
            { 0,  0,  0}, // Pat: 13 Zon: 4 Lay: 10
            { 0,  0,  0}, // Pat: 13 Zon: 4 Lay: 11
            { 0,  0,  0}, // Pat: 13 Zon: 4 Lay: 12
            { 0,  0,  0}, // Pat: 13 Zon: 4 Lay: 13
            { 0,  0,  0}, // Pat: 13 Zon: 4 Lay: 14
        },
        { // Zon: 5
            { 0,  0,  0}, // Pat: 13 Zon: 5 Lay: 0
            {24, 26, 28}, // Pat: 13 Zon: 5 Lay: 1
            { 0,  0,  0}, // Pat: 13 Zon: 5 Lay: 2
            {25, 26, 27}, // Pat: 13 Zon: 5 Lay: 3
            {25, 26, 27}, // Pat: 13 Zon: 5 Lay: 4
            {24, 26, 28}, // Pat: 13 Zon: 5 Lay: 5
            {25, 26, 27}, // Pat: 13 Zon: 5 Lay: 6
            {25, 26, 27}, // Pat: 13 Zon: 5 Lay: 7
            {25, 26, 27}, // Pat: 13 Zon: 5 Lay: 8
            { 0,  0,  0}, // Pat: 13 Zon: 5 Lay: 9
            { 0,  0,  0}, // Pat: 13 Zon: 5 Lay: 10
            { 0,  0,  0}, // Pat: 13 Zon: 5 Lay: 11
            { 0,  0,  0}, // Pat: 13 Zon: 5 Lay: 12
            { 0,  0,  0}, // Pat: 13 Zon: 5 Lay: 13
            { 0,  0,  0}, // Pat: 13 Zon: 5 Lay: 14
        },
        { // Zon: 6
            { 0,  0,  0}, // Pat: 13 Zon: 6 Lay: 0
            { 0,  0,  0}, // Pat: 13 Zon: 6 Lay: 1
            { 0,  0,  0}, // Pat: 13 Zon: 6 Lay: 2
            { 0,  0,  0}, // Pat: 13 Zon: 6 Lay: 3
            { 0,  0,  0}, // Pat: 13 Zon: 6 Lay: 4
            { 0,  0,  0}, // Pat: 13 Zon: 6 Lay: 5
            { 0,  0,  0}, // Pat: 13 Zon: 6 Lay: 6
            { 0,  0,  0}, // Pat: 13 Zon: 6 Lay: 7
            { 0,  0,  0}, // Pat: 13 Zon: 6 Lay: 8
            { 0,  0,  0}, // Pat: 13 Zon: 6 Lay: 9
            { 0,  0,  0}, // Pat: 13 Zon: 6 Lay: 10
            { 0,  0,  0}, // Pat: 13 Zon: 6 Lay: 11
            { 0,  0,  0}, // Pat: 13 Zon: 6 Lay: 12
            { 0,  0,  0}, // Pat: 13 Zon: 6 Lay: 13
            { 0,  0,  0}, // Pat: 13 Zon: 6 Lay: 14
        }
    },
    { // Pat: 14
        { // Zon: 0
            {27, 31, 35}, // Pat: 14 Zon: 0 Lay: 0
            { 0,  0,  0}, // Pat: 14 Zon: 0 Lay: 1
            { 0,  0,  0}, // Pat: 14 Zon: 0 Lay: 2
            {23, 25, 26}, // Pat: 14 Zon: 0 Lay: 3
            {21, 24, 26}, // Pat: 14 Zon: 0 Lay: 4
            { 0,  0,  0}, // Pat: 14 Zon: 0 Lay: 5
            { 0,  0,  0}, // Pat: 14 Zon: 0 Lay: 6
            {22, 24, 26}, // Pat: 14 Zon: 0 Lay: 7
            {20, 23, 26}, // Pat: 14 Zon: 0 Lay: 8
            { 0,  0,  0}, // Pat: 14 Zon: 0 Lay: 9
            {26, 27, 27}, // Pat: 14 Zon: 0 Lay: 10
            {27, 33, 39}, // Pat: 14 Zon: 0 Lay: 11
            { 0,  0,  0}, // Pat: 14 Zon: 0 Lay: 12
            { 0,  0,  0}, // Pat: 14 Zon: 0 Lay: 13
            { 0,  0,  0}, // Pat: 14 Zon: 0 Lay: 14
        },
        { // Zon: 1
            {26, 30, 34}, // Pat: 14 Zon: 1 Lay: 0
            { 0,  0,  0}, // Pat: 14 Zon: 1 Lay: 1
            { 0,  0,  0}, // Pat: 14 Zon: 1 Lay: 2
            {23, 25, 26}, // Pat: 14 Zon: 1 Lay: 3
            {22, 24, 26}, // Pat: 14 Zon: 1 Lay: 4
            { 0,  0,  0}, // Pat: 14 Zon: 1 Lay: 5
            { 0,  0,  0}, // Pat: 14 Zon: 1 Lay: 6
            {23, 25, 26}, // Pat: 14 Zon: 1 Lay: 7
            {22, 24, 26}, // Pat: 14 Zon: 1 Lay: 8
            {27, 31, 35}, // Pat: 14 Zon: 1 Lay: 9
            {26, 26, 27}, // Pat: 14 Zon: 1 Lay: 10
            {27, 32, 37}, // Pat: 14 Zon: 1 Lay: 11
            { 0,  0,  0}, // Pat: 14 Zon: 1 Lay: 12
            { 0,  0,  0}, // Pat: 14 Zon: 1 Lay: 13
            { 0,  0,  0}, // Pat: 14 Zon: 1 Lay: 14
        },
        { // Zon: 2
            {26, 30, 33}, // Pat: 14 Zon: 2 Lay: 0
            { 0,  0,  0}, // Pat: 14 Zon: 2 Lay: 1
            { 0,  0,  0}, // Pat: 14 Zon: 2 Lay: 2
            {24, 25, 26}, // Pat: 14 Zon: 2 Lay: 3
            {23, 24, 26}, // Pat: 14 Zon: 2 Lay: 4
            { 0,  0,  0}, // Pat: 14 Zon: 2 Lay: 5
            { 0,  0,  0}, // Pat: 14 Zon: 2 Lay: 6
            {23, 25, 26}, // Pat: 14 Zon: 2 Lay: 7
            {22, 24, 26}, // Pat: 14 Zon: 2 Lay: 8
            {26, 30, 35}, // Pat: 14 Zon: 2 Lay: 9
            {26, 26, 27}, // Pat: 14 Zon: 2 Lay: 10
            { 0,  0,  0}, // Pat: 14 Zon: 2 Lay: 11
            { 0,  0,  0}, // Pat: 14 Zon: 2 Lay: 12
            { 0,  0,  0}, // Pat: 14 Zon: 2 Lay: 13
            { 0,  0,  0}, // Pat: 14 Zon: 2 Lay: 14
        },
        { // Zon: 3
            {25, 29, 32}, // Pat: 14 Zon: 3 Lay: 0
            { 0,  0,  0}, // Pat: 14 Zon: 3 Lay: 1
            { 0,  0,  0}, // Pat: 14 Zon: 3 Lay: 2
            {24, 25, 26}, // Pat: 14 Zon: 3 Lay: 3
            {23, 25, 26}, // Pat: 14 Zon: 3 Lay: 4
            { 0,  0,  0}, // Pat: 14 Zon: 3 Lay: 5
            { 0,  0,  0}, // Pat: 14 Zon: 3 Lay: 6
            {24, 25, 26}, // Pat: 14 Zon: 3 Lay: 7
            {23, 24, 26}, // Pat: 14 Zon: 3 Lay: 8
            {25, 30, 34}, // Pat: 14 Zon: 3 Lay: 9
            {26, 26, 27}, // Pat: 14 Zon: 3 Lay: 10
            { 0,  0,  0}, // Pat: 14 Zon: 3 Lay: 11
            { 0,  0,  0}, // Pat: 14 Zon: 3 Lay: 12
            { 0,  0,  0}, // Pat: 14 Zon: 3 Lay: 13
            { 0,  0,  0}, // Pat: 14 Zon: 3 Lay: 14
        },
        { // Zon: 4
            {25, 29, 32}, // Pat: 14 Zon: 4 Lay: 0
            {26, 27, 29}, // Pat: 14 Zon: 4 Lay: 1
            { 0,  0,  0}, // Pat: 14 Zon: 4 Lay: 2
            {24, 25, 26}, // Pat: 14 Zon: 4 Lay: 3
            {23, 25, 26}, // Pat: 14 Zon: 4 Lay: 4
            {26, 27, 29}, // Pat: 14 Zon: 4 Lay: 5
            { 0,  0,  0}, // Pat: 14 Zon: 4 Lay: 6
            {24, 25, 26}, // Pat: 14 Zon: 4 Lay: 7
            {23, 24, 26}, // Pat: 14 Zon: 4 Lay: 8
            {25, 30, 34}, // Pat: 14 Zon: 4 Lay: 9
            { 0,  0,  0}, // Pat: 14 Zon: 4 Lay: 10
            { 0,  0,  0}, // Pat: 14 Zon: 4 Lay: 11
            { 0,  0,  0}, // Pat: 14 Zon: 4 Lay: 12
            { 0,  0,  0}, // Pat: 14 Zon: 4 Lay: 13
            { 0,  0,  0}, // Pat: 14 Zon: 4 Lay: 14
        },
        { // Zon: 5
            { 0,  0,  0}, // Pat: 14 Zon: 5 Lay: 0
            {26, 27, 29}, // Pat: 14 Zon: 5 Lay: 1
            { 0,  0,  0}, // Pat: 14 Zon: 5 Lay: 2
            {24, 25, 26}, // Pat: 14 Zon: 5 Lay: 3
            {24, 25, 26}, // Pat: 14 Zon: 5 Lay: 4
            {26, 27, 29}, // Pat: 14 Zon: 5 Lay: 5
            {26, 26, 27}, // Pat: 14 Zon: 5 Lay: 6
            {24, 25, 26}, // Pat: 14 Zon: 5 Lay: 7
            {23, 25, 26}, // Pat: 14 Zon: 5 Lay: 8
            { 0,  0,  0}, // Pat: 14 Zon: 5 Lay: 9
            { 0,  0,  0}, // Pat: 14 Zon: 5 Lay: 10
            { 0,  0,  0}, // Pat: 14 Zon: 5 Lay: 11
            { 0,  0,  0}, // Pat: 14 Zon: 5 Lay: 12
            { 0,  0,  0}, // Pat: 14 Zon: 5 Lay: 13
            { 0,  0,  0}, // Pat: 14 Zon: 5 Lay: 14
        },
        { // Zon: 6
            { 0,  0,  0}, // Pat: 14 Zon: 6 Lay: 0
            { 0,  0,  0}, // Pat: 14 Zon: 6 Lay: 1
            { 0,  0,  0}, // Pat: 14 Zon: 6 Lay: 2
            { 0,  0,  0}, // Pat: 14 Zon: 6 Lay: 3
            { 0,  0,  0}, // Pat: 14 Zon: 6 Lay: 4
            { 0,  0,  0}, // Pat: 14 Zon: 6 Lay: 5
            { 0,  0,  0}, // Pat: 14 Zon: 6 Lay: 6
            { 0,  0,  0}, // Pat: 14 Zon: 6 Lay: 7
            { 0,  0,  0}, // Pat: 14 Zon: 6 Lay: 8
            { 0,  0,  0}, // Pat: 14 Zon: 6 Lay: 9
            { 0,  0,  0}, // Pat: 14 Zon: 6 Lay: 10
            { 0,  0,  0}, // Pat: 14 Zon: 6 Lay: 11
            { 0,  0,  0}, // Pat: 14 Zon: 6 Lay: 12
            { 0,  0,  0}, // Pat: 14 Zon: 6 Lay: 13
            { 0,  0,  0}, // Pat: 14 Zon: 6 Lay: 14
        }
    },
    { // Pat: 15
        { // Zon: 0
            {33, 37, 41}, // Pat: 15 Zon: 0 Lay: 0
            { 0,  0,  0}, // Pat: 15 Zon: 0 Lay: 1
            { 0,  0,  0}, // Pat: 15 Zon: 0 Lay: 2
            {21, 23, 24}, // Pat: 15 Zon: 0 Lay: 3
            {18, 20, 22}, // Pat: 15 Zon: 0 Lay: 4
            { 0,  0,  0}, // Pat: 15 Zon: 0 Lay: 5
            { 0,  0,  0}, // Pat: 15 Zon: 0 Lay: 6
            {20, 22, 24}, // Pat: 15 Zon: 0 Lay: 7
            {17, 20, 22}, // Pat: 15 Zon: 0 Lay: 8
            { 0,  0,  0}, // Pat: 15 Zon: 0 Lay: 9
            {26, 27, 28}, // Pat: 15 Zon: 0 Lay: 10
            {36, 41, 45}, // Pat: 15 Zon: 0 Lay: 11
            { 0,  0,  0}, // Pat: 15 Zon: 0 Lay: 12
            { 0,  0,  0}, // Pat: 15 Zon: 0 Lay: 13
            { 0,  0,  0}, // Pat: 15 Zon: 0 Lay: 14
        },
        { // Zon: 1
            {32, 35, 38}, // Pat: 15 Zon: 1 Lay: 0
            { 0,  0,  0}, // Pat: 15 Zon: 1 Lay: 1
            { 0,  0,  0}, // Pat: 15 Zon: 1 Lay: 2
            {22, 23, 24}, // Pat: 15 Zon: 1 Lay: 3
            {19, 21, 23}, // Pat: 15 Zon: 1 Lay: 4
            { 0,  0,  0}, // Pat: 15 Zon: 1 Lay: 5
            { 0,  0,  0}, // Pat: 15 Zon: 1 Lay: 6
            {21, 23, 24}, // Pat: 15 Zon: 1 Lay: 7
            {18, 21, 23}, // Pat: 15 Zon: 1 Lay: 8
            {33, 37, 40}, // Pat: 15 Zon: 1 Lay: 9
            {26, 27, 28}, // Pat: 15 Zon: 1 Lay: 10
            {35, 39, 43}, // Pat: 15 Zon: 1 Lay: 11
            { 0,  0,  0}, // Pat: 15 Zon: 1 Lay: 12
            { 0,  0,  0}, // Pat: 15 Zon: 1 Lay: 13
            { 0,  0,  0}, // Pat: 15 Zon: 1 Lay: 14
        },
        { // Zon: 2
            {31, 34, 37}, // Pat: 15 Zon: 2 Lay: 0
            { 0,  0,  0}, // Pat: 15 Zon: 2 Lay: 1
            { 0,  0,  0}, // Pat: 15 Zon: 2 Lay: 2
            {22, 24, 25}, // Pat: 15 Zon: 2 Lay: 3
            {20, 22, 23}, // Pat: 15 Zon: 2 Lay: 4
            { 0,  0,  0}, // Pat: 15 Zon: 2 Lay: 5
            { 0,  0,  0}, // Pat: 15 Zon: 2 Lay: 6
            {21, 23, 24}, // Pat: 15 Zon: 2 Lay: 7
            {19, 21, 23}, // Pat: 15 Zon: 2 Lay: 8
            {32, 36, 39}, // Pat: 15 Zon: 2 Lay: 9
            {26, 27, 28}, // Pat: 15 Zon: 2 Lay: 10
            { 0,  0,  0}, // Pat: 15 Zon: 2 Lay: 11
            { 0,  0,  0}, // Pat: 15 Zon: 2 Lay: 12
            { 0,  0,  0}, // Pat: 15 Zon: 2 Lay: 13
            { 0,  0,  0}, // Pat: 15 Zon: 2 Lay: 14
        },
        { // Zon: 3
            {29, 32, 36}, // Pat: 15 Zon: 3 Lay: 0
            { 0,  0,  0}, // Pat: 15 Zon: 3 Lay: 1
            { 0,  0,  0}, // Pat: 15 Zon: 3 Lay: 2
            {23, 24, 25}, // Pat: 15 Zon: 3 Lay: 3
            {22, 23, 24}, // Pat: 15 Zon: 3 Lay: 4
            { 0,  0,  0}, // Pat: 15 Zon: 3 Lay: 5
            { 0,  0,  0}, // Pat: 15 Zon: 3 Lay: 6
            {22, 24, 25}, // Pat: 15 Zon: 3 Lay: 7
            {20, 22, 24}, // Pat: 15 Zon: 3 Lay: 8
            {30, 34, 38}, // Pat: 15 Zon: 3 Lay: 9
            {26, 27, 28}, // Pat: 15 Zon: 3 Lay: 10
            { 0,  0,  0}, // Pat: 15 Zon: 3 Lay: 11
            { 0,  0,  0}, // Pat: 15 Zon: 3 Lay: 12
            { 0,  0,  0}, // Pat: 15 Zon: 3 Lay: 13
            { 0,  0,  0}, // Pat: 15 Zon: 3 Lay: 14
        },
        { // Zon: 4
            {29, 32, 36}, // Pat: 15 Zon: 4 Lay: 0
            {27, 29, 31}, // Pat: 15 Zon: 4 Lay: 1
            { 0,  0,  0}, // Pat: 15 Zon: 4 Lay: 2
            {23, 24, 25}, // Pat: 15 Zon: 4 Lay: 3
            {22, 23, 24}, // Pat: 15 Zon: 4 Lay: 4
            {27, 28, 30}, // Pat: 15 Zon: 4 Lay: 5
            { 0,  0,  0}, // Pat: 15 Zon: 4 Lay: 6
            {22, 24, 25}, // Pat: 15 Zon: 4 Lay: 7
            {20, 22, 24}, // Pat: 15 Zon: 4 Lay: 8
            {30, 34, 38}, // Pat: 15 Zon: 4 Lay: 9
            { 0,  0,  0}, // Pat: 15 Zon: 4 Lay: 10
            { 0,  0,  0}, // Pat: 15 Zon: 4 Lay: 11
            { 0,  0,  0}, // Pat: 15 Zon: 4 Lay: 12
            { 0,  0,  0}, // Pat: 15 Zon: 4 Lay: 13
            { 0,  0,  0}, // Pat: 15 Zon: 4 Lay: 14
        },
        { // Zon: 5
            { 0,  0,  0}, // Pat: 15 Zon: 5 Lay: 0
            {27, 28, 30}, // Pat: 15 Zon: 5 Lay: 1
            { 0,  0,  0}, // Pat: 15 Zon: 5 Lay: 2
            {23, 24, 25}, // Pat: 15 Zon: 5 Lay: 3
            {22, 23, 24}, // Pat: 15 Zon: 5 Lay: 4
            {27, 28, 30}, // Pat: 15 Zon: 5 Lay: 5
            {26, 27, 28}, // Pat: 15 Zon: 5 Lay: 6
            {23, 24, 25}, // Pat: 15 Zon: 5 Lay: 7
            {22, 23, 24}, // Pat: 15 Zon: 5 Lay: 8
            { 0,  0,  0}, // Pat: 15 Zon: 5 Lay: 9
            { 0,  0,  0}, // Pat: 15 Zon: 5 Lay: 10
            { 0,  0,  0}, // Pat: 15 Zon: 5 Lay: 11
            { 0,  0,  0}, // Pat: 15 Zon: 5 Lay: 12
            { 0,  0,  0}, // Pat: 15 Zon: 5 Lay: 13
            { 0,  0,  0}, // Pat: 15 Zon: 5 Lay: 14
        },
        { // Zon: 6
            { 0,  0,  0}, // Pat: 15 Zon: 6 Lay: 0
            { 0,  0,  0}, // Pat: 15 Zon: 6 Lay: 1
            { 0,  0,  0}, // Pat: 15 Zon: 6 Lay: 2
            { 0,  0,  0}, // Pat: 15 Zon: 6 Lay: 3
            { 0,  0,  0}, // Pat: 15 Zon: 6 Lay: 4
            { 0,  0,  0}, // Pat: 15 Zon: 6 Lay: 5
            { 0,  0,  0}, // Pat: 15 Zon: 6 Lay: 6
            { 0,  0,  0}, // Pat: 15 Zon: 6 Lay: 7
            { 0,  0,  0}, // Pat: 15 Zon: 6 Lay: 8
            { 0,  0,  0}, // Pat: 15 Zon: 6 Lay: 9
            { 0,  0,  0}, // Pat: 15 Zon: 6 Lay: 10
            { 0,  0,  0}, // Pat: 15 Zon: 6 Lay: 11
            { 0,  0,  0}, // Pat: 15 Zon: 6 Lay: 12
            { 0,  0,  0}, // Pat: 15 Zon: 6 Lay: 13
            { 0,  0,  0}, // Pat: 15 Zon: 6 Lay: 14
        }
    },
    { // Pat: 16
        { // Zon: 0
            {38, 41, 44}, // Pat: 16 Zon: 0 Lay: 0
            { 0,  0,  0}, // Pat: 16 Zon: 0 Lay: 1
            { 0,  0,  0}, // Pat: 16 Zon: 0 Lay: 2
            {19, 21, 23}, // Pat: 16 Zon: 0 Lay: 3
            {15, 18, 20}, // Pat: 16 Zon: 0 Lay: 4
            { 0,  0,  0}, // Pat: 16 Zon: 0 Lay: 5
            { 0,  0,  0}, // Pat: 16 Zon: 0 Lay: 6
            {18, 20, 22}, // Pat: 16 Zon: 0 Lay: 7
            {14, 17, 19}, // Pat: 16 Zon: 0 Lay: 8
            { 0,  0,  0}, // Pat: 16 Zon: 0 Lay: 9
            {27, 28, 29}, // Pat: 16 Zon: 0 Lay: 10
            {42, 46, 50}, // Pat: 16 Zon: 0 Lay: 11
            { 0,  0,  0}, // Pat: 16 Zon: 0 Lay: 12
            { 0,  0,  0}, // Pat: 16 Zon: 0 Lay: 13
            { 0,  0,  0}, // Pat: 16 Zon: 0 Lay: 14
        },
        { // Zon: 1
            {36, 39, 42}, // Pat: 16 Zon: 1 Lay: 0
            { 0,  0,  0}, // Pat: 16 Zon: 1 Lay: 1
            { 0,  0,  0}, // Pat: 16 Zon: 1 Lay: 2
            {20, 22, 24}, // Pat: 16 Zon: 1 Lay: 3
            {17, 19, 21}, // Pat: 16 Zon: 1 Lay: 4
            { 0,  0,  0}, // Pat: 16 Zon: 1 Lay: 5
            { 0,  0,  0}, // Pat: 16 Zon: 1 Lay: 6
            {19, 21, 22}, // Pat: 16 Zon: 1 Lay: 7
            {16, 18, 20}, // Pat: 16 Zon: 1 Lay: 8
            {38, 41, 45}, // Pat: 16 Zon: 1 Lay: 9
            {26, 27, 28}, // Pat: 16 Zon: 1 Lay: 10
            {40, 43, 48}, // Pat: 16 Zon: 1 Lay: 11
            { 0,  0,  0}, // Pat: 16 Zon: 1 Lay: 12
            { 0,  0,  0}, // Pat: 16 Zon: 1 Lay: 13
            { 0,  0,  0}, // Pat: 16 Zon: 1 Lay: 14
        },
        { // Zon: 2
            {34, 37, 40}, // Pat: 16 Zon: 2 Lay: 0
            { 0,  0,  0}, // Pat: 16 Zon: 2 Lay: 1
            { 0,  0,  0}, // Pat: 16 Zon: 2 Lay: 2
            {21, 22, 24}, // Pat: 16 Zon: 2 Lay: 3
            {18, 20, 22}, // Pat: 16 Zon: 2 Lay: 4
            { 0,  0,  0}, // Pat: 16 Zon: 2 Lay: 5
            { 0,  0,  0}, // Pat: 16 Zon: 2 Lay: 6
            {20, 22, 23}, // Pat: 16 Zon: 2 Lay: 7
            {17, 19, 21}, // Pat: 16 Zon: 2 Lay: 8
            {36, 40, 43}, // Pat: 16 Zon: 2 Lay: 9
            {26, 27, 28}, // Pat: 16 Zon: 2 Lay: 10
            { 0,  0,  0}, // Pat: 16 Zon: 2 Lay: 11
            { 0,  0,  0}, // Pat: 16 Zon: 2 Lay: 12
            { 0,  0,  0}, // Pat: 16 Zon: 2 Lay: 13
            { 0,  0,  0}, // Pat: 16 Zon: 2 Lay: 14
        },
        { // Zon: 3
            {32, 36, 39}, // Pat: 16 Zon: 3 Lay: 0
            { 0,  0,  0}, // Pat: 16 Zon: 3 Lay: 1
            { 0,  0,  0}, // Pat: 16 Zon: 3 Lay: 2
            {22, 23, 24}, // Pat: 16 Zon: 3 Lay: 3
            {20, 21, 23}, // Pat: 16 Zon: 3 Lay: 4
            { 0,  0,  0}, // Pat: 16 Zon: 3 Lay: 5
            { 0,  0,  0}, // Pat: 16 Zon: 3 Lay: 6
            {21, 22, 24}, // Pat: 16 Zon: 3 Lay: 7
            {18, 20, 22}, // Pat: 16 Zon: 3 Lay: 8
            {34, 38, 41}, // Pat: 16 Zon: 3 Lay: 9
            {26, 27, 28}, // Pat: 16 Zon: 3 Lay: 10
            { 0,  0,  0}, // Pat: 16 Zon: 3 Lay: 11
            { 0,  0,  0}, // Pat: 16 Zon: 3 Lay: 12
            { 0,  0,  0}, // Pat: 16 Zon: 3 Lay: 13
            { 0,  0,  0}, // Pat: 16 Zon: 3 Lay: 14
        },
        { // Zon: 4
            {32, 36, 39}, // Pat: 16 Zon: 4 Lay: 0
            {28, 30, 32}, // Pat: 16 Zon: 4 Lay: 1
            { 0,  0,  0}, // Pat: 16 Zon: 4 Lay: 2
            {22, 23, 24}, // Pat: 16 Zon: 4 Lay: 3
            {20, 21, 23}, // Pat: 16 Zon: 4 Lay: 4
            {28, 30, 32}, // Pat: 16 Zon: 4 Lay: 5
            { 0,  0,  0}, // Pat: 16 Zon: 4 Lay: 6
            {21, 22, 24}, // Pat: 16 Zon: 4 Lay: 7
            {18, 20, 22}, // Pat: 16 Zon: 4 Lay: 8
            {34, 38, 41}, // Pat: 16 Zon: 4 Lay: 9
            { 0,  0,  0}, // Pat: 16 Zon: 4 Lay: 10
            { 0,  0,  0}, // Pat: 16 Zon: 4 Lay: 11
            { 0,  0,  0}, // Pat: 16 Zon: 4 Lay: 12
            { 0,  0,  0}, // Pat: 16 Zon: 4 Lay: 13
            { 0,  0,  0}, // Pat: 16 Zon: 4 Lay: 14
        },
        { // Zon: 5
            { 0,  0,  0}, // Pat: 16 Zon: 5 Lay: 0
            {28, 29, 31}, // Pat: 16 Zon: 5 Lay: 1
            { 0,  0,  0}, // Pat: 16 Zon: 5 Lay: 2
            {23, 24, 25}, // Pat: 16 Zon: 5 Lay: 3
            {21, 22, 24}, // Pat: 16 Zon: 5 Lay: 4
            {28, 29, 31}, // Pat: 16 Zon: 5 Lay: 5
            {26, 27, 28}, // Pat: 16 Zon: 5 Lay: 6
            {22, 23, 24}, // Pat: 16 Zon: 5 Lay: 7
            {20, 22, 23}, // Pat: 16 Zon: 5 Lay: 8
            { 0,  0,  0}, // Pat: 16 Zon: 5 Lay: 9
            { 0,  0,  0}, // Pat: 16 Zon: 5 Lay: 10
            { 0,  0,  0}, // Pat: 16 Zon: 5 Lay: 11
            { 0,  0,  0}, // Pat: 16 Zon: 5 Lay: 12
            { 0,  0,  0}, // Pat: 16 Zon: 5 Lay: 13
            { 0,  0,  0}, // Pat: 16 Zon: 5 Lay: 14
        },
        { // Zon: 6
            { 0,  0,  0}, // Pat: 16 Zon: 6 Lay: 0
            { 0,  0,  0}, // Pat: 16 Zon: 6 Lay: 1
            { 0,  0,  0}, // Pat: 16 Zon: 6 Lay: 2
            { 0,  0,  0}, // Pat: 16 Zon: 6 Lay: 3
            { 0,  0,  0}, // Pat: 16 Zon: 6 Lay: 4
            { 0,  0,  0}, // Pat: 16 Zon: 6 Lay: 5
            { 0,  0,  0}, // Pat: 16 Zon: 6 Lay: 6
            { 0,  0,  0}, // Pat: 16 Zon: 6 Lay: 7
            { 0,  0,  0}, // Pat: 16 Zon: 6 Lay: 8
            { 0,  0,  0}, // Pat: 16 Zon: 6 Lay: 9
            { 0,  0,  0}, // Pat: 16 Zon: 6 Lay: 10
            { 0,  0,  0}, // Pat: 16 Zon: 6 Lay: 11
            { 0,  0,  0}, // Pat: 16 Zon: 6 Lay: 12
            { 0,  0,  0}, // Pat: 16 Zon: 6 Lay: 13
            { 0,  0,  0}, // Pat: 16 Zon: 6 Lay: 14
        }
    },
    { // Pat: 17
        { // Zon: 0
            {41, 43, 45}, // Pat: 17 Zon: 0 Lay: 0
            { 0,  0,  0}, // Pat: 17 Zon: 0 Lay: 1
            { 0,  0,  0}, // Pat: 17 Zon: 0 Lay: 2
            {17, 20, 22}, // Pat: 17 Zon: 0 Lay: 3
            {13, 16, 18}, // Pat: 17 Zon: 0 Lay: 4
            { 0,  0,  0}, // Pat: 17 Zon: 0 Lay: 5
            { 0,  0,  0}, // Pat: 17 Zon: 0 Lay: 6
            {16, 18, 20}, // Pat: 17 Zon: 0 Lay: 7
            {11, 14, 17}, // Pat: 17 Zon: 0 Lay: 8
            { 0,  0,  0}, // Pat: 17 Zon: 0 Lay: 9
            {27, 28, 29}, // Pat: 17 Zon: 0 Lay: 10
            {46, 49, 52}, // Pat: 17 Zon: 0 Lay: 11
            { 0,  0,  0}, // Pat: 17 Zon: 0 Lay: 12
            { 0,  0,  0}, // Pat: 17 Zon: 0 Lay: 13
            { 0,  0,  0}, // Pat: 17 Zon: 0 Lay: 14
        },
        { // Zon: 1
            {39, 42, 45}, // Pat: 17 Zon: 1 Lay: 0
            { 0,  0,  0}, // Pat: 17 Zon: 1 Lay: 1
            { 0,  0,  0}, // Pat: 17 Zon: 1 Lay: 2
            {18, 20, 23}, // Pat: 17 Zon: 1 Lay: 3
            {14, 17, 19}, // Pat: 17 Zon: 1 Lay: 4
            { 0,  0,  0}, // Pat: 17 Zon: 1 Lay: 5
            { 0,  0,  0}, // Pat: 17 Zon: 1 Lay: 6
            {17, 19, 21}, // Pat: 17 Zon: 1 Lay: 7
            {13, 16, 18}, // Pat: 17 Zon: 1 Lay: 8
            {42, 45, 47}, // Pat: 17 Zon: 1 Lay: 9
            {27, 28, 29}, // Pat: 17 Zon: 1 Lay: 10
            {46, 48, 51}, // Pat: 17 Zon: 1 Lay: 11
            { 0,  0,  0}, // Pat: 17 Zon: 1 Lay: 12
            { 0,  0,  0}, // Pat: 17 Zon: 1 Lay: 13
            { 0,  0,  0}, // Pat: 17 Zon: 1 Lay: 14
        },
        { // Zon: 2
            {38, 41, 44}, // Pat: 17 Zon: 2 Lay: 0
            { 0,  0,  0}, // Pat: 17 Zon: 2 Lay: 1
            { 0,  0,  0}, // Pat: 17 Zon: 2 Lay: 2
            {19, 21, 23}, // Pat: 17 Zon: 2 Lay: 3
            {16, 18, 20}, // Pat: 17 Zon: 2 Lay: 4
            { 0,  0,  0}, // Pat: 17 Zon: 2 Lay: 5
            { 0,  0,  0}, // Pat: 17 Zon: 2 Lay: 6
            {18, 20, 22}, // Pat: 17 Zon: 2 Lay: 7
            {14, 17, 19}, // Pat: 17 Zon: 2 Lay: 8
            {40, 43, 46}, // Pat: 17 Zon: 2 Lay: 9
            {27, 28, 29}, // Pat: 17 Zon: 2 Lay: 10
            { 0,  0,  0}, // Pat: 17 Zon: 2 Lay: 11
            { 0,  0,  0}, // Pat: 17 Zon: 2 Lay: 12
            { 0,  0,  0}, // Pat: 17 Zon: 2 Lay: 13
            { 0,  0,  0}, // Pat: 17 Zon: 2 Lay: 14
        },
        { // Zon: 3
            {35, 39, 42}, // Pat: 17 Zon: 3 Lay: 0
            { 0,  0,  0}, // Pat: 17 Zon: 3 Lay: 1
            { 0,  0,  0}, // Pat: 17 Zon: 3 Lay: 2
            {20, 22, 24}, // Pat: 17 Zon: 3 Lay: 3
            {18, 20, 21}, // Pat: 17 Zon: 3 Lay: 4
            { 0,  0,  0}, // Pat: 17 Zon: 3 Lay: 5
            { 0,  0,  0}, // Pat: 17 Zon: 3 Lay: 6
            {19, 21, 22}, // Pat: 17 Zon: 3 Lay: 7
            {16, 18, 20}, // Pat: 17 Zon: 3 Lay: 8
            {37, 41, 44}, // Pat: 17 Zon: 3 Lay: 9
            {26, 27, 28}, // Pat: 17 Zon: 3 Lay: 10
            { 0,  0,  0}, // Pat: 17 Zon: 3 Lay: 11
            { 0,  0,  0}, // Pat: 17 Zon: 3 Lay: 12
            { 0,  0,  0}, // Pat: 17 Zon: 3 Lay: 13
            { 0,  0,  0}, // Pat: 17 Zon: 3 Lay: 14
        },
        { // Zon: 4
            {35, 39, 42}, // Pat: 17 Zon: 4 Lay: 0
            {30, 31, 34}, // Pat: 17 Zon: 4 Lay: 1
            { 0,  0,  0}, // Pat: 17 Zon: 4 Lay: 2
            {20, 22, 24}, // Pat: 17 Zon: 4 Lay: 3
            {18, 20, 21}, // Pat: 17 Zon: 4 Lay: 4
            {29, 31, 34}, // Pat: 17 Zon: 4 Lay: 5
            { 0,  0,  0}, // Pat: 17 Zon: 4 Lay: 6
            {19, 21, 22}, // Pat: 17 Zon: 4 Lay: 7
            {16, 18, 20}, // Pat: 17 Zon: 4 Lay: 8
            {37, 41, 44}, // Pat: 17 Zon: 4 Lay: 9
            { 0,  0,  0}, // Pat: 17 Zon: 4 Lay: 10
            { 0,  0,  0}, // Pat: 17 Zon: 4 Lay: 11
            { 0,  0,  0}, // Pat: 17 Zon: 4 Lay: 12
            { 0,  0,  0}, // Pat: 17 Zon: 4 Lay: 13
            { 0,  0,  0}, // Pat: 17 Zon: 4 Lay: 14
        },
        { // Zon: 5
            { 0,  0,  0}, // Pat: 17 Zon: 5 Lay: 0
            {29, 31, 33}, // Pat: 17 Zon: 5 Lay: 1
            { 0,  0,  0}, // Pat: 17 Zon: 5 Lay: 2
            {22, 23, 24}, // Pat: 17 Zon: 5 Lay: 3
            {19, 21, 23}, // Pat: 17 Zon: 5 Lay: 4
            {28, 30, 33}, // Pat: 17 Zon: 5 Lay: 5
            {26, 27, 28}, // Pat: 17 Zon: 5 Lay: 6
            {20, 22, 24}, // Pat: 17 Zon: 5 Lay: 7
            {18, 20, 22}, // Pat: 17 Zon: 5 Lay: 8
            { 0,  0,  0}, // Pat: 17 Zon: 5 Lay: 9
            { 0,  0,  0}, // Pat: 17 Zon: 5 Lay: 10
            { 0,  0,  0}, // Pat: 17 Zon: 5 Lay: 11
            { 0,  0,  0}, // Pat: 17 Zon: 5 Lay: 12
            { 0,  0,  0}, // Pat: 17 Zon: 5 Lay: 13
            { 0,  0,  0}, // Pat: 17 Zon: 5 Lay: 14
        },
        { // Zon: 6
            { 0,  0,  0}, // Pat: 17 Zon: 6 Lay: 0
            { 0,  0,  0}, // Pat: 17 Zon: 6 Lay: 1
            { 0,  0,  0}, // Pat: 17 Zon: 6 Lay: 2
            { 0,  0,  0}, // Pat: 17 Zon: 6 Lay: 3
            { 0,  0,  0}, // Pat: 17 Zon: 6 Lay: 4
            { 0,  0,  0}, // Pat: 17 Zon: 6 Lay: 5
            { 0,  0,  0}, // Pat: 17 Zon: 6 Lay: 6
            { 0,  0,  0}, // Pat: 17 Zon: 6 Lay: 7
            { 0,  0,  0}, // Pat: 17 Zon: 6 Lay: 8
            { 0,  0,  0}, // Pat: 17 Zon: 6 Lay: 9
            { 0,  0,  0}, // Pat: 17 Zon: 6 Lay: 10
            { 0,  0,  0}, // Pat: 17 Zon: 6 Lay: 11
            { 0,  0,  0}, // Pat: 17 Zon: 6 Lay: 12
            { 0,  0,  0}, // Pat: 17 Zon: 6 Lay: 13
            { 0,  0,  0}, // Pat: 17 Zon: 6 Lay: 14
        }
    }
};

