//////////////////////////////////////////////////////////////////////////////////
// Company: UF
// Author: Rafael Hernandez
//
// Create Date:    01:23:48 03/27/2010 
// Design Name: tf_slhc
// Module Name:    sp
// Project Name: tf_slhc
// Target Devices: V6
// Tool versions: 11.4
// Description: sector processor top module
//
// Dependencies: all underlying modules
//
// Revision: 
// Revision 0.01 - File Created
// Additional Comments: Translated by Rafael into C++
//
//////////////////////////////////////////////////////////////////////////////////
#ifndef _SP_CLASS_
#define _SP_CLASS_

#ifdef _LOCAL_AP_INT_H_
  #include "../include/ap_int.h"
#else
  #include <ap_int.h>
#endif
#include "spbits.h"
#include "prim_conv_sector_EMTFe.h"
#include "zones_EMTFe.h"
#include "extend_sector_EMTFe.h"
#include "ph_pattern_sector_EMTFe.h"

//#define PC_PRINT_MACRO

/* Cosimulation: need self-check test bench (ie can write to a file and see that
 * output file == golden using diff, array comparisons, etc)
 * ap_ctrl_none is fine for pipelined functions
 * I have been doing this myself, but it may be better to do it later
 * Was thinking: -D to_log and write C++ outputs to file, then in cosim check
 * against these ideal values from C++ output
 */

struct sp {
    // I could make a top level function with just a "sp uut" and then
    //     uut() to run sp's main function

    prim_conv_sector  pcs;    // Convert primitives into angular values
    zones             zns;    // Construct raw hit zones
    extend_sector     exts;   // Extend raw hit pulses
    ph_pattern_sector phps;   // Detect ph patterns in all zones
    /* // Uncomment as development continues
    sort_sector       srts;   // Find 3 best ph patterns in each zone
    coord_delay       cdl;    // Delay line for polar coordinates provided by prim_conv_sector
    match_ph_segments mphseg; // Match ph patterns to segments and reroute segments according to ph zones
    deltas_sector     ds;     // Delta ph and th for 12 candidates
    best_tracks       bt;     // Identify best three tracks
    single            sngl;   // Single hit trigger; take only chambers from this sector, not neighbor
    two_mu            twom;   // Two-muon trigger, one track + one single hit in ME1/1
    ptlut_address     pta;    // Construct PT_LUT addresses for best tracks
    */

    void operator()(
        // [station][chamber][segment] station 5 = neighbor sector, all stations
        // unpack LCTs in Verilog code -- unable to do so here without increasing II
        const ap_uint<seg_ch>  vpf      [14][9],
        const ap_uint<bw_wg>   wg       [6][9][seg_ch],
        const ap_uint<bw_hs>   hstr     [6][9][seg_ch],
        const ap_uint<4>       cpat     [6][9][seg_ch],
        const ap_uint<64>      cppf_rxd [7][3], // cppf rx data, 3 frames x 64 bit, for 7 links
        const ap_uint<7>      &cppf_rx_valid,   // cprx data valid flags
        const ap_uint<4>       th_corr_mem[3][3][th_corr_mem_sz],
        const ap_uint<6>       th_mem     [6][9][th_mem_sz],
        const ap_uint<13>      params     [6][9][6],
        const ap_uint<bw_fph-2>ph_rpc[7][8][seg_ch],
        const ap_uint<bw_th-2> th_rpc[7][8][seg_ch],

        // precise phi and theta of best tracks
        // [best_track_num]
              ap_uint<bw_fph>  bt_phi   [3],
              ap_uint<bw_th>   bt_theta [3],
        // [best_track_num][station]
              ap_uint<4>       bt_cpattern[3][4],
        // ph and th deltas from best stations
        // [best_track_num], last index: 0=12, 1=13, 2=14, 3=23, 4=24, 5=34
              ap_uint<bw_fph>  bt_delta_ph[3][6],
              ap_uint<bw_th>   bt_delta_th[3][6],
              ap_uint<6>       bt_sign_ph [3],
              ap_uint<6>       bt_sign_th [3],
        // ranks [best_track_num]
              ap_uint<bwr+1>   bt_rank[3],
        // segment IDs
        // [best_track_num][station 0-3]
              ap_uint<seg_ch>  bt_vi[3][5],     // valid
              ap_uint<2>       bt_hi[3][5],     // bx index
              ap_uint<4>       bt_ci[3][5],     // chamber
              ap_uint<5>       bt_si[3],        // segment

              ap_uint<30>      ptlut_addr[3],   // ptlut addresses for best 3 muons
              ap_uint<32>      ptlut_cs  [3],   // pre-decoded chip selects
              ap_uint<3>      &ptlut_addr_val,  // ptlut address valid flags
              ap_uint<8>       gmt_phi[3],      // phi for gmt
              ap_uint<9>       gmt_eta[3],      // eta for gmt
              ap_uint<4>       gmt_qlt[3],      // quality for gmt
              ap_uint<3>      &gmt_crg,

        const ap_uint<1>      &endcap,
        const ap_uint<3>      &sector,
        const ap_uint<1>      &lat_test,
        const ap_uint<64>     &core_config
    );

    #ifndef __SYNTHESIS__ // Here for simulation to give test bench ability to see these
    ap_uint<bw_fph>  ph    [6][9][seg_ch];
    ap_uint<bw_th>   th11  [3][3][th_ch11];
    ap_uint<bw_th>   th    [6][9][seg_ch];
    ap_uint<seg_ch>  vl    [6][9];
    ap_uint<7>       phzvl [14][9];
    ap_uint<seg_ch>  me11a [3][3];
    ap_uint<4>       cpatr [6][9][seg_ch];
    // ph and th raw hits [station][chamber]
    ap_uint<ph_hit_w> ph_hito [14][9];
    // ph zones [zone][station]
    ap_uint<ph_raw_w> ph_zone [7][15];
    // ph zones extended [zone][station]
    ap_uint<ph_raw_w> ph_ext  [7][15]; // TODO: dimm: [3:0][4:1]

    // ph quality codes output [zone][key_strip]
    ap_uint<11>     ph_rank [7][ph_raw_w];
    #endif
};

#endif
