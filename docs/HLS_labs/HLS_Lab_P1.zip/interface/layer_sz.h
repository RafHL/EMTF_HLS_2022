// Pattern bank layer sizes
constexpr int zapp_pat_layer_sz[15] = {
    46, 36, 1, 36, 40, 35, 29, 37, 42, 48, 30, 53, 35, 31, 31
};

