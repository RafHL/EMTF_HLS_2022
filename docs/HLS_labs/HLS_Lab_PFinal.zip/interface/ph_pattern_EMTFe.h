//////////////////////////////////////////////////////////////////////////////////
// Company: UF
// Author: Rafael Hernandez
//
// Create Date:    01:36:08 03/19/2010
// Design Name: tf_slch
// Module Name:    ph_pattern
// Project Name: tf_slch
// Target Devices: V6
// Tool versions: 11.4
// Description: a signle pattern detector
//
// Dependencies:
//
// Revision:
// Revision 0.01 - File Created
// Additional Comments: Translated by Rafael into C++
//
//////////////////////////////////////////////////////////////////////////////////
#ifndef _PH_PATTERN_CLASS_
#define _PH_PATTERN_CLASS_

#ifdef _LOCAL_AP_INT_H_
  #include "../include/ap_int.h"
#else
  #include <ap_int.h>
#endif
#include "../interface/spbits.h"
#include "../interface/layer_sz.h"
#include <iostream>
//#define window_size 41

struct ph_pattern {

    ap_uint<3> zone = 7;
    ap_uint<3> bx [9][fold] = {
        {0,0,0,0},
        {0,0,0,0},
        {0,0,0,0},
        {0,0,0,0},
        {0,0,0,0},
        {0,0,0,0},
        {0,0,0,0},
        {0,0,0,0},
        {0,0,0,0}
    };

    ph_pattern();

    inline bool is_emtf_singlemu(ap_uint<4> &mode) const;
    inline bool is_emtf_doublemu(ap_uint<4> &mode) const;
    inline bool is_emtf_muopen  (ap_uint<4> &mode) const;

    void operator()(
        const ap_uint<zapp_pat_layer_sz[ 0]> &st0,  // ME11
        const ap_uint<zapp_pat_layer_sz[ 1]> &st1,  // ME12
        const ap_uint<1>           &st2,  // ME2
        const ap_uint<zapp_pat_layer_sz[ 3]> &st3,  // ME3
        const ap_uint<zapp_pat_layer_sz[ 4]> &st4,  // ME4
        const ap_uint<zapp_pat_layer_sz[ 5]> &st5,  // RE1
        const ap_uint<zapp_pat_layer_sz[ 6]> &st6,  // RE2
        const ap_uint<zapp_pat_layer_sz[ 7]> &st7,  // RE3
        const ap_uint<zapp_pat_layer_sz[ 8]> &st8,  // RE4
        const ap_uint<zapp_pat_layer_sz[ 9]> &st9,  // GE11
        const ap_uint<zapp_pat_layer_sz[10]> &st10, // GE21
        const ap_uint<zapp_pat_layer_sz[11]> &st11, // ME0
        const ap_uint<zapp_pat_layer_sz[12]> &st12, // MB1
        const ap_uint<zapp_pat_layer_sz[13]> &st13, // MB2
        const ap_uint<zapp_pat_layer_sz[14]> &st14, // MB3
        const ap_uint<3>                     &drifttime,
        const ap_uint<3>                     &foldn,
              ap_uint<11>                    &qcode
    );
};

#endif

