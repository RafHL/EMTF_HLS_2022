//////////////////////////////////////////////////////////////////////////////////
// Company: UF
// Author: Rafael Hernandez
//
// Create Date:    20:48:51 03/25/2010
// Design Name: tf_slhc
// Module Name:    zones
// Project Name: tf_slhc
// Target Devices: V6
// Tool versions: 11.4
// Description: raw hit zone merger
//
// Dependencies:
//
// Revision:
// Revision 0.01 - File Created
// Additional Comments: Translated by Rafael into C++
//
//////////////////////////////////////////////////////////////////////////////////

#ifndef _ZONES_H_
#define _ZONES_H_

//#define ZNS_PRINT_MACRO

#ifndef __SYNTHESIS__
  #ifdef ZNS_PRINT_MACRO // If printing, include iostream
    #include <iostream>
    #include <iomanip>
    //#include <cstdio>
  #endif // ZNS_PRINT
#endif // Synthesis
#ifdef _LOCAL_AP_INT_H_
  #include "../include/ap_int.h"
#else
  #include <ap_int.h>
#endif
#include "spbits.h"

struct zones {
    void operator()(
        // ph zone valid flags [station][chamber][zone]
        // note that zone flags in phzvl are local to each chamber
        const ap_uint<7>        phzvl  [13][9], // TODO: was 3 bits
        // ph raw hits [station][chamber]
        const ap_uint<ph_hit_w> ph_hit [13][9],
        // ph zones [zone][layers]
              ap_uint<ph_raw_w> ph_zone[7][15]
    ) const;
};

#endif

