
//////////////////////////////////////////////////////////////////////////////////
// Company: UF
// Author: Rafael Hernandez, Beichen (Oliver) Su
//
// Create Date:    01:23:48 03/27/2010
// Design Name: tf_slhc
// Module Name:    extend_sector
// Project Name: tf_slhc
// Target Devices: V6
// Tool versions: 11.4
// Description: raw hit extender for entire sector
//
// Dependencies: extender
//
// Revision:
// Revision 0.01 - File Created
// Additional Comments: Translated by Oliver into C++, heavily updated by Rafael
//
//////////////////////////////////////////////////////////////////////////////////

#ifndef _EXTEND_SECTOR_CLASS_
#define _EXTEND_SECTOR_CLASS_

//#define EXTS_PRINT_MACRO
#define EXTS_FILE_MACRO
#define EXTS_I_FILENAME "exts_i.out"
#define EXTS_O_FILENAME "exts_o.out"

#ifndef __SYNTHESIS__
  #ifdef EXTS_PRINT_MACRO
    #include <iostream>
    #include "../tb/ap_to_hex.h"
  #endif // EXTS_PRINT
  #ifdef EXTS_FILE_MACRO
    #include <iostream>
    #include <iomanip>
    #include <fstream>
  #endif // EXTS_FILE
#endif // Synthesis

#ifdef _LOCAL_AP_INT_H_
  #include "../include/ap_int.h"
#else
  #include <ap_int.h>
#endif
#include "../interface/spbits.h"
#include "../interface/extender_EMTFe.h"

struct extend_sector {
    extender ext[7][15];

    extend_sector();

    void operator()(
        // ph zones [zone][station]
        const ap_uint<ph_raw_w>  ph_zone[7][15],
        // ph extended zones [zone][station]
              ap_uint<ph_raw_w>  ph_ext [7][15],
        const ap_uint<3>        &drifttime
    );
};

#endif

