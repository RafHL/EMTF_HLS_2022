//////////////////////////////////////////////////////////////////////////////////
// Company: UF
// Engineer: Madorsky
// Translator: Rafael Hernandez
//
// Create Date:    01:36:08 03/19/2010
// Design Name: tf_slch
// Module Name:    prim_conv_sector
// Project Name: tf_slch
// Target Devices: V6
// Tool versions: 11.4
// Description: primitive converter for entire sector
//
// Dependencies: prim_conv
//
// Revision:
// Revision 0.01 - File Created
// Additional Comments: Translated by Rafael into C++
//
//////////////////////////////////////////////////////////////////////////////////
#ifndef _PRIM_CONV_SECTOR_CLASS_
#define _PRIM_CONV_SECTOR_CLASS_

// Undef and define new changes into a new include file
#ifdef _LOCAL_AP_INT_H_
  #include "../include/ap_int.h"
#else
  #include <ap_int.h>
#endif
#include "spbits.h"
#include "prim_conv_EMTFe.h"
#include "prim_conv11_EMTFe.h"


struct prim_conv_sector {
    csc_prim_conv11 pc11 [2][3];
    csc_prim_conv   pc12 [2][6]; // j 3:9 (j-3)
    csc_prim_conv   pc   [3][9]; // i 2:5 (i-2), j 0:9
    csc_prim_conv11 pcn11;       // st0, ch12, see ind for variables
    csc_prim_conv   pcn  [8];    // j 1:9 (j-1)
    rpc_prim_conv   pcr  [7][8]; // i0 neighbor i1-6 subsectors 1-6. j chambers 1-7
                                 // chamber ID taken from coord_delay from
                                 // Andrew B. see message from 2017-05-03 and
                                 // iRPC addition IDs 6-7 added by Rafael H.

    prim_conv_sector();

    void operator()(
        // lct parameters [station][chamber][segment]
        // st 5 = neighbor sector, all stations
        const ap_uint<seg_ch>    vpf   [14][9],              /* input  */
        const ap_uint<bw_wg>     wg    [6][9][seg_ch],       /* input  */
        const ap_uint<bw_hs>     hstr  [6][9][seg_ch],       /* input  */
        const ap_uint<4>         cpat  [6][9][seg_ch],       /* input  */
        const ap_uint<4>         th_corr_mem[3][3][th_corr_mem_sz], /* input */
        const ap_uint<6>         th_mem[6][9][th_mem_sz],    /* input  */
        const ap_uint<13>        params[6][9][6],            /* input  */
        const ap_uint<bw_fph-2>  ph_rpc[7][8][seg_ch],       /* input  */
        const ap_uint<bw_th-2>   th_rpc[7][8][seg_ch],       /* input  */
              ap_uint<bw_fph>    ph    [6][9][seg_ch],       /* output */
        // special th outputs for ME11 because of duplication
        // [station][chamber][segment with duplicates], station 2 = neighbor segment
              ap_uint<bw_th>     th11  [3][3][th_ch11],      /* output */
              ap_uint<bw_th>     th    [6][9][seg_ch],       /* output */
              ap_uint<seg_ch>    vl    [6][9],               /* output */
              ap_uint<7>         phzvl [14][9],              /* output */
        // me11a flags only for ME11 (stations 1,0, chambers 2:0)
        // [station][chamber][segment], station 2 = neighbor segment
              ap_uint<seg_ch>    me11a [3][3],               /* output */
              ap_uint<4>         cpatr [6][9][seg_ch],       /* output */
        // ph and th raw hits
              ap_uint<ph_hit_w>  ph_hit[14][9],              /* output */
        const ap_uint<1>        &endcap,                     /* input  */
        const ap_uint<1>        &lat_test                    /* input  */
    ) const;
};

#endif

