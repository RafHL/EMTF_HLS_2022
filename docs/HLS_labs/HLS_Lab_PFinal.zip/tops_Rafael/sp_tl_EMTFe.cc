#include "../include/ap_int.h"
#include "../interface/sp.h"

void sp_tl(
    // [station][chamber][segment] station 5 = neighbor sector, all stations
    // unpack LCTs in Verilog code -- unable to do so here without increasing II
    const ap_uint<seg_ch>  vpf      [11][9],
    const ap_uint<bw_wg>   wg       [6][9][seg_ch],
    const ap_uint<bw_hs>   hstr     [6][9][seg_ch],
    const ap_uint<4>       cpat     [6][9][seg_ch],
    const ap_uint<64>      cppf_rxd [7][3], // cppf rx data, 3 frames x 64 bit, for 7 links
    const ap_uint<7>      &cppf_rx_valid,   // cprx data valid flags
    const ap_uint<4>       th_corr_mem[3][3][th_corr_mem_sz],
    const ap_uint<6>       th_mem     [6][9][th_mem_sz],
    const ap_uint<13>      params     [6][9][6],
    const ap_uint<bw_fph-2>ph_rpc[5][9][seg_ch],
    const ap_uint<bw_th-2> th_rpc[5][9][seg_ch],

    // precise phi and theta of best tracks
    // [best_track_num]
          ap_uint<bw_fph>  bt_phi   [3],
          ap_uint<bw_th>   bt_theta [3],
    // [best_track_num][station]
          ap_uint<4>       bt_cpattern[3][4],
    // ph and th deltas from best stations
    // [best_track_num], last index: 0=12, 1=13, 2=14, 3=23, 4=24, 5=34
          ap_uint<bw_fph>  bt_delta_ph[3][6],
          ap_uint<bw_th>   bt_delta_th[3][6],
          ap_uint<6>       bt_sign_ph [3],
          ap_uint<6>       bt_sign_th [3],
    // ranks [best_track_num]
          ap_uint<bwr+1>   bt_rank[3],
    // segment IDs
    // [best_track_num][station 0-3]
          ap_uint<seg_ch>  bt_vi[3][5],     // valid
          ap_uint<2>       bt_hi[3][5],     // bx index
          ap_uint<4>       bt_ci[3][5],     // chamber
          ap_uint<5>       bt_si[3],        // segment

          ap_uint<30>      ptlut_addr[3],   // ptlut addresses for best 3 muons
          ap_uint<32>      ptlut_cs  [3],   // pre-decoded chip selects
          ap_uint<3>      &ptlut_addr_val,  // ptlut address valid flags
          ap_uint<8>       gmt_phi[3],      // phi for gmt
          ap_uint<9>       gmt_eta[3],      // eta for gmt
          ap_uint<4>       gmt_qlt[3],      // quality for gmt
          ap_uint<3>      &gmt_crg,

    const ap_uint<1>      &endcap,
    const ap_uint<3>      &sector,
    const ap_uint<1>      &lat_test,
    const ap_uint<64>     &core_config
) {
    #pragma HLS pipeline
    #pragma HLS interface ap_ctrl_none port=return
    static sp sp_o;
    sp_o(
        vpf, wg, hstr, cpat, cppf_rxd, cppf_rx_valid, th_corr_mem, th_mem,
        params, ph_rpc, th_rpc, bt_phi, bt_theta, bt_cpattern, bt_delta_ph,
        bt_delta_th, bt_sign_ph, bt_sign_th, bt_rank, bt_vi, bt_hi, bt_ci,
        bt_si, ptlut_addr, ptlut_cs, ptlut_addr_val, gmt_phi, gmt_eta, gmt_qlt,
        gmt_crg, endcap, sector, lat_test, core_config
    );
}

