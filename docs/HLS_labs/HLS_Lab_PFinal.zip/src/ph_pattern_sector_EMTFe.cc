//////////////////////////////////////////////////////////////////////////////////
// Company: UF
// Author: Rafael Hernandez
//
// Create Date:    01:36:08 03/19/2010
// Design Name: tf_slch
// Module Name:    ph_pattern_sector
// Project Name: tf_slch
// Target Devices: V6
// Tool versions: 11.4
// Description: pattern detector for entire sector
//
// Dependencies: ph_pattern
//
// Revision:
// Revision 0.01 - File Created
// Additional Comments: Translated by Rafael into C++
//
//////////////////////////////////////////////////////////////////////////////////
#include "../interface/ph_pattern_sector_EMTFe.h"

ph_pattern_sector::ph_pattern_sector() {
    for (int zn = 0; zn < 7; zn++) {
#pragma HLS unroll
        for (int ks = 0; ks < ph_raw_w; ks++) {
    #pragma HLS unroll
            php[zn][ks].zone = ap_uint<3>(zn);
        }
    }
}

void ph_pattern_sector::operator()(
    const ap_uint<ph_raw_w>  st[7][15],
    const ap_uint<3>        &drifttime,
    const ap_uint<3>        &foldn,
          ap_uint<11>        qcode[7][ph_raw_w]
) {

#pragma HLS interface ap_ctrl_none port=return
    //#pragma HLS inline off
#pragma HLS pipeline II=1
#pragma HLS latency max=1

#pragma HLS array_partition variable=st        dim=0
#pragma HLS array_partition variable=qcode     dim=0

#if defined(PHPS_FILE_MACRO) && defined(PHPS_FILENAME) && !defined(__SYNTHESIS__)
    static std::ofstream of(PHPS_FILENAME);
    static bool first_time = 1;
    static int  event = 0;
#endif // PHPS_FILE

    // copy of stations with padding of zeroes on sides, so it's easier to pass to detectors
    // station numbering is different here:
    // 0 == st1
    // 1 == st3
    // 2 == st4
    // ...
    // 15 == st16
    // st 2 does not need padding
    // zapp_pat_layer_size is the width of Jia Fu's EMTFpp patterns' layers
    // window_size/2*2 for proper rounding
    ap_uint<ph_raw_w + (zapp_pat_layer_sz[ 0]/2)*2> st0 [7];
    ap_uint<ph_raw_w + (zapp_pat_layer_sz[ 1]/2)*2> st1 [7];
    ap_uint<ph_raw_w + (zapp_pat_layer_sz[ 3]/2)*2> st3 [7];
    ap_uint<ph_raw_w + (zapp_pat_layer_sz[ 4]/2)*2> st4 [7];
    ap_uint<ph_raw_w + (zapp_pat_layer_sz[ 5]/2)*2> st5 [7];
    ap_uint<ph_raw_w + (zapp_pat_layer_sz[ 6]/2)*2> st6 [7];
    ap_uint<ph_raw_w + (zapp_pat_layer_sz[ 7]/2)*2> st7 [7];
    ap_uint<ph_raw_w + (zapp_pat_layer_sz[ 8]/2)*2> st8 [7];
    ap_uint<ph_raw_w + (zapp_pat_layer_sz[ 9]/2)*2> st9 [7];
    ap_uint<ph_raw_w + (zapp_pat_layer_sz[10]/2)*2> st10[7];
    ap_uint<ph_raw_w + (zapp_pat_layer_sz[11]/2)*2> st11[7];
    ap_uint<ph_raw_w + (zapp_pat_layer_sz[12]/2)*2> st12[7];
    ap_uint<ph_raw_w + (zapp_pat_layer_sz[13]/2)*2> st13[7];
    ap_uint<ph_raw_w + (zapp_pat_layer_sz[14]/2)*2> st14[7];

    // padding to 0, otherwise use input
    for (int zn = 0; zn < 7; zn++) {
#pragma HLS unroll
        st0 [zn] = (ap_uint<zapp_pat_layer_sz[ 0]/2>(0), st[zn][ 0], ap_uint<zapp_pat_layer_sz[ 0]/2>(0));
        st1 [zn] = (ap_uint<zapp_pat_layer_sz[ 1]/2>(0), st[zn][ 1], ap_uint<zapp_pat_layer_sz[ 1]/2>(0));
        st3 [zn] = (ap_uint<zapp_pat_layer_sz[ 3]/2>(0), st[zn][ 3], ap_uint<zapp_pat_layer_sz[ 3]/2>(0));
        st4 [zn] = (ap_uint<zapp_pat_layer_sz[ 4]/2>(0), st[zn][ 4], ap_uint<zapp_pat_layer_sz[ 4]/2>(0));
        st5 [zn] = (ap_uint<zapp_pat_layer_sz[ 5]/2>(0), st[zn][ 5], ap_uint<zapp_pat_layer_sz[ 5]/2>(0));
        st6 [zn] = (ap_uint<zapp_pat_layer_sz[ 6]/2>(0), st[zn][ 6], ap_uint<zapp_pat_layer_sz[ 6]/2>(0));
        st7 [zn] = (ap_uint<zapp_pat_layer_sz[ 7]/2>(0), st[zn][ 7], ap_uint<zapp_pat_layer_sz[ 7]/2>(0));
        st8 [zn] = (ap_uint<zapp_pat_layer_sz[ 8]/2>(0), st[zn][ 8], ap_uint<zapp_pat_layer_sz[ 8]/2>(0));
        st9 [zn] = (ap_uint<zapp_pat_layer_sz[ 9]/2>(0), st[zn][ 9], ap_uint<zapp_pat_layer_sz[ 9]/2>(0));
        st10[zn] = (ap_uint<zapp_pat_layer_sz[10]/2>(0), st[zn][10], ap_uint<zapp_pat_layer_sz[10]/2>(0));
        st11[zn] = (ap_uint<zapp_pat_layer_sz[11]/2>(0), st[zn][11], ap_uint<zapp_pat_layer_sz[11]/2>(0));
        st12[zn] = (ap_uint<zapp_pat_layer_sz[12]/2>(0), st[zn][12], ap_uint<zapp_pat_layer_sz[12]/2>(0));
        st13[zn] = (ap_uint<zapp_pat_layer_sz[13]/2>(0), st[zn][13], ap_uint<zapp_pat_layer_sz[13]/2>(0));
        st14[zn] = (ap_uint<zapp_pat_layer_sz[14]/2>(0), st[zn][14], ap_uint<zapp_pat_layer_sz[14]/2>(0));
    }

    for (int zn = 0; zn < 7; zn++)
#pragma HLS unroll
        //for (int ks = 0; ks < 0; ks++)
        //for (int ks = 40; ks < 41; ks++)
        for (int ks = 0; ks < ph_raw_w; ks++)
// 0-7     2025.48s user 98.54s cpu 35:31.69
// 7-14    2215.87s user 94.67s system 99% cpu 38:37.24 total
// 14-21   2247.31s user 91.37s system 99% cpu 39:05.15 total
// 21-28   2057.62s user 97.03s system 99% cpu 36:01.88 total
// 28-35   2202.77s user 92.91s system 99% cpu 38:22.60 total
// 35-42   2188.54s user 92.94s system 99% cpu 38:08.14 total
// 42-49   1523.07s user 97.46s system 99% cpu 27:07.11 total
// 49-56   2003.54s user 100.30s system 99% cpu 35:11.75 total
// 56-63   2037.78s user 98.97s system 99% cpu 35:43.93 total
// 63-70   1645.48s user 96.20s system 99% cpu 29:07.52 total
// 70-77   2075.96s user 97.18s system 99% cpu 36:19.83 total
// 77-84   2084.08s user 98.29s system 99% cpu 36:29.12 total
// 84-91   1562.97s user 94.52s system 99% cpu 27:43.56 total
// 91-98   2109.82s user 98.76s system 99% cpu 36:56.26 total
// 98-105  2182.92s user 97.11s system 99% cpu 38:06.90 total
// 105-112 1565.91s user 96.45s system 99% cpu 27:47.76 total
// 112-119 2301.41s user 94.80s system 99% cpu 40:03.24 total
// 119-126 2374.08s user 94.16s system 99% cpu 41:15.25 total
// 126-133 2186.18s user 94.45s system 99% cpu 38:07.29 total
// 133-140 2419.74s user 96.35s system 99% cpu 42:03.25 total
// 140-147 2460.22s user 95.96s system 99% cpu 42:43.59 total
// 147-154 2351.62s user 94.51s system 99% cpu 40:52.91 total
// 153-160 1326.60s user 83.86s system 99% cpu 23:34.44 total
// 140-160 14215.15s user 424.58s system 99% cpu 4:04:32.88 total
// 100-160 69970.89s user 1173.52s system 99% cpu 19:47:58.68 total

// TODO: try moving the pipeline pragma here: and removing the one above

    #pragma HLS unroll
            php[zn][ks](
                st0 [zn]    (ks+zapp_pat_layer_sz[ 0]-1, ks), // ME11
                st1 [zn]    (ks+zapp_pat_layer_sz[ 1]-1, ks), // ME12
                st  [zn][ 2][ks],                   // ME2
                st3 [zn]    (ks+zapp_pat_layer_sz[ 3]-1, ks), // ME3
                st4 [zn]    (ks+zapp_pat_layer_sz[ 4]-1, ks), // ME4
                st5 [zn]    (ks+zapp_pat_layer_sz[ 5]-1, ks), // RE1
                st6 [zn]    (ks+zapp_pat_layer_sz[ 6]-1, ks), // RE2
                st7 [zn]    (ks+zapp_pat_layer_sz[ 7]-1, ks), // RE3
                st8 [zn]    (ks+zapp_pat_layer_sz[ 8]-1, ks), // RE4
                st9 [zn]    (ks+zapp_pat_layer_sz[ 9]-1, ks), // GE11
                st10[zn]    (ks+zapp_pat_layer_sz[10]-1, ks), // GE21
                st11[zn]    (ks+zapp_pat_layer_sz[11]-1, ks), // ME0
                st12[zn]    (ks+zapp_pat_layer_sz[12]-1, ks), // MB1
                st13[zn]    (ks+zapp_pat_layer_sz[13]-1, ks), // MB2
                st14[zn]    (ks+zapp_pat_layer_sz[14]-1, ks), // MB3
                drifttime,
                foldn,
                qcode[zn][ks]
            );
#ifndef __SYNTHESIS__
    #if defined(PHPS_FILE_MACRO) && defined(PHPS_FILENAME) && !defined(__SYNTHESIS__)
    if (first_time) {
        of << "    zone keystrip   q_code" << std::endl;
        of << "       7      160       11" << std::endl;
        first_time = 0;
    }
    for (unsigned int zn = 0; zn < 7u; zn++) {
        for (unsigned int ks = 0; ks < ph_raw_w; ks++) {
            if (qcode[zn][ks])
                of << std::setw(8) << zn << " "
                   << std::setw(8) << ks << " "
                   << std::setw(8) << qcode[zn][ks] << std::endl;
        }
    }
    of << ++event << std::endl;
    #endif /*PHPS_FILE_MACRO */
#endif /* __SYNTHESIS__ */
}

