//////////////////////////////////////////////////////////////////////////////////
// Company: UF
// Author: Rafael Hernandez
//
// Create Date:    01:36:08 03/19/2010
// Design Name: tf_slch
// Module Name:    prim_conv_sector
// Project Name: tf_slch
// Target Devices: V6
// Tool versions: 11.4
// Description: primitive converter for entire sector
//
// Dependencies: prim_conv
//
// Revision:
// Revision 0.01 - File Created
// Additional Comments: Translated by Rafael into C++
//
//////////////////////////////////////////////////////////////////////////////////
#include "../interface/prim_conv_sector_EMTFe.h"

prim_conv_sector::prim_conv_sector() {
    // System Verilog generation constant parameters set up:
//  genblk_st_ch:

    // Set up chamber and station ids
station11_st_ch:
    for (ap_uint<4> i = 0; i < 2; i++) {
    csc11_st_ch:
        for (ap_uint<4> j = 0; j < 3; j++) {
            pc11[i][j].station = i;
            pc11[i][j].cscid   = j;
        }
    } // block: station11_st_ch

station12_st_ch:
    for (ap_uint<4> i = 0; i < 2; i++) {
    csc12_st_ch:
        for (ap_uint<4> j = 0; j < 6; j++) {
            pc12[i][j].station = i;
            pc12[i][j].cscid   = j + 3; // Account for index difference
        }
    } // block: station12_st_ch

station_st_ch:
    for (ap_uint<4> i = 0; i < 3; i++) {
    csc_st_ch:
        for (ap_uint<4> j = 0; j < 9; j++) {
            pc[i][j].station = i + 2; // Account for index difference
            pc[i][j].cscid   = j;
        }
    } // block: station_st_ch

station_r_st_ch:
    for (unsigned int i = 1; i < 7; i++) { // Subsector
    rpc_st_ch:
        for (unsigned int j = 0; j < 8; j++) { // Chamber
            // Values taken from cscid-to-ring.pdf and coord_delay.sv
            pcr[i][j].station = (j == 0 && i > 3) ? 1 :
                                (j == 0)          ? 0 :
                                (j == 1)          ? 2 :
                                (j == 2 || j == 3 || j == 6)? 3 : // 6 is iRPC3/1
                                (j == 4 || j == 5 || j == 7)? 4 : // 7 is iRPC4/1
                                                             -1;
            pcr[i][j].rpcid   = (j == 0 && i > 3) ? i - 1 :
                                                    i + 2;  // Subsector 1 aligns with chamber 3 in non-ME11 stations
        }
    } // block: station_r

rpcn_st_ch:
    for (unsigned int j = 0; j < 8; j++) {
        // Values taken from cscid-to-ring.pdf and coord_delay.sv
        pcr[0][j].station = (j == 0) ? 1 :
                            (j == 1) ? 2 :
                            (j < 4 || j == 6)? 3 :
                            (j < 6 || j == 7)? 4 :
                                      -1;
        pcr[0][j].rpcid   = (j == 0) ? 5 :
                            (j == 1) ? 9 :
                            (j < 4 || j == 6)? 9 :
                            (j < 6 || j == 7)? 9 :
                                      -1;
    } // block: rpcn

    // neighbor sector single ME11 chamber
cscn11_st_ch:
    pcn11.station = 0;
    pcn11.cscid   = 12;
    // block: cscn11_st_ch

    // rest of neighbor chambers
cscn_st_ch:
    for (ap_uint<4> j = 1; j < 9; j++) {
        pcn[j-1].station = j < 3 ? ap_uint<4>(0)      : ap_uint<4>((j+1)/2);
        pcn[j-1].cscid   = j < 3 ? ap_uint<4>(j + 12) : ap_uint<4>((j-1)%2 + 9);
    } // block: cscn_st_ch
//block: genblk_st_ch
}

void prim_conv_sector::operator()(
    // lct parameters [station][chamber][segment]
    // st 5 = neighbor sector, all stations
    const ap_uint<seg_ch>    vpf   [14][9],              /* input  */
    const ap_uint<bw_wg>     wg    [6][9][seg_ch],       /* input  */
    const ap_uint<bw_hs>     hstr  [6][9][seg_ch],       /* input  */
    const ap_uint<4>         cpat  [6][9][seg_ch],       /* input  */
    const ap_uint<4>         th_corr_mem[3][3][th_corr_mem_sz], /* input */
    const ap_uint<6>         th_mem[6][9][th_mem_sz],    /* input  */
    const ap_uint<13>        params[6][9][6],            /* input  */
    const ap_uint<bw_fph-2>  ph_rpc[7][8][seg_ch],       /* input  */
    const ap_uint<bw_th-2>   th_rpc[7][8][seg_ch],       /* input  */
          ap_uint<bw_fph>    ph    [6][9][seg_ch],       /* output */
    // special th outputs for ME11 because of duplication
    // [station][chamber][segment with duplicates], station 2 = neighbor segment
          ap_uint<bw_th>     th11  [3][3][th_ch11],      /* output */
          ap_uint<bw_th>     th    [6][9][seg_ch],       /* output */
          ap_uint<seg_ch>    vl    [6][9],               /* output */
          ap_uint<7>         phzvl [14][9],              /* output */
    // me11a flags only for ME11 (stations 1,0, chambers 2:0)
    // [station][chamber][segment], station 2 = neighbor segment
          ap_uint<seg_ch>    me11a [3][3],               /* output */
          ap_uint<4>         cpatr [6][9][seg_ch],       /* output */
    // ph and th raw hits
          //TODO: Fix first index once I am sure about the RPC geometry
          ap_uint<ph_hit_w>  ph_hit[14][9],              /* output */
    const ap_uint<1>        &endcap,                     /* input  */
    const ap_uint<1>        &lat_test                    /* input  */
) const {

#pragma HLS interface ap_ctrl_none port=return
//#pragma HLS inline off
#pragma HLS pipeline

    ap_uint<seg_ch> dummy  [6][9]; // me11a for pc variables which always send 0

// Look into largest blocks mainting II of 1
// TODO: Probably needed at first input
#pragma HLS array_partition variable=vpf    dim=0
#pragma HLS array_partition variable=wg     dim=0
#pragma HLS array_partition variable=hstr   dim=0
#pragma HLS array_partition variable=cpat   dim=0
#pragma HLS array_partition variable=th_corr_mem dim=0
#pragma HLS array_partition variable=th_mem dim=0
#pragma HLS array_partition variable=params dim=0
#pragma HLS array_partition variable=ph_rpc dim=0
#pragma HLS array_partition variable=th_rpc dim=0
#pragma HLS array_partition variable=ph     dim=0
#pragma HLS array_partition variable=th11   dim=0
#pragma HLS array_partition variable=th     dim=0
#pragma HLS array_partition variable=vl     dim=0
#pragma HLS array_partition variable=phzvl  dim=0
#pragma HLS array_partition variable=me11a  dim=0
#pragma HLS array_partition variable=cpatr  dim=0
#pragma HLS array_partition variable=ph_hit dim=0
#pragma HLS array_partition variable=dummy  dim=0

    // genblk:

// TODO: add in ZAPP
station11:
    for (unsigned int i = 0; i < 2; i++) // FIXME: pc11 index out of range at 1.0
    csc11:
        for (unsigned int j = 0; j < 3; j++)
            pc11[i][j](
                vpf         [i][j],
                wg          [i][j],
                hstr        [i][j],
                cpat        [i][j],
                th_corr_mem [i][j],
                th_mem      [i][j],
                params      [i][j],
                ph          [i][j],
                th11        [i][j], // use special th11 array for ME11
                vl          [i][j],
                phzvl       [i][j],
                me11a       [i][j],
                cpatr       [i][j],
                ph_hit      [i][j],
                endcap
            );
    // block: station11

station12:
    for (unsigned int i = 0; i < 2; i++)
    csc12:
        for (unsigned int j = 3; j < 9; j++)
            // XXX: Why no latency test?
            pc12[i][j-3](
                 vpf    [i][j],
                 wg     [i][j],
                 hstr   [i][j],
                 cpat   [i][j],
                 th_mem [i][j],
                 params [i][j],
                 ph     [i][j],
                 th     [i][j],
                 vl     [i][j],
                 phzvl  [i][j],
                 dummy  [i][j],
                 cpatr  [i][j],
                 ph_hit [i][j],
                 endcap,
                 0              // Disconnected in verilog code
            );
    // block: station12

station:
    for (unsigned int i = 2; i < 5; i++)
    csc:
        for (unsigned int j = 0; j < 9; j++)
            pc[i-2][j](
                 vpf    [i][j],
                 wg     [i][j],
                 hstr   [i][j],
                 cpat   [i][j],
                 th_mem [i][j],
                 params [i][j],
                 ph     [i][j],
                 th     [i][j],
                 vl     [i][j],
                 phzvl  [i][j],
                 dummy  [i][j],
                 cpatr  [i][j],
                 ph_hit [i][j],
                 endcap,
                 lat_test
            );
    // block: station

station_r:
    // Neighbors in i = 0
    for (unsigned int i = 0; i < 7; i++)
    rpc:
        for (unsigned int j = 0; j < 8; j++)
            pcr[i][j](
                ph_rpc[i][j],
                th_rpc[i][j],
                vpf   [6+i][j],
                phzvl [6+i][j],
                ph_hit[6+i][j],
                lat_test
            );
    // block: station_r

    // neighbor sector single ME11 chamber
cscn11:
    pcn11(
        vpf         [5][0],
        wg          [5][0],
        hstr        [5][0],
        cpat        [5][0],
        th_corr_mem [2][0],
        th_mem      [5][0],
        params      [5][0],
        ph          [5][0],
        th11        [2][0], // use special th11 array for ME11
        vl          [5][0],
        phzvl       [5][0],
        me11a       [2][0],
        cpatr       [5][0],
        ph_hit      [5][0],
        endcap
    );
    // block: cscn11

    // rest of neighbor chambers
cscn:
    for (unsigned int j = 1; j < 9; j++)
        pcn[j-1](
             vpf    [5][j],
             wg     [5][j],
             hstr   [5][j],
             cpat   [5][j],
             th_mem [5][j],
             params [5][j],
             ph     [5][j],
             th     [5][j],
             vl     [5][j],
             phzvl  [5][j],
             dummy  [5][j],
             cpatr  [5][j],
             ph_hit [5][j],
             endcap,
             lat_test
        );
    // block: cscn
// block: genblk
}

