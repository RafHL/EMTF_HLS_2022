//////////////////////////////////////////////////////////////////////////////////
// Company: UF
// Author: Rafael Hernandez
//
// Create Date:    20:48:51 03/25/2010
// Design Name: tf_slhc
// Module Name:    zones
// Project Name: tf_slhc
// Target Devices: V6
// Tool versions: 11.4
// Description: raw hit zone merger
//
// Dependencies:
//
// Revision:
// Revision 0.01 - File Created
// Additional Comments: Translated by Rafael into C++
//
//////////////////////////////////////////////////////////////////////////////////

#include "../interface/zones_EMTFe.h"
#ifndef __SYNTHESIS__
    #ifdef ZNS_PRINT_MACRO
    #include <string>
    #include "../tb/ap_to_hex.h"
    #endif /*ZNS_PRINT_MACRO */
#endif /* __SYNTHESIS__ */

// Rafael Hernandez-Lopez added:
// Necessary because a.range() |= b does a.range() = a | b instead of a.range() = a.range() | b
// I also updated the etc/ap_private.h file to have sizes on an error message and
//      fixed a typo
#define OREQUAL(a, b) (a = a | b)

void zones::operator()(
    // ph zone valid flags [station][chamber][zone]
    // note that zone flags in phzvl are local to each chamber
    const ap_uint<7>        phzvl  [13][9],
    // ph raw hits [station][chamber]
    const ap_uint<ph_hit_w> ph_hit [13][9],
    // ph zones [zone][layers]
          ap_uint<ph_raw_w> ph_zone[7][15]
) const {
#pragma HLS pipeline
#pragma HLS array_partition variable=phzvl   dim=0
#pragma HLS array_partition variable=ph_hit  dim=0
#pragma HLS array_partition variable=ph_zone dim=0

#include "../interface/ph_init_hard.h"

#ifndef __SYNTHESIS__
    #ifdef ZNS_PRINT_MACRO
    std::string temp;
    for (int i = 0; i < 6; i++)
        for (int j = 0; j < 9; j++)
            std::cout << "    ph_hit [" << i << "][" << j << "] = " << apu_to_hex<ph_hit_w>(ph_hit[i][j]) << std::endl;
            //printf("    ph_hit [%d][%d] = %lx\n", i, j, temp = ph_hit[i][j]);

    for (int i = 0; i < 6; i++)
        for (int j = 0; j < 9; j++)
            std::cout << "    phzvl  [" << i << "][" << j << "] = " << apu_to_hex<3>(phzvl[i][j]) << std::endl;
            //printf("    phzvl  [%d][%d] = %lx\n", i, j, temp = phzvl[i][j]);
    #endif /*ZNS_PRINT_MACRO */
#endif /* __SYNTHESIS__ */

    // EMTFpp minimal overlap in between chambers within the same layer
    // Overlap only if ph_init_hard causes two chambers to share a certain ph range

    // For all zones,
    //     For all layers,
    //         if zone is valid
    //             put ph_hit into ph_zone
    //                 -- Make sure to have correct bit span ph_hit_wXX
    //                 -- Make sure to use hardware variation in ph_init_hard
    //                 -- Make sure to account for neighbors

    // TODO: EMTF SV reduced logic to potential valid rings only.
    //       I will use all rings for all zones since I am not sure about the
    //           vertical span of each chamber.
    //       This is something to consider putting into ZAPP when I roll this up.
    //           and therefore next year's focus
    // NOTE: currently cannot roll up more because I am missing lct index to layer LUT and more
    for (int zn = 0; zn < 7; zn++) {
        // Layer 0: ME11
        ph_zone[zn][0] = 0;
        for (int i = 0; i < 2; i++) // From cscid-to-ring-conversion.pdf
            for (int j = 0; j < 3; j++) // For ring 1
                if (phzvl[i][j][zn]) OREQUAL(ph_zone[zn][0](ph_init_hard[i][j] + ph_hit_w10 - 1, ph_init_hard[i][j]), ph_hit[i][j]);
        if (phzvl[5][0][zn]) OREQUAL(ph_zone[zn][0](ph_init_hard[0][12] + ph_hit_w10 - 1, ph_init_hard[0][12]), ph_hit[5][0]); // ME11B neighbor
        // ph_init_hard[1] in neighbor missing because that is ME11A neighbor which is in ME11B (i = 1) in cscid-to-ring-conversion.pdf


        // Layer 1: ME12
        ph_zone[zn][1] = 0;
        for (int i = 0; i < 2; i++) // ME1 rings 2 and 3
            for (int j = 3; j < 9; j++)
                if (phzvl[i][j][zn]) OREQUAL(ph_zone[zn][1](ph_init_hard[i][j] + ph_hit_w10 - 1, ph_init_hard[i][j]), ph_hit[i][j]);
        for (int j = 1; j < 3; j++) // ME11B rings 2,3 neighbor
            if (phzvl[5][j][zn]) OREQUAL(ph_zone[zn][1](ph_init_hard[0][j+12] + ph_hit_w10 - 1, ph_init_hard[0][j+12]), ph_hit[5][j]);

        // Layer 2: ME2
        ph_zone[zn][2] = 0;
        for (int j = 0; j < 3; j++) // ME2, ring1 span 20
            if (phzvl[2][j][zn]) OREQUAL(ph_zone[zn][2](ph_init_hard[2][j] + ph_hit_w20 - 1, ph_init_hard[2][j]), ph_hit[2][j]);
        for (int j = 3; j < 9; j++) // ME2, ring2,3 span 10
            if (phzvl[2][j][zn]) OREQUAL(ph_zone[zn][2](ph_init_hard[2][j] + ph_hit_w10 - 1, ph_init_hard[2][j]), ph_hit[2][j]);
        if (phzvl[5][3][zn]) OREQUAL(ph_zone[zn][2](ph_init_hard[2][ 9] + ph_hit_w20 - 1, ph_init_hard[2][ 9]), ph_hit[5][3]); // ME2 ring1 neighbor span 20
        if (phzvl[5][4][zn]) OREQUAL(ph_zone[zn][2](ph_init_hard[2][10] + ph_hit_w10 - 1, ph_init_hard[2][10]), ph_hit[5][4]); // ME2 ring2 neighbor span 10

        // Layer 3: ME3
        ph_zone[zn][3] = 0;
        for (int j = 0; j < 3; j++) // ME3, ring1 span 20
            if (phzvl[3][j][zn]) OREQUAL(ph_zone[zn][3](ph_init_hard[3][j] + ph_hit_w20 - 1, ph_init_hard[3][j]), ph_hit[3][j]);
        for (int j = 3; j < 9; j++)
            if (phzvl[3][j][zn]) OREQUAL(ph_zone[zn][3](ph_init_hard[3][j] + ph_hit_w10 - 1, ph_init_hard[3][j]), ph_hit[3][j]);
        if (phzvl[5][5][zn]) OREQUAL(ph_zone[zn][3](ph_init_hard[3][ 9] + ph_hit_w20 - 1, ph_init_hard[3][ 9]), ph_hit[5][5]); // ME3 ring1 neighbor span 20
        if (phzvl[5][6][zn]) OREQUAL(ph_zone[zn][3](ph_init_hard[3][10] + ph_hit_w10 - 1, ph_init_hard[3][10]), ph_hit[5][6]); // ME3 ring2 neighbor span 10

        // Layer 4: ME4
        ph_zone[zn][4] = 0;
        for (int j = 0; j < 3; j++)
            if (phzvl[4][j][zn]) OREQUAL(ph_zone[zn][4](ph_init_hard[4][j] + ph_hit_w20 - 1, ph_init_hard[4][j]), ph_hit[4][j]);
        for (int j = 3; j < 9; j++)
            if (phzvl[4][j][zn]) OREQUAL(ph_zone[zn][4](ph_init_hard[4][j] + ph_hit_w10 - 1, ph_init_hard[4][j]), ph_hit[4][j]);
        if (phzvl[5][7][zn]) OREQUAL(ph_zone[zn][4](ph_init_hard[4][ 9] + ph_hit_w20 - 1, ph_init_hard[4][ 9]), ph_hit[5][7]); // ME4 ring1 neighbor span 20
        if (phzvl[5][8][zn]) OREQUAL(ph_zone[zn][4](ph_init_hard[4][10] + ph_hit_w10 - 1, ph_init_hard[4][10]), ph_hit[5][8]); // ME4 ring2 neighbor span 10

        // Layer 5-8: RE1-4
        // Chamber 0 in coord_delay.sv
        ph_zone[zn][5] = 0;
        ph_zone[zn][6] = 0;
        ph_zone[zn][7] = 0;
        ph_zone[zn][8] = 0;
        for (int i = 1; i < 7; i++) // Subsector
            for (int j = 0; j < 8; j++) { // Chamber
                // From prim_conv_sector
                ap_uint<4> station = (j == 0 && i > 3) ? 1 :
                                     (j == 0)          ? 0 :
                                     (j == 1)          ? 2 :
                                     (j == 2 || j == 3 || j == 6)? 3 : // 6 is iRPC3/1
                                     (j == 4 || j == 5 || j == 7)? 4 : // 7 is iRPC4/1
                                                                  -1;
                ap_uint<4> rpcid   = (j == 0 && i > 3) ? i - 1 :
                                                         i + 2;  // Subsector 1 aligns with chamber 3 in non-ME11 stations
                ap_uint<4> lay = (station > 0) ? ap_uint<4>(4 + station) : ap_uint<4>(5);
                if (phzvl[6+i][j][zn]) OREQUAL(ph_zone[zn][lay](ph_init_hard[station][rpcid] + ph_hit_w10 - 1, ph_init_hard[station][rpcid]), ph_hit[6+i][j]);
            }
        // RE1-4 neighbors
        for (unsigned int j = 0; j < 8; j++) {
            // From prim_conv_sector
            ap_uint<4> station = (j == 0) ? 1 :
                                 (j == 1) ? 2 :
                                 (j < 4 || j == 6)? 3 :
                                 (j < 6 || j == 7)? 4 :
                                           -1;
            ap_uint<4> lay = 4 + station;
            // RPC aligned with CSC ring 2, so ph_init_hard looks at ring 2 neighbors (index 10)
            if (phzvl[6][j][zn]) OREQUAL(ph_zone[zn][lay](ph_init_hard[station][10] + ph_hit_w10 - 1, ph_init_hard[station][10]), ph_hit[6][j]);
        } // block: rpcn

//        // Layer 9: GE11
//        // TODO: Change gem_init_hard to actual LUT once we get it
//        // TODO: Ask Alex about GEM rings once we can convert them
//        ph_zone[zn][9] = 0;
//        for (int j = 0; j < 9; j++)
//            if (phzvl[TODO][j][zn]) OREQUAL(ph_zone[zn][9](gem_init_hard[TODO][j] + ph_hit_wTODO - 1, ph_init_hard[TODO][j]), ph_hit[TODO][j]);

//        // Layer 10: GE21
//        // TODO: Change gem_init_hard to actual LUT once we get it
//        // TODO: Ask Alex about GEM rings once we can convert them
//        ph_zone[zn][10] = 0;
//        for (int j = 0; j < 9; j++)
//            if (phzvl[TODO][j][zn]) OREQUAL(ph_zone[zn][10](gem_init_hard[TODO][j] + ph_hit_wTODO - 1, ph_init_hard[TODO][j]), ph_hit[TODO][j]);

//        // Layer 11: ME0
//        // TODO: Change me0_init_hard to actual LUT once it exists
//        // TODO: Ask Alex about ME0 rings once it exists
//        ph_zone[zn][11] = 0;
//        for (int j = 0; j < 9; j++)
//            if (phzvl[TODO][j][zn]) OREQUAL(ph_zone[zn][11](me0_init_hard[TODO][j] + ph_hit_wTODO - 1, ph_init_hard[TODO][j]), ph_hit[TODO][j]);

//        // Layer 12: MB1
//        ph_zone[zn][12] = 0;
//        for (int j = 0; j < 9; j++)
//            if (phzvl[TODO][j][zn]) OREQUAL(ph_zone[zn][12](me0_init_hard[TODO][j] + ph_hit_wTODO - 1, ph_init_hard[TODO][j]), ph_hit[TODO][j]);

//        // Layer 13: MB2
//        ph_zone[zn][13] = 0;
//        for (int j = 0; j < 9; j++)
//            if (phzvl[TODO][j][zn]) OREQUAL(ph_zone[zn][13](me0_init_hard[TODO][j] + ph_hit_wTODO - 1, ph_init_hard[TODO][j]), ph_hit[TODO][j]);

//        // Layer 14: MB3
//        ph_zone[zn][14] = 0;
//        for (int j = 0; j < 9; j++)
//            if (phzvl[TODO][j][zn]) OREQUAL(ph_zone[zn][14](me0_init_hard[TODO][j] + ph_hit_wTODO - 1, ph_init_hard[TODO][j]), ph_hit[TODO][j]);
    }

#ifndef __SYNTHESIS__
    #ifdef ZNS_PRINT_MACRO
    for (int i = 0; i < 4; i++)
        for (int j = 0; j < 4; j++)
            std::cout << "    ph_zone[" << i << "][" << j+1 << "] = " << apu_to_hex<ph_raw_w>(ph_zone[i][j]) << std::endl;
            //printf("    ph_zone[%d][%d] = %lx\n", i, j+1, temp = ph_zone[i][j]);
    #endif /*ZNS_PRINT_MACRO */
#endif /* __SYNTHESIS__ */
}

