//////////////////////////////////////////////////////////////////////////////////
// Company: UF
// Author: Rafael Hernandez
//
// Create Date:    01:36:08 03/19/2010
// Design Name: tf_slch
// Module Name:    ph_pattern
// Project Name: tf_slch
// Target Devices: V6
// Tool versions: 11.4
// Description: a single pattern detector
//
// Dependencies:
//
// Revision:
// Revision 0.01 - File Created
// Additional Comments: Translated by Rafael into C++
//
//////////////////////////////////////////////////////////////////////////////////
#include "../interface/ph_pattern_EMTFe.h"

ph_pattern::ph_pattern() {
}

    bool ph_pattern::is_emtf_singlemu(ap_uint<4> &mode) const {
#pragma HLS inline
        switch (mode) { // s.contains(mode);
            case 11: case 13: case 14: case 15:
                return 1;
            default:
                return 0;
        }
    }

    bool ph_pattern::is_emtf_doublemu(ap_uint<4> &mode) const {
#pragma HLS inline
        //static const std::set<int> s {9,10,12,11,13,14,15};  // replace 2-3-4 with 1-4
        switch (mode) { // s.contains(mode);
            case 11: case 13: case 14: case 15:
            case  9: case 10: case 12:
                return 1;
            default:
                return 0;
        }
    }

    bool ph_pattern::is_emtf_muopen(ap_uint<4> &mode) const {
#pragma HLS inline
        //static const std::set<int> s {3,5,6,9,7,10,12,11,13,14,15};
        switch (mode) {
            case 11: case 13: case 14: case 15:
            case  9: case 10: case 12:
            case  3: case  5: case  6: case  7:
                return 1;
            default:
                return 0;
        };
    }

void ph_pattern::operator()(
    const ap_uint<zapp_pat_layer_sz[ 0]> &st0,  // ME11
    const ap_uint<zapp_pat_layer_sz[ 1]> &st1,  // ME12
    const ap_uint<1>                     &st2,  // ME2
    const ap_uint<zapp_pat_layer_sz[ 3]> &st3,  // ME3
    const ap_uint<zapp_pat_layer_sz[ 4]> &st4,  // ME4
    const ap_uint<zapp_pat_layer_sz[ 5]> &st5,  // RE1
    const ap_uint<zapp_pat_layer_sz[ 6]> &st6,  // RE2
    const ap_uint<zapp_pat_layer_sz[ 7]> &st7,  // RE3
    const ap_uint<zapp_pat_layer_sz[ 8]> &st8,  // RE4
    const ap_uint<zapp_pat_layer_sz[ 9]> &st9,  // GE11
    const ap_uint<zapp_pat_layer_sz[10]> &st10, // GE21
    const ap_uint<zapp_pat_layer_sz[11]> &st11, // ME0
    const ap_uint<zapp_pat_layer_sz[12]> &st12, // MB1
    const ap_uint<zapp_pat_layer_sz[13]> &st13, // MB2
    const ap_uint<zapp_pat_layer_sz[14]> &st14, // MB3
    const ap_uint<3>                     &drifttime,
    const ap_uint<3>                     &foldn,
          ap_uint<11>                    &qcode
) {
//#pragma HLS inline

#include "../interface/pbank.h"

#pragma HLS array_partition variable=pbank dim=0
#pragma HLS array_partition variable=bx    dim=0

#pragma HLS interface ap_ctrl_none port=return
//#pragma HLS INLINE off
//#pragma HLS pipeline II=1
#pragma HLS latency max=0

    ap_uint<15> lyhits = 0;    // hit_lay in EMTFpp
    ap_uint<11> qcode_p[9] = {0,0,0,0,0,0,0,0,0}; // Sort code in EMTFpp
    ap_uint<3>  straightness;
    ap_uint<11> comp1[4];
    ap_uint<11> comp2[3];
    ap_uint<11> comp3;

    ap_uint<4> box_mode[9];          // road_mode  in EMTFpp, but we are using hit boxes in FPGA
    ap_uint<4> box_mode_csc[9];      // road_mode* in EMTFpp, but we are using hit boxes in FPGA
    ap_uint<2> box_mode_me0[9];      // road_mode* in EMTFpp, but we are using hit boxes in FPGA
    ap_uint<4> box_mode_me12[9];     // road_mode* in EMTFpp, but we are using hit boxes in FPGA
    ap_uint<4> box_mode_csc_me12[9]; // road_mode* in EMTFpp, but we are using hit boxes in FPGA
    ap_uint<2> box_mode_mb1[9];      // road_mode* in EMTFpp, but we are using hit boxes in FPGA
    ap_uint<2> box_mode_mb2[9];      // road_mode* in EMTFpp, but we are using hit boxes in FPGA
    ap_uint<2> box_mode_me13[9];     // road_mode* in EMTFpp, but we are using hit boxes in FPGA

    // First 9 patterns for prompt muons  : -1/2 <= q/pT <= +1/2
    // Next 9 patterns for displaced muons: -1/14 <= q/pT <= +1/14, -120 <= d0 <= 120
    // Total is 18 patterns.
    // ipt   0  1  2  3  4  5  6  7  8
    // strg  1  3  5  7  9  7  5  3  1
    // ipt   9 10 11 12 13 14 15 16 17
    // strg  0  2  4  6  8  6  4  2  0
    const ap_uint<4> straightness_lut[] = {1,3,5,7,9,7,5,3,1,0,2,4,6,8,6,4,2,0};
    // 10   9      8      7    6      5    4    3..0
    //      ME1/1  ME1/2  ME2         ME3  ME4  qual
    //                         RE1&2  RE3  RE4
    // ME0         GE1/1       GE2/1
    // MB1  MB2                MB3&4
    const ap_uint<4> sort_lut[] = {9,8,7,5,4,6,6,5,4,8,6,10,10,9,6,6};

    for (int mi = 0; mi < 9; mi++) {
#pragma HLS unroll
        // pbank is patternbank
        // pbank[pattern][zone][layer][0 - min, 1 - mid, 2 - max]
        lyhits[ 0] = st0 (pbank[mi][zone][ 0][2], pbank[mi][zone][ 0][0]) != 0;
        lyhits[ 1] = st1 (pbank[mi][zone][ 1][2], pbank[mi][zone][ 1][0]) != 0;
        lyhits[ 2] = st2                                                  != 0;
        lyhits[ 3] = st3 (pbank[mi][zone][ 3][2], pbank[mi][zone][ 3][0]) != 0;
        lyhits[ 4] = st4 (pbank[mi][zone][ 4][2], pbank[mi][zone][ 4][0]) != 0;
        lyhits[ 5] = st5 (pbank[mi][zone][ 5][2], pbank[mi][zone][ 5][0]) != 0;
        lyhits[ 6] = st6 (pbank[mi][zone][ 6][2], pbank[mi][zone][ 6][0]) != 0;
        lyhits[ 7] = st7 (pbank[mi][zone][ 7][2], pbank[mi][zone][ 7][0]) != 0;
        lyhits[ 8] = st8 (pbank[mi][zone][ 8][2], pbank[mi][zone][ 8][0]) != 0;
        lyhits[ 9] = st9 (pbank[mi][zone][ 9][2], pbank[mi][zone][ 9][0]) != 0;
        lyhits[10] = st10(pbank[mi][zone][10][2], pbank[mi][zone][10][0]) != 0;
        lyhits[11] = st11(pbank[mi][zone][11][2], pbank[mi][zone][11][0]) != 0;
        lyhits[12] = st12(pbank[mi][zone][12][2], pbank[mi][zone][12][0]) != 0;
        lyhits[13] = st13(pbank[mi][zone][13][2], pbank[mi][zone][13][0]) != 0;
        lyhits[14] = st14(pbank[mi][zone][14][2], pbank[mi][zone][14][0]) != 0;

        // Straightness based on pattern
        straightness = straightness_lut[mi];

        // All "Road" mode logic
        // TODO ask Jia Fu if RB1:4 count as stations 1:4
        //road_mode |= (1 << (4 - station));
        // bit0: station 4
        //                ME4                     RE4                                  MB4
        box_mode[mi][0] = lyhits[4]             | lyhits[8];
        // bit1: station 3
        //                ME3                     RE3                                  MB3
        box_mode[mi][1] = lyhits[3]             | lyhits[7]                          | lyhits[14];
        // bit2: station 2
        //                ME2                     RE2         GE21                     MB2
        box_mode[mi][2] = lyhits[2]             | lyhits[6] | lyhits[10]             | lyhits[13];
        // bit3: station 1
        //                ME11        ME12        RE1         GE11        ME0          MB1
        box_mode[mi][3] = lyhits[0] | lyhits[1] | lyhits[5] | lyhits[9] | lyhits[11] | lyhits[12];

        //if ((type == TriggerPrimitive::kCSC) || (type == TriggerPrimitive::kME0)) // ME0 are GEM
        //    road_mode_csc |= (1 << (4 - station));
        // bit0: station 4
        //                    ME4
        box_mode_csc[mi][0] = lyhits[4];
        // bit1: station 3
        //                    ME3
        box_mode_csc[mi][1] = lyhits[3];
        // bit2: station 2
        //                    ME2
        box_mode_csc[mi][2] = lyhits[2];
        // bit3: station 1
        //                    ME11        ME12        ME0
        box_mode_csc[mi][3] = lyhits[0] | lyhits[1] | lyhits[11];

        //if ((type == TriggerPrimitive::kME0) && (bx == 0))
        //    road_mode_me0 |= (1 << 1);
        box_mode_me0[mi][1] = lyhits[11]; // TODO: Had extra bx == 0 term ask Alex
        //else if ((type == TriggerPrimitive::kCSC) && (station == 1) && ((ring == 1) || (ring == 4)) && (bx == 0))
        //    road_mode_me0 |= (1 << 0);
        // Ring data was flattened down, so checking all CSC in station 1
        box_mode_me0[mi][0] = ~lyhits[11] & (lyhits[0] | lyhits[1]);

        //if ((type == TriggerPrimitive::kCSC) && (station == 1) && ((ring == 2) || (ring == 3))) // pretend as station 2
        //    road_mode_me12 |= (1 << (4 - 2));
        //else if ((type == TriggerPrimitive::kRPC) && (station == 1) && ((ring == 2) || (ring == 3))) // pretend as station 2
        //    road_mode_me12 |= (1 << (4 - 2));
        // Ring data was flattened down, so checking all CSC or RPC in station 1
        box_mode_me12[mi][2] = lyhits[0] | lyhits[1] | lyhits[5];
        //else
        box_mode_me12[mi][0] = ~(lyhits[0] | lyhits[1] | lyhits[5]) & (lyhits[4]             | lyhits[8]);
        box_mode_me12[mi][1] = ~(lyhits[0] | lyhits[1] | lyhits[5]) & (lyhits[3]             | lyhits[7]                          | lyhits[14]);
        box_mode_me12[mi][2] = ~(lyhits[0] | lyhits[1] | lyhits[5]) & (lyhits[2]             | lyhits[6] | lyhits[10]             | lyhits[13]);
        box_mode_me12[mi][3] = ~(lyhits[0] | lyhits[1] | lyhits[5]) & (lyhits[0] | lyhits[1] | lyhits[5] | lyhits[9] | lyhits[11] | lyhits[12]);

        //if ((type == TriggerPrimitive::kCSC) && (station == 1) && ((ring == 2) || (ring == 3))) // pretend as station 2
        //    road_mode_csc_me12 |= (1 << (4 - 2));
        //else if (type == TriggerPrimitive::kCSC)
        //    road_mode_csc_me12 |= (1 << (4 - station));
        box_mode_csc_me12[mi][2] = lyhits[0] | lyhits[1];
        box_mode_csc_me12[mi][0] = ~(lyhits[0] | lyhits[1]) & lyhits[4];
        box_mode_csc_me12[mi][1] = ~(lyhits[0] | lyhits[1]) & lyhits[3];
        box_mode_csc_me12[mi][2] = ~(lyhits[0] | lyhits[1]) & lyhits[2];
        box_mode_csc_me12[mi][3] = ~(lyhits[0] | lyhits[1]) & (lyhits[0] | lyhits[1]);

        //if ((type == TriggerPrimitive::kDT) && (station == 1))
        //    road_mode_mb1 |= (1 << 1);
        box_mode_mb1[mi][1] = lyhits[12];
        //else if ((type == TriggerPrimitive::kDT) && (station >= 2))
        //    road_mode_mb1 |= (1 << 0);
        //else if ((type == TriggerPrimitive::kCSC) && (station >= 1) && ((ring == 2) || (ring == 3)))
        //    road_mode_mb1 |= (1 << 0);
        //else if ((type == TriggerPrimitive::kRPC) && (station >= 1) && ((ring == 2) || (ring == 3)))
        //    road_mode_mb1 |= (1 << 0);
        box_mode_mb1[mi][0] = ~lyhits[12] & (lyhits[13] | lyhits[14] |
                               lyhits[ 0] | lyhits[ 1] | lyhits[ 2] | lyhits[ 3] | lyhits[ 4] |
                               lyhits[ 5] | lyhits[ 6] | lyhits[ 7] | lyhits[ 8]);

        //if ((type == TriggerPrimitive::kDT) && (station == 2))
        //    road_mode_mb2 |= (1 << 1);
        box_mode_mb2[mi][1] = lyhits[13];
        //else if ((type == TriggerPrimitive::kDT) && (station >= 3))
        //    road_mode_mb2 |= (1 << 0);
        //else if ((type == TriggerPrimitive::kCSC) && (station >= 1) && ((ring == 2) || (ring == 3)))
        //    road_mode_mb2 |= (1 << 0);
        //else if ((type == TriggerPrimitive::kRPC) && (station >= 1) && ((ring == 2) || (ring == 3)))
        //    road_mode_mb2 |= (1 << 0);
        box_mode_mb2[mi][0] = ~lyhits[13] & (lyhits[14] |
                               lyhits[ 0] | lyhits[ 1] | lyhits[ 2] | lyhits[ 3] | lyhits[ 4] |
                               lyhits[ 5] | lyhits[ 6] | lyhits[ 7] | lyhits[ 8]);

        //if ((type == TriggerPrimitive::kCSC) && (station == 1) && ((ring == 2) || (ring == 3)))
        //    road_mode_me13 |= (1 << 1);
        if (lyhits[0] || lyhits[1])
            box_mode_me13[mi][1] = 1;
        //else if ((type == TriggerPrimitive::kCSC) && (station >= 2) && ((ring == 2) || (ring == 3)))
        //    road_mode_me13 |= (1 << 0);
        else if (lyhits[2] || lyhits[3] || lyhits[4])
            box_mode_me13[mi][0] = 1;
        //else if ((type == TriggerPrimitive::kRPC) && (station == 1) && ((ring == 2) || (ring == 3)))
        //    road_mode_me13 |= (1 << 1);
        else if (lyhits[5])
            box_mode_me13[mi][1] = 1;
        //else if ((type == TriggerPrimitive::kRPC) && (station >= 2) && ((ring == 2) || (ring == 3)))
        //    road_mode_me13 |= (1 << 0);
        else if (lyhits[6] || lyhits[7] || lyhits[8])
            box_mode_me13[mi][0] = 1;

        //more_than_one = (lyhits != 3'h0 && lyhits != 3'h1 && lyhits != 3'h2 && lyhits != 3'h4) ? 1'b1 : 1'b0;
        //more_than_zero = (lyhits != 3'h0) ? 1'b1 : 1'b0;


        // Apply SingleMu requirement
        // + (zones 0,1) any road with ME0 and ME1
        // + (zone 4) any road with ME1/1, ME1/2 + one more station
        // + (zone 5) any road with 2 stations
        // + (zone 6) any road with MB1+MB2, MB1+MB3, MB1+ME1/3, MB1+ME2/2, MB2+MB3, MB2+ME1/3, MB2+ME2/2, ME1/3+ME2/2
        if (
                bx[mi][foldn][2] == 0 && // if drift time is up, find quality of this pattern
                bx[mi][foldn][1] == 1 && (
                    (is_emtf_singlemu(box_mode[mi]) && is_emtf_muopen(box_mode_csc[mi])) ||
                    (((zone == 0) || (zone == 1)) && (box_mode_me0[mi] == 3)) ||
                    ((zone == 4) && is_emtf_singlemu(box_mode_me12[mi]) && is_emtf_muopen(box_mode_csc_me12[mi])) ||
                    ((zone == 5) && is_emtf_doublemu(box_mode[mi]) && is_emtf_muopen(box_mode_csc[mi])) ||
                    ((zone == 6) && ((box_mode_mb1[mi] == 3) || (box_mode_mb2[mi] == 3) || (box_mode_me13[mi] == 3)))
//                    lyhits
                )
        ) {
            // Quality based on which layers lit up
            for (int i = 0; i < 15; i++)
        #pragma HLS unroll
                if (lyhits[i])
                    qcode_p[mi][sort_lut[i]] = 1;
            qcode_p[mi] = qcode_p[mi] | straightness;
            //qcode_p[mi] = {straightness[2], lyhits[2], straightness[1], lyhits[1], straightness[0], lyhits[0]};
        }


       // process bx shifter
        bx[mi][foldn][2] = bx[mi][foldn][1];
        bx[mi][foldn][1] = bx[mi][foldn][0];
        bx[mi][foldn][0] = lyhits != 0; // put 1 in shifter when at least one layer is hit
    }

    // find max quality
    comp1[0] = qcode_p[0] > qcode_p[1] ? qcode_p[0] : qcode_p[1];
    comp1[1] = qcode_p[2] > qcode_p[3] ? qcode_p[2] : qcode_p[3];
    comp1[2] = qcode_p[4] > qcode_p[5] ? qcode_p[4] : qcode_p[5];
    comp1[3] = qcode_p[6] > qcode_p[7] ? qcode_p[6] : qcode_p[7];

    comp2[0] = comp1[0] > comp1[1] ? comp1[0] : comp1[1];
    comp2[1] = comp1[2] > comp1[3] ? comp1[2] : comp1[3];

    comp3 = comp2[0] > comp2[1] ? comp2[0] : comp2[1];

    qcode = comp3 > qcode_p[8] ? comp3 : qcode_p[8];
//    if (qcode != 0) {
//        std::cout << "qcode: " << qcode
//                  << " bm0: " << box_mode[0]
//                  << " bm1: " << box_mode[1]
//                  << " bm2: " << box_mode[2]
//                  << " bm3: " << box_mode[3]
//                  << " bm4: " << box_mode[4]
//                  << " bm5: " << box_mode[5]
//                  << " bm6: " << box_mode[6]
//                  << " bm7: " << box_mode[7]
//                  << " bm8: " << box_mode[8]
//                  << std::endl
//                  << std::hex << "st0: " << st0
//                  << std::hex << " st1: " << st1
//                  << std::hex << " st2: " << st2
//                  << std::hex << " st3: " << st3
//                  << std::hex << " st4: " << st4
//                  << std::hex << " st5: " << st5
//                  << std::hex << " st6: " << st6
//                  << std::hex << " st7: " << st7
//                  << std::hex << " st8: " << st8
//                  << std::hex << " st9: " << st9
//                  << std::hex << " st10: " << st10
//                  << std::hex << " st11: " << st11
//                  << std::hex << " st12: " << st12
//                  << std::hex << " st13: " << st13
//                  << std::hex << " st14: " << st14
//                  << std::hex << " st15: " << st15
//                  << std::endl;
//    }

}

