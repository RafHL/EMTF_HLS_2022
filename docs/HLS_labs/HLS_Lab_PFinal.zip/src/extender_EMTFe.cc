//////////////////////////////////////////////////////////////////////////////////
// Company: UF
// Author: Rafael Hernandez, Beichen (Oliver) Su
//
// Create Date:    14:24:00 03/12/2010
// Design Name: tf_slhc
// Module Name:    extender
// Project Name: tf_slhc
// Target Devices: V6
// Tool versions: 11.4
// Description: pulse extender
//
// Dependencies:
//
// Revision:
// Revision 0.01 - File Created
// Additional Comments: Translated by Oliver into C++, then heavily updated by
//                      Rafael
//
//////////////////////////////////////////////////////////////////////////////////
#include "../interface/extender_EMTFe.h"

extender::extender(): d1(0), d2(0) { }

void extender::operator()(
    const ap_uint<ph_raw_w> &inp,
          ap_uint<ph_raw_w> &outp,
    const ap_uint<3>        &drifttime
) {

#pragma HLS Interface ap_stable port=inp
#pragma HLS interface ap_ctrl_none port=return
#pragma HLS inline off
// TODO: Check synthesis if HLS inline suggested in _sector and this pipeline
//           request removed
#pragma HLS pipeline

    // build delay lines for each bit

    outp = d2|d1|inp; // output logic should be combinatorial to reduce latency
    d2   = d1;
    d1   = inp;

}

