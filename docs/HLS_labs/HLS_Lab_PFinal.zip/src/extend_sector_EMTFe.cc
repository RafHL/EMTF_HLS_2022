
//////////////////////////////////////////////////////////////////////////////////
// Company: UF
// Authors: Rafael Hernandez, Beichen (Oliver) Su
//
// Create Date:    01:23:48 03/27/2010
// Design Name: tf_slhc
// Module Name:    extend_sector
// Project Name: tf_slhc
// Target Devices: V6
// Tool versions: 11.4
// Description: raw hit extender for entire sector
//
// Dependencies: extender
//
// Revision:
// Revision 0.01 - File Created
// Additional Comments: Translated by Oliver into C++, then heavily updated by
//                      Rafael
//
//////////////////////////////////////////////////////////////////////////////////
#include "../interface/extend_sector_EMTFe.h"

extend_sector::extend_sector() {
    // System Verilog generation constant parameters set up:
//    ph_zone_blk:
//    for (ap_uint<3> i = 0; i < 7; i++)
//        station:
//        for (ap_uint<3> j = 0; j < 16; j++)
//            ext[i][j].bit_w = ph_raw_w;
}

void extend_sector::operator()(
    // ph zones [zone][layer]
    const ap_uint<ph_raw_w>  ph_zone[7][15],
    // ph extended zones [zone][layer]
          ap_uint<ph_raw_w>  ph_ext [7][15],
    const ap_uint<3>        &drifttime
) {

#pragma HLS interface ap_ctrl_none port=return
#pragma HLS pipeline
#pragma HLS array_partition variable=ph_zone dim=0
#pragma HLS array_partition variable=ph_ext dim=0
//#pragma HLS INLINE off

#if defined(EXTS_FILE_MACRO) && defined(EXTS_I_FILENAME) && defined(EXTS_O_FILENAME) && !defined(__SYNTHESIS__)
    static std::ofstream of_i(EXTS_I_FILENAME);
    static std::ofstream of_o(EXTS_O_FILENAME);
    static bool first_time = 1;
    static int  event = 0;
#endif // EXTS_FILE


    //ph_zone_blk:
    for (unsigned int zn = 0; zn < 7u; zn++)
        //station:
        for (unsigned int ly = 0; ly < 15u; ly++)
            ext[zn][ly](
                ph_zone [zn][ly],
                ph_ext  [zn][ly],
                drifttime
            );

#ifndef __SYNTHESIS__
    #ifdef EXTS_PRINT_MACRO
    for (unsigned int zn = 0; zn < 7u; zn++) {
        for (unsigned int ly = 0; ly < 15u; ly++) {
            std::cout << "ph_zone[" << zn << "][" << ly << "]=" << apu_to_hex<ph_raw_w>(ph_zone[zn][ly]) << std::endl;
            std::cout << "ph_ext[" << zn << "][" << ly << "]=" << apu_to_hex<ph_raw_w>(ph_ext[zn][ly]) << std::endl;
        }
    }
    #endif /*EXTS_PRINT_MACRO */
#endif /* __SYNTHESIS__ */
#ifndef __SYNTHESIS__
    #if defined(EXTS_FILE_MACRO) && defined(EXTS_I_FILENAME) && defined(EXTS_O_FILENAME) && !defined(__SYNTHESIS__)
    if (first_time) {
        of_i << "    zone    layer keystrip   ph_zone" << std::endl;
        of_i << "       7       15      160   ph_zone" << std::endl;
        of_o << "    zone    layer keystrip   ph_ext" << std::endl;
        of_o << "       7       15      160   ph_ext" << std::endl;
        first_time = 0;
    }
    for (unsigned int zn = 0; zn < 7u; zn++) {
        for (unsigned int ly = 0; ly < 15u; ly++) {
            for (unsigned int ks = 0; ks < ph_raw_w; ks++) {
                if (ph_zone[zn][ly][ks])
                    of_i << std::setw(8) << zn << " "
                         << std::setw(8) << ly << " "
                         << std::setw(8) << ks << " "
                         << std::setw(8) << 1  << std::endl;
                if (ph_ext [zn][ly][ks]) {
                    of_o << std::setw(8) << zn << " "
                         << std::setw(8) << ly << " "
                         << std::setw(8) << ks << " "
                         << std::setw(8) << 1  << std::endl;
                }
            }
        }
    }
    of_i << ++event << std::endl;
    of_o <<   event << std::endl;
    #endif /*EXTS_FILE_MACRO */
#endif /* __SYNTHESIS__ */
}
